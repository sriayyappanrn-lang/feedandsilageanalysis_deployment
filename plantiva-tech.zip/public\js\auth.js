/**
 * Plantiva Tech - Authentication & Session Gatekeeper
 * Strictly enforces Mandatory Login-First security:
 * No internal pages or protected data can be rendered without valid server session.
 */

let currentUserSession = null;

function getAuthToken() {
  return localStorage.getItem('plantiva_token');
}

function setAuthToken(token) {
  if (token) {
    localStorage.setItem('plantiva_token', token);
  } else {
    localStorage.removeItem('plantiva_token');
  }
}

// Wrapper for authenticated fetch
async function apiFetch(url, options = {}) {
  const token = getAuthToken();
  const headers = options.headers ? { ...options.headers } : {};

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const res = await fetch(url, { ...options, headers });
  
  if (res.status === 401) {
    // Session expired or invalid
    setAuthToken(null);
    currentUserSession = null;
    showAuthScreen();
    showToast('Your session has expired. Please log in again.', 'warning');
    throw new Error('Unauthorized');
  }

  return res;
}

// UI State Switcher: Auth Screen vs App Screen
function showAuthScreen() {
  document.getElementById('authScreen').classList.remove('hidden');
  document.getElementById('appScreen').classList.add('hidden');
}

function showAppScreen() {
  document.getElementById('authScreen').classList.add('hidden');
  document.getElementById('appScreen').classList.remove('hidden');
}

// Check session on load
async function checkAuthAndBoot() {
  const token = getAuthToken();
  if (!token) {
    showAuthScreen();
    return;
  }

  try {
    const res = await apiFetch('/api/auth/me');
    const data = await res.json();
    if (data.success && data.user) {
      currentUserSession = data.user;
      showAppScreen();
      initAppDashboard(data.user);
    } else {
      setAuthToken(null);
      showAuthScreen();
    }
  } catch (err) {
    setAuthToken(null);
    showAuthScreen();
  }
}

// Switch between Login and Register tabs
function switchAuthTab(tab) {
  const loginBtn = document.getElementById('tabBtnLogin');
  const regBtn = document.getElementById('tabBtnRegister');
  const loginForm = document.getElementById('loginFormContainer');
  const regForm = document.getElementById('registerFormContainer');

  if (tab === 'login') {
    loginBtn.className = 'flex-1 py-2 text-sm font-medium rounded-lg text-white bg-emerald-600 shadow-md transition-all';
    regBtn.className = 'flex-1 py-2 text-sm font-medium rounded-lg text-slate-400 hover:text-white transition-all';
    loginForm.classList.remove('hidden');
    regForm.classList.add('hidden');
  } else {
    regBtn.className = 'flex-1 py-2 text-sm font-medium rounded-lg text-white bg-emerald-600 shadow-md transition-all';
    loginBtn.className = 'flex-1 py-2 text-sm font-medium rounded-lg text-slate-400 hover:text-white transition-all';
    regForm.classList.remove('hidden');
    loginForm.classList.add('hidden');
  }
}

// Switch between Password and OTP Login Mode
function toggleLoginMode(mode) {
  const pwdField = document.getElementById('loginPasswordField');
  const otpField = document.getElementById('loginOtpField');

  if (mode === 'otp') {
    pwdField.classList.add('hidden');
    otpField.classList.remove('hidden');
  } else {
    pwdField.classList.remove('hidden');
    otpField.classList.add('hidden');
  }
}

// Request SMS OTP for Login
async function handleSendLoginOtp() {
  const phone = document.getElementById('loginPhone').value.trim();
  if (!phone || phone.length !== 10) {
    showToast('Please enter a valid 10-digit mobile number first.', 'error');
    return;
  }

  const btn = document.getElementById('btnRequestLoginOtp');
  btn.disabled = true;
  btn.innerText = 'Sending...';

  try {
    const res = await fetch('/api/auth/otp/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone })
    });
    const data = await res.json();

    if (data.success) {
      if (data.devMode && data.devTestOtp) {
        showToast(data.message, 'info', 10000);
        document.getElementById('loginOtpCode').value = data.devTestOtp;
      } else {
        showToast(data.message, 'success');
      }
    } else {
      showToast(data.error || 'Failed to dispatch OTP.', 'error');
    }
  } catch (err) {
    showToast('Network error while requesting OTP.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerText = 'Resend OTP';
  }
}

// Request SMS OTP for Registration
async function handleSendRegisterOtp() {
  const phone = document.getElementById('regPhone').value.trim();
  if (!phone || phone.length !== 10) {
    showToast('Please enter a valid 10-digit mobile number for registration.', 'error');
    return;
  }

  try {
    const res = await fetch('/api/auth/otp/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone })
    });
    const data = await res.json();

    if (data.success) {
      if (data.devMode && data.devTestOtp) {
        showToast(data.message, 'info', 10000);
        document.getElementById('regOtpCode').value = data.devTestOtp;
      } else {
        showToast(data.message, 'success');
      }
    } else {
      showToast(data.error || 'Failed to dispatch OTP.', 'error');
    }
  } catch (err) {
    showToast('Network error while requesting OTP.', 'error');
  }
}

// Submit Login
async function handleLoginSubmit() {
  const phone = document.getElementById('loginPhone').value.trim();
  const isOtpMode = document.querySelector('input[name="loginMode"]:checked').value === 'otp';
  const password = document.getElementById('loginPassword').value.trim();
  const otpCode = document.getElementById('loginOtpCode').value.trim();

  if (!phone || phone.length !== 10) {
    showToast('Please enter a valid 10-digit mobile number.', 'error');
    return;
  }

  if (isOtpMode && !otpCode) {
    showToast('Please enter the 6-digit SMS OTP received on your mobile.', 'error');
    return;
  }

  if (!isOtpMode && !password) {
    showToast('Please enter your password.', 'error');
    return;
  }

  const btn = document.getElementById('btnLoginSubmit');
  btn.disabled = true;
  btn.innerHTML = `<span class="animate-spin inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></span> Authenticating...`;

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        phone,
        password,
        otp_code: otpCode,
        login_method: isOtpMode ? 'otp' : 'password'
      })
    });

    const data = await res.json();

    if (data.success && data.token) {
      setAuthToken(data.token);
      currentUserSession = data.user;
      showToast(`Welcome back, ${data.user.full_name}!`, 'success');
      showAppScreen();
      initAppDashboard(data.user);
    } else {
      showToast(data.error || 'Authentication failed. Please verify credentials.', 'error');
    }
  } catch (err) {
    showToast('Server connection error. Please try again.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>Verify &amp; Enter Dashboard</span> <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>`;
  }
}

// Submit Registration
async function handleRegisterSubmit() {
  const fullName = document.getElementById('regFullName').value.trim();
  const role = document.getElementById('regRole').value;
  const phone = document.getElementById('regPhone').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value.trim();
  const otpCode = document.getElementById('regOtpCode').value.trim();

  if (!fullName) {
    showToast('Full Name is required.', 'error');
    return;
  }
  if (!phone || phone.length !== 10) {
    showToast('10-digit mobile number is required.', 'error');
    return;
  }
  if (!password || password.length < 6) {
    showToast('Password must be at least 6 characters.', 'error');
    return;
  }
  if (!otpCode) {
    showToast('Please request and enter the SMS verification OTP.', 'error');
    return;
  }

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        full_name: fullName,
        role,
        phone,
        email,
        password,
        otp_code: otpCode
      })
    });

    const data = await res.json();

    if (data.success && data.token) {
      setAuthToken(data.token);
      currentUserSession = data.user;
      showToast('Account registered successfully! Welcome to Plantiva Tech.', 'success');
      showAppScreen();
      initAppDashboard(data.user);
    } else {
      showToast(data.error || 'Registration failed.', 'error');
    }
  } catch (err) {
    showToast('Network error during registration.', 'error');
  }
}

// Quick demo login preset filler
function quickFillCredentials(phone, password) {
  document.getElementById('loginPhone').value = phone;
  const pwdRadio = document.querySelector('input[name="loginMode"][value="password"]');
  if (pwdRadio) {
    pwdRadio.checked = true;
    toggleLoginMode('password');
  }
  document.getElementById('loginPassword').value = password;
  showToast(`Loaded demo credentials for +91 ${phone}`, 'info');
}

// Logout
async function handleLogout() {
  try {
    await apiFetch('/api/auth/logout', { method: 'POST' });
  } catch (e) {
    // ignore
  }
  setAuthToken(null);
  currentUserSession = null;
  showAuthScreen();
  showToast('You have been securely logged out.', 'info');
}

// Forgot Password modal
function showForgotPasswordModal() {
  openModal(`
    <div class="space-y-4">
      <h3 class="text-lg font-bold text-white flex items-center space-x-2">
        <svg class="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
        <span>Account Recovery &amp; Password Reset</span>
      </h3>
      <p class="text-xs text-slate-400">
        Enter your registered 10-digit mobile number. A secure verification OTP will be dispatched to your phone to reset your password.
      </p>
      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Mobile Number</label>
        <input type="tel" id="resetPhoneInput" placeholder="9876543210" maxlength="10" class="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm">
      </div>
      <div class="flex justify-end space-x-3 pt-2">
        <button onclick="closeModal()" class="px-4 py-2 bg-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-medium">Cancel</button>
        <button onclick="handleTriggerPasswordReset()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold">Send Recovery OTP</button>
      </div>
    </div>
  `);
}

async function handleTriggerPasswordReset() {
  const phone = document.getElementById('resetPhoneInput').value.trim();
  if (!phone || phone.length !== 10) {
    showToast('Please enter a valid 10-digit mobile number.', 'error');
    return;
  }
  closeModal();
  document.getElementById('loginPhone').value = phone;
  const otpRadio = document.querySelector('input[name="loginMode"][value="otp"]');
  if (otpRadio) {
    otpRadio.checked = true;
    toggleLoginMode('otp');
  }
  handleSendLoginOtp();
}

document.addEventListener('DOMContentLoaded', () => {
  checkAuthAndBoot();
});
