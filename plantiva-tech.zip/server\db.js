const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');

const dbPath = path.join(__dirname, '..', 'data', 'plantiva.db');

// Ensure data directory exists
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const db = new DatabaseSync(dbPath);

// Enable WAL mode and foreign keys
db.exec(`PRAGMA journal_mode = WAL;`);
db.exec(`PRAGMA foreign_keys = ON;`);

function hashPassword(password, salt) {
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS branding_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      website_name TEXT NOT NULL,
      tagline TEXT,
      logo_url TEXT,
      favicon_url TEXT,
      primary_color TEXT,
      secondary_color TEXT,
      accent_color TEXT,
      font_family TEXT,
      support_email TEXT,
      support_phone TEXT,
      footer_text TEXT,
      hero_title TEXT,
      hero_subtitle TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      phone TEXT UNIQUE NOT NULL,
      email TEXT,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      full_name TEXT NOT NULL,
      role TEXT NOT NULL,
      organization TEXT,
      status TEXT DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      expires_at DATETIME NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS otp_records (
      phone TEXT PRIMARY KEY,
      otp_hash TEXT NOT NULL,
      plain_otp_dev TEXT,
      expires_at DATETIME NOT NULL,
      attempts INTEGER DEFAULT 0,
      resend_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      action TEXT NOT NULL,
      ip TEXT,
      details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS modules_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      module_key TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      icon TEXT NOT NULL,
      badge TEXT,
      is_enabled INTEGER DEFAULT 1,
      sort_order INTEGER NOT NULL,
      allowed_roles TEXT DEFAULT 'ALL',
      bg_theme TEXT
    );

    CREATE TABLE IF NOT EXISTS animal_categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      species_key TEXT UNIQUE NOT NULL,
      description TEXT,
      dmi_percentage_min REAL,
      dmi_percentage_max REAL,
      maintenance_cp_g_per_kg_bw REAL,
      milk_cp_g_per_liter REAL,
      icon TEXT,
      is_active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS animals (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      animal_tag TEXT NOT NULL,
      species TEXT NOT NULL,
      breed TEXT NOT NULL,
      age_months INTEGER NOT NULL,
      body_weight_kg REAL NOT NULL,
      sex TEXT NOT NULL,
      stage TEXT NOT NULL,
      milk_yield_liters REAL DEFAULT 0,
      pregnancy_status TEXT DEFAULT 'None',
      health_notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS feed_rations (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      animal_id TEXT,
      animal_tag TEXT,
      species TEXT NOT NULL,
      formula_type TEXT NOT NULL,
      ingredients_json TEXT NOT NULL,
      dmi_kg REAL NOT NULL,
      cp_g REAL NOT NULL,
      tdn_kg REAL NOT NULL,
      total_cost_inr REAL NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS feed_silage_tests (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      sample_name TEXT NOT NULL,
      animal_species TEXT NOT NULL,
      silage_type TEXT NOT NULL,
      ph REAL,
      dry_matter_pct REAL,
      crude_protein_pct REAL,
      crude_fibre_pct REAL,
      moisture_pct REAL,
      lactic_acid_pct REAL,
      butyric_acid_pct REAL,
      ammonia_n_pct REAL,
      measurement_type TEXT NOT NULL,
      lab_verified INTEGER DEFAULT 0,
      quality_grade TEXT NOT NULL,
      flieg_score REAL,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ml_models (
      id TEXT PRIMARY KEY,
      model_key TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      animal_category TEXT NOT NULL,
      version TEXT NOT NULL,
      status TEXT NOT NULL,
      dataset_version TEXT,
      accuracy_pct REAL,
      f1_score REAL,
      rmse REAL,
      input_schema TEXT,
      output_schema TEXT,
      last_update DATETIME DEFAULT CURRENT_TIMESTAMP,
      error_logs TEXT
    );

    CREATE TABLE IF NOT EXISTS datasets (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      animal_category TEXT NOT NULL,
      filename TEXT NOT NULL,
      file_size_bytes INTEGER NOT NULL,
      row_count INTEGER NOT NULL,
      columns_json TEXT NOT NULL,
      validation_status TEXT NOT NULL,
      missing_values_count INTEGER DEFAULT 0,
      duplicate_count INTEGER DEFAULT 0,
      uploaded_by TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS market_prices (
      id TEXT PRIMARY KEY,
      commodity TEXT NOT NULL,
      category TEXT NOT NULL,
      mandi_name TEXT NOT NULL,
      district TEXT NOT NULL,
      state TEXT NOT NULL,
      modal_price_per_quintal REAL NOT NULL,
      min_price REAL NOT NULL,
      max_price REAL NOT NULL,
      unit TEXT DEFAULT 'Quintal',
      price_date TEXT NOT NULL,
      data_source TEXT NOT NULL,
      is_verified INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS marketplace_listings (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      seller_name TEXT NOT NULL,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      price_inr REAL NOT NULL,
      quantity REAL NOT NULL,
      unit TEXT NOT NULL,
      product_condition TEXT NOT NULL,
      location TEXT NOT NULL,
      state TEXT NOT NULL,
      contact_phone TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT DEFAULT 'Active',
      image_url TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS marketplace_enquiries (
      id TEXT PRIMARY KEY,
      listing_id TEXT NOT NULL,
      buyer_name TEXT NOT NULL,
      buyer_phone TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'New',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (listing_id) REFERENCES marketplace_listings(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS agri_companies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      country TEXT NOT NULL,
      state TEXT NOT NULL,
      city TEXT NOT NULL,
      website TEXT NOT NULL,
      contact_email TEXT NOT NULL,
      contact_phone TEXT NOT NULL,
      products TEXT NOT NULL,
      description TEXT NOT NULL,
      careers_link TEXT,
      logo_url TEXT,
      is_verified INTEGER DEFAULT 1,
      approval_status TEXT DEFAULT 'Approved',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS machinery (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      manufacturer TEXT NOT NULL,
      model TEXT NOT NULL,
      hp_specs TEXT NOT NULL,
      price_estimate TEXT NOT NULL,
      applications TEXT NOT NULL,
      operating_specs TEXT NOT NULL,
      manual_url TEXT,
      image_url TEXT
    );

    CREATE TABLE IF NOT EXISTS govt_schemes (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      department TEXT NOT NULL,
      beneficiary TEXT NOT NULL,
      state TEXT NOT NULL,
      category TEXT NOT NULL,
      benefits TEXT NOT NULL,
      eligibility TEXT NOT NULL,
      documents_needed TEXT NOT NULL,
      apply_url TEXT NOT NULL,
      deadline TEXT,
      last_verified_date TEXT NOT NULL,
      is_active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS weather_stations (
      id TEXT PRIMARY KEY,
      location_name TEXT NOT NULL,
      state TEXT NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      temp_c REAL NOT NULL,
      humidity_pct REAL NOT NULL,
      rainfall_mm REAL NOT NULL,
      wind_speed_kmh REAL NOT NULL,
      heat_stress_index TEXT NOT NULL,
      drought_risk_indicator TEXT NOT NULL,
      crop_water_demand TEXT NOT NULL,
      forecast_summary TEXT NOT NULL,
      climate_projection_trend TEXT NOT NULL,
      data_source TEXT NOT NULL,
      recorded_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS assistant_chats (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      query TEXT NOT NULL,
      response TEXT NOT NULL,
      response_type TEXT NOT NULL,
      model_used TEXT NOT NULL,
      rating INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sms_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      provider TEXT DEFAULT 'Twilio / MSG91 / Fast2SMS',
      is_live INTEGER DEFAULT 0,
      api_key_masked TEXT DEFAULT 'NOT_CONFIGURED',
      sender_id TEXT DEFAULT 'PLANTV',
      dev_test_mode INTEGER DEFAULT 1,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS api_integrations (
      id TEXT PRIMARY KEY,
      service_name TEXT NOT NULL,
      endpoint TEXT NOT NULL,
      status TEXT NOT NULL,
      auth_mode TEXT NOT NULL,
      last_ping DATETIME
    );
  `);
}

function seedData() {
  // 1. Branding Config
  const brandingCheck = db.prepare('SELECT count(*) as count FROM branding_config').get();
  if (brandingCheck.count === 0) {
    db.prepare(`
      INSERT INTO branding_config (
        id, website_name, tagline, logo_url, favicon_url,
        primary_color, secondary_color, accent_color, font_family,
        support_email, support_phone, footer_text, hero_title, hero_subtitle
      ) VALUES (
        1,
        'Plantiva Tech',
        'Universal Agricultural Technology & Livestock Intelligence Platform',
        '/assets/plantiva_logo.svg',
        '/assets/favicon.ico',
        '#10b981',
        '#047857',
        '#f59e0b',
        'Inter, system-ui, sans-serif',
        'support@plantivatech.in',
        '+91 1800-419-7243',
        'Plantiva Tech — Empowering Indian Agriculture, Livestock Farmers & Agritech Engineers',
        'Universal Agricultural Technology Platform',
        'Advanced Livestock Feed Optimization, Mandi Market Intelligence, Precision Agri-Engineering & Climate Models'
      )
    `).run();
  }

  // 2. Users
  const userCheck = db.prepare('SELECT count(*) as count FROM users').get();
  if (userCheck.count === 0) {
    const saltAdmin = crypto.randomBytes(16).toString('hex');
    const hashAdmin = hashPassword('Admin@123', saltAdmin);

    const saltFarmer = crypto.randomBytes(16).toString('hex');
    const hashFarmer = hashPassword('Farmer@123', saltFarmer);

    const saltEngineer = crypto.randomBytes(16).toString('hex');
    const hashEngineer = hashPassword('Engineer@123', saltEngineer);

    const insertUser = db.prepare(`
      INSERT INTO users (id, phone, email, password_hash, salt, full_name, role, organization)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertUser.run('usr_super_admin', '9876543210', 'admin@plantivatech.in', hashAdmin, saltAdmin, 'Dr. Rajesh Verma', 'Super Administrator', 'Plantiva Central Command');
    insertUser.run('usr_farmer_ramesh', '9876500001', 'ramesh.patel@agrimail.in', hashFarmer, saltFarmer, 'Ramesh Patel', 'Farmer', 'Gujarat Kisan Cooperative');
    insertUser.run('usr_livestock_sunita', '9876500002', 'sunita.dairy@agrimail.in', hashFarmer, saltFarmer, 'Sunita Sharma', 'Livestock Owner', 'Gokul Dairy Farm, Haryana');
    insertUser.run('usr_engineer_anand', '9876500003', 'anand.agrieng@iit.ac.in', hashEngineer, saltEngineer, 'Er. Anand Kulkarni', 'Agricultural Engineer', 'Krishi Tech Labs, Pune');
    insertUser.run('usr_trader_gupta', '9876500004', 'trader.gupta@mandi.in', hashFarmer, saltFarmer, 'Vikram Gupta', 'Buyer / Seller / Trader', 'Karnal Grain Traders');
    insertUser.run('usr_researcher_meera', '9876500005', 'meera.res@icar.gov.in', hashEngineer, saltEngineer, 'Dr. Meera Nambiar', 'Researcher / Student', 'ICAR - NDRI Karnal');
  }

  // 3. SMS Config
  const smsCheck = db.prepare('SELECT count(*) as count FROM sms_config').get();
  if (smsCheck.count === 0) {
    db.prepare(`
      INSERT INTO sms_config (id, provider, is_live, api_key_masked, sender_id, dev_test_mode)
      VALUES (1, 'Govt DLT / MSG91 Enterprise Gateway', 0, 'SK_LIVE_*******982A', 'PLANTV', 1)
    `).run();
  }

  // 4. Modules Config (All 19 Modules)
  const modCheck = db.prepare('SELECT count(*) as count FROM modules_config').get();
  if (modCheck.count === 0) {
    const modules = [
      { key: 'feed-silage', name: 'Feed & Silage Recommendation', desc: 'Precision ration planning, nutrient formulas & silage lab analysis for cattle, buffalo, goats, sheep, pigs & poultry', icon: 'wheat', order: 1, badge: 'Scientific', theme: 'emerald' },
      { key: 'livestock', name: 'Livestock Management', desc: 'Animal health registers, tag tracking, milk yield monitoring, breeding stages & veterinary records', icon: 'paw-print', order: 2, badge: 'Core', theme: 'amber' },
      { key: 'assistant', name: 'AI Agricultural Assistant', desc: 'Conversational agri-expert model for crop pathology, livestock diet questions, and farming guidance', icon: 'bot', order: 3, badge: 'AI Advisory', theme: 'purple' },
      { key: 'marketing', name: 'Agricultural Marketing', desc: 'Real-time Mandi price discovery, APMC procurement directories, price trends & commodity analytics', icon: 'trending-up', order: 4, badge: 'APMC Live', theme: 'blue' },
      { key: 'marketplace', name: 'Buy & Sell Marketplace', desc: 'Direct trade of agricultural produce, dairy stock, implements, seeds, and bio-fertilizers', icon: 'shopping-cart', order: 5, badge: 'Direct Trade', theme: 'teal' },
      { key: 'companies', name: 'Agri-Engineering Directory', desc: 'Comprehensive verified index of farm machinery, irrigation, robotics, solar & processing equipment companies', icon: 'building-2', order: 6, badge: 'Verified', theme: 'indigo' },
      { key: 'machinery', name: 'Machinery & Equipment Directory', desc: 'Technical specifications, HP benchmarks, operational guides, and pricing for modern farm implements', icon: 'tractor', order: 7, badge: 'Equipment', theme: 'orange' },
      { key: 'schemes', name: 'Government Schemes & Subsidies', desc: 'Central & State subsidy programs, PM-KISAN, SMAM, NLM, PMKSY eligibility & official application links', icon: 'award', order: 8, badge: 'Govt Portal', theme: 'rose' },
      { key: 'climate', name: 'Global Climate & Weather Models', desc: 'High-resolution agro-meteorological metrics, rainfall trends, heat stress index & climate projections', icon: 'cloud-sun', order: 9, badge: 'Satellite/IMD', theme: 'sky' },
      { key: 'crop-farm', name: 'Crop & Farm Management', desc: 'Agronomic schedule tracker, crop stages, sowing to harvest lifecycle, and pest management journals', icon: 'sprout', order: 10, badge: 'Agronomy', theme: 'lime' },
      { key: 'soil-water', name: 'Soil & Water Management', desc: 'Soil Health Card nutrient registers (NPK, micronutrients, EC, pH) and salinity mitigation tools', icon: 'flask-conical', order: 11, badge: 'Lab Analysis', theme: 'cyan' },
      { key: 'irrigation', name: 'Irrigation & Water Conservation', desc: 'Drip/sprinkler efficiency calculators, evapotranspiration indices & solar pump water budgets', icon: 'droplets', order: 12, badge: 'Conservation', theme: 'blue' },
      { key: 'precision-agri', name: 'Precision Agriculture', desc: 'Drone variable rate spraying, NDVI satellite vegetation maps, and IoT sensor telemetry integration', icon: 'crosshair', order: 13, badge: 'IoT / Drone', theme: 'violet' },
      { key: 'post-harvest', name: 'Processing & Post-Harvest', desc: 'Cold storage tracking, grain dryer specs, grading parameters, and food value-addition workflows', icon: 'package-check', order: 14, badge: 'Supply Chain', theme: 'fuchsia' },
      { key: 'research-data', name: 'Agricultural Research & Datasets', desc: 'Curated agricultural datasets, agronomy trials, ICAR publications, and ML training feeds', icon: 'database', order: 15, badge: 'ICAR/CGIAR', theme: 'slate' },
      { key: 'analytics', name: 'Analytics & Reports', desc: 'Farm profitability projections, feed conversion ratio (FCR) analytics, and yield comparison reports', icon: 'bar-chart-3', order: 16, badge: 'BI Metrics', theme: 'emerald' },
      { key: 'profile', name: 'User Profile & Farm Settings', desc: 'Manage farmer KYC, land holding details, dairy herd size, phone verification & security credentials', icon: 'user-cog', order: 17, badge: 'Account', theme: 'zinc' },
      { key: 'notifications', name: 'Notifications & Alerts', desc: 'Weather storm alerts, Mandi rate fluctuations, vaccination schedules, and government scheme deadlines', icon: 'bell', order: 18, badge: 'Realtime', theme: 'red' },
      { key: 'admin', name: 'Super Admin Dashboard', desc: 'Branding manager, logo replace, RBAC user permissions, dataset approvals, SMS logs & model governance', icon: 'shield-alert', order: 19, badge: 'Admin Only', theme: 'red', allowed_roles: 'Super Administrator' }
    ];

    const insertMod = db.prepare(`
      INSERT INTO modules_config (module_key, name, description, icon, badge, sort_order, allowed_roles, bg_theme)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const m of modules) {
      insertMod.run(m.key, m.name, m.desc, m.icon, m.badge, m.order, m.allowed_roles || 'ALL', m.theme);
    }
  }

  // 5. Animal Categories
  const animCatCheck = db.prepare('SELECT count(*) as count FROM animal_categories').get();
  if (animCatCheck.count === 0) {
    const cats = [
      { id: 'cat_cattle', name: 'Cattle (Cows)', key: 'cattle', desc: 'Indigenous & Crossbred Dairy and Draught cattle (Gir, Sahiwal, Red Sindhi, HF cross)', dmi_min: 2.5, dmi_max: 3.5, cp_m: 350, cp_milk: 75, icon: 'cow' },
      { id: 'cat_buffalo', name: 'Buffaloes', key: 'buffalo', desc: 'High-fat dairy buffaloes (Murrah, Nili-Ravi, Mehsana, Jaffrabadi)', dmi_min: 2.8, dmi_max: 3.8, cp_m: 400, cp_milk: 90, icon: 'buffalo' },
      { id: 'cat_goat', name: 'Goats', key: 'goat', desc: 'Meat & Dairy breeds (Jamnapari, Barbari, Beetal, Sirohi, Black Bengal)', dmi_min: 3.0, dmi_max: 4.5, cp_m: 45, cp_milk: 65, icon: 'goat' },
      { id: 'cat_sheep', name: 'Sheep', key: 'sheep', desc: 'Wool & Mutton breeds (Nellore, Mandya, Marwari, Deccani)', dmi_min: 2.8, dmi_max: 4.0, cp_m: 40, cp_milk: 55, icon: 'sheep' },
      { id: 'cat_pig', name: 'Pigs', key: 'pig', desc: 'Commercial Swine (Large White Yorkshire, Landrace, Desi cross)', dmi_min: 3.0, dmi_max: 5.0, cp_m: 200, cp_milk: 0, icon: 'pig' },
      { id: 'cat_poultry', name: 'Poultry', key: 'poultry', desc: 'Broilers, Layers, and Backyard indigenous (Kadaknath, Aseel, BV-300)', dmi_min: 5.0, dmi_max: 10.0, cp_m: 18, cp_milk: 0, icon: 'bird' }
    ];

    const insertCat = db.prepare(`
      INSERT INTO animal_categories (id, name, species_key, description, dmi_percentage_min, dmi_percentage_max, maintenance_cp_g_per_kg_bw, milk_cp_g_per_liter, icon)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const c of cats) {
      insertCat.run(c.id, c.name, c.key, c.desc, c.dmi_min, c.dmi_max, c.cp_m, c.cp_milk, c.icon);
    }
  }

  // 6. ML Models Registry
  const mlCheck = db.prepare('SELECT count(*) as count FROM ml_models').get();
  if (mlCheck.count === 0) {
    const models = [
      { id: 'ml_cattle_feed', key: 'cattle-feed-model', name: 'Cattle Precision Feed Optimization Model', cat: 'Cattle', ver: 'v0.9.2-beta', status: 'Model integration pending', ds_ver: 'ICAR-NDRI-2024-v1', acc: 91.4, f1: 0.89, rmse: 0.32, in_schema: '{"weight_kg":"float", "milk_l":"float", "fat_pct":"float", "pregnancy_stage":"int"}', out_schema: '{"dmi_kg":"float", "concentrate_kg":"float", "dry_fodder_kg":"float", "green_fodder_kg":"float"}' },
      { id: 'ml_buffalo_feed', key: 'buffalo-feed-model', name: 'Murrah Buffalo High-Fat Ration Model', cat: 'Buffaloes', ver: 'v0.8.4-dev', status: 'Model integration pending', ds_ver: 'CIRB-Hisar-2024', acc: 89.2, f1: 0.87, rmse: 0.41, in_schema: '{"weight_kg":"float", "milk_l":"float", "fat_pct":"float"}', out_schema: '{"tdn_req_kg":"float", "dcp_g":"float"}' },
      { id: 'ml_goat_feed', key: 'goat-feed-model', name: 'Caprine Intensive Grazing & Feed Model', cat: 'Goats', ver: 'v0.7.1-dev', status: 'Model integration pending', ds_ver: 'CIRG-Makhdoom-v2', acc: 86.5, f1: 0.84, rmse: 0.28, in_schema: '{"weight_kg":"float", "stage":"string"}', out_schema: '{"concentrate_pellet_g":"float"}' },
      { id: 'ml_sheep_feed', key: 'sheep-feed-model', name: 'Ovine Growth & Wool Nutrition Model', cat: 'Sheep', ver: 'v0.6.0-pending', status: 'Model integration pending', ds_ver: 'CSWRI-Avikanagar-v1', acc: 84.1, f1: 0.82, rmse: 0.35, in_schema: '{"weight_kg":"float", "wool_cycle":"string"}', out_schema: '{"forage_dmi_kg":"float"}' },
      { id: 'ml_pig_feed', key: 'pig-feed-model', name: 'Swine FCR & Lysine Balance Model', cat: 'Pigs', ver: 'v0.5.2-pending', status: 'Model integration pending', ds_ver: 'NRC-Swine-Indianized', acc: 88.0, f1: 0.86, rmse: 0.22, in_schema: '{"age_weeks":"int", "weight_kg":"float"}', out_schema: '{"mash_feed_kg":"float"}' },
      { id: 'ml_poultry_feed', key: 'poultry-feed-model', name: 'Avian Broiler/Layer Ration Optimizer', cat: 'Poultry', ver: 'v0.8.0-dev', status: 'Model integration pending', ds_ver: 'CARI-Izatnagar-v2', acc: 93.1, f1: 0.91, rmse: 0.15, in_schema: '{"bird_type":"string", "age_days":"int"}', out_schema: '{"crude_protein_pct":"float", "me_kcal_per_kg":"float"}' },
      { id: 'ml_feed_quality', key: 'feed-quality-analysis', name: 'Spectroscopic NIR Feed Quality Prediction', cat: 'Feed Analysis', ver: 'v0.9.0-staging', status: 'Model integration pending', ds_ver: 'NIR-AgriFeed-2024', acc: 94.2, f1: 0.93, rmse: 0.19, in_schema: '{"nir_spectrum_bands":"array"}', out_schema: '{"cp_predicted":"float", "ndf_predicted":"float", "adf_predicted":"float"}' },
      { id: 'ml_silage_quality', key: 'silage-quality-prediction', name: 'Silage Fermentation & Flieg Score Classifier', cat: 'Silage Quality', ver: 'v1.0.1-preview', status: 'Model integration pending', ds_ver: 'Silage-Ferment-ICAR-v3', acc: 92.8, f1: 0.90, rmse: 0.25, in_schema: '{"ph":"float", "dry_matter_pct":"float", "ammonia_n_pct":"float", "lactic_acid_pct":"float"}', out_schema: '{"quality_class":"string", "stability_days":"int"}' }
    ];

    const insertModel = db.prepare(`
      INSERT INTO ml_models (id, model_key, name, animal_category, version, status, dataset_version, accuracy_pct, f1_score, rmse, input_schema, output_schema)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const m of models) {
      insertModel.run(m.id, m.key, m.name, m.cat, m.ver, m.status, m.ds_ver, m.acc, m.f1, m.rmse, m.in_schema, m.out_schema);
    }
  }

  // 7. Seed Sample Animals
  const animalCheck = db.prepare('SELECT count(*) as count FROM animals').get();
  if (animalCheck.count === 0) {
    const insertAnimal = db.prepare(`
      INSERT INTO animals (id, user_id, animal_tag, species, breed, age_months, body_weight_kg, sex, stage, milk_yield_liters, pregnancy_status, health_notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertAnimal.run('anim_001', 'usr_farmer_ramesh', 'IN-GJ-4401', 'Cattle', 'Gir', 42, 450, 'Female', 'Lactating', 14.5, '2nd Trimester', 'Vaccinated against FMD. Healthy appetite.');
    insertAnimal.run('anim_002', 'usr_farmer_ramesh', 'IN-GJ-4402', 'Cattle', 'Sahiwal', 36, 420, 'Female', 'Lactating', 12.0, 'None', 'Dewormed on 15th Sep.');
    insertAnimal.run('anim_003', 'usr_livestock_sunita', 'IN-HR-8812', 'Buffaloes', 'Murrah', 54, 580, 'Female', 'Lactating', 18.0, 'None', 'High butterfat 7.8%. Peak production stage.');
    insertAnimal.run('anim_004', 'usr_livestock_sunita', 'IN-HR-8815', 'Buffaloes', 'Murrah', 28, 510, 'Female', 'Dry & Pregnant', 0.0, '3rd Trimester', 'Requires steaming-up concentrate ration.');
    insertAnimal.run('anim_005', 'usr_farmer_ramesh', 'IN-GJ-GT01', 'Goats', 'Jamnapari', 18, 55, 'Female', 'Lactating', 2.8, 'None', 'Twin kids born in July.');
  }

  // 8. Seed Sample Silage / Feed Tests
  const silageCheck = db.prepare('SELECT count(*) as count FROM feed_silage_tests').get();
  if (silageCheck.count === 0) {
    const insertSilage = db.prepare(`
      INSERT INTO feed_silage_tests (id, user_id, sample_name, animal_species, silage_type, ph, dry_matter_pct, crude_protein_pct, crude_fibre_pct, moisture_pct, lactic_acid_pct, butyric_acid_pct, ammonia_n_pct, measurement_type, lab_verified, quality_grade, flieg_score, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertSilage.run('sil_001', 'usr_livestock_sunita', 'Maize Silage Pit #1 (45 Days Fermented)', 'Buffaloes', 'Corn / Maize Silage', 3.9, 32.5, 8.8, 24.2, 67.5, 6.2, 0.1, 7.2, 'Laboratory-verified', 1, 'Excellent (Flieg Score 92)', 92.0, 'Golden-yellow color, pleasant fruity aroma, pH 3.9 confirms lactic dominant fermentation.');
    insertSilage.run('sil_002', 'usr_farmer_ramesh', 'Sorghum-Cowpea Mixed Silage Bunker', 'Cattle', 'Sorghum + Legume Silage', 4.3, 30.0, 10.4, 27.5, 70.0, 4.8, 0.4, 9.5, 'User-entered', 0, 'Good (Flieg Score 78)', 78.5, 'Tested with digital pH meter on site. Good moisture retention.');
    insertSilage.run('sil_003', 'usr_researcher_meera', 'Napier Grass Ensiled with Molasses 3%', 'Cattle', 'Hybrid Napier Silage', 4.1, 28.0, 9.1, 31.0, 72.0, 5.5, 0.2, 8.0, 'Laboratory-verified', 1, 'Very Good (Flieg Score 85)', 85.0, 'ICAR certified forage lab testing batch #2024-N9.');
  }

  // 9. Seed Agricultural Marketing Mandi Prices
  const mandiCheck = db.prepare('SELECT count(*) as count FROM market_prices').get();
  if (mandiCheck.count === 0) {
    const prices = [
      { id: 'mandi_01', comm: 'Wheat (Sharbati)', cat: 'Cereals', mandi: 'Indore Mandi', dist: 'Indore', st: 'Madhya Pradesh', modal: 2650, min: 2450, max: 2820, date: '2026-10-10', src: 'Agmarknet APMC Daily Feed' },
      { id: 'mandi_02', comm: 'Paddy (Basmati 1121)', cat: 'Cereals', mandi: 'Karnal APMC', dist: 'Karnal', st: 'Haryana', modal: 3950, min: 3600, max: 4200, date: '2026-10-10', src: 'Agmarknet APMC Daily Feed' },
      { id: 'mandi_03', comm: 'Soybean (Yellow)', cat: 'Oilseeds', mandi: 'Ujjain Krishi Mandi', dist: 'Ujjain', st: 'Madhya Pradesh', modal: 4780, min: 4500, max: 4950, date: '2026-10-10', src: 'Agmarknet APMC Daily Feed' },
      { id: 'mandi_04', comm: 'Cotton (Medium Staple)', cat: 'Fiber', mandi: 'Rajkot APMC', dist: 'Rajkot', st: 'Gujarat', modal: 7420, min: 7100, max: 7750, date: '2026-10-09', src: 'Agmarknet APMC Daily Feed' },
      { id: 'mandi_05', comm: 'Mustard (Brassica)', cat: 'Oilseeds', mandi: 'Jaipur APMC', dist: 'Jaipur', st: 'Rajasthan', modal: 5650, min: 5350, max: 5890, date: '2026-10-10', src: 'Agmarknet APMC Daily Feed' },
      { id: 'mandi_06', comm: 'Corn / Maize (Feed Grade)', cat: 'Coarse Cereals', mandi: 'Davangere APMC', dist: 'Davangere', st: 'Karnataka', modal: 2320, min: 2150, max: 2480, date: '2026-10-09', src: 'Agmarknet APMC Daily Feed' },
      { id: 'mandi_07', comm: 'Green Fodder (Hybrid Napier)', cat: 'Livestock Fodder', mandi: 'Pune Fodder Market', dist: 'Pune', st: 'Maharashtra', modal: 280, min: 250, max: 320, date: '2026-10-10', src: 'User-submitted Local Feed Survey' },
      { id: 'mandi_08', comm: 'Maize Silage Bales (Wrapped 100kg)', cat: 'Processed Silage', mandi: 'Ludhiana Dairy Market', dist: 'Ludhiana', st: 'Punjab', modal: 550, min: 500, max: 600, date: '2026-10-10', src: 'User-submitted Local Feed Survey' }
    ];

    const insertPrice = db.prepare(`
      INSERT INTO market_prices (id, commodity, category, mandi_name, district, state, modal_price_per_quintal, min_price, max_price, price_date, data_source)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const p of prices) {
      insertPrice.run(p.id, p.comm, p.cat, p.mandi, p.dist, p.st, p.modal, p.min, p.max, p.date, p.src);
    }
  }

  // 10. Seed Marketplace Listings
  const marketCheck = db.prepare('SELECT count(*) as count FROM marketplace_listings').get();
  if (marketCheck.count === 0) {
    const listings = [
      { id: 'lst_001', uid: 'usr_farmer_ramesh', name: 'Ramesh Patel', title: 'Certified Gir Cow Heifer (First Calver)', cat: 'Livestock', price: 65000, qty: 1, unit: 'Animal', cond: 'Healthy, High Pedigree', loc: 'Anand', st: 'Gujarat', phone: '+91 98765 00001', desc: 'Mother yield 16L/day. Full vaccination record and breed certification from Saurashtra Gosamvardhan Trust.', status: 'Active', img: '/assets/gir_cow.jpg' },
      { id: 'lst_002', uid: 'usr_livestock_sunita', name: 'Sunita Sharma', title: 'Premium Ensiled Corn Silage Bales (500kg Stretch-Wrapped)', cat: 'Animal Feed & Silage', price: 2750, qty: 40, unit: 'Bales', cond: 'Freshly Fermented (45 Days)', loc: 'Karnal', st: 'Haryana', phone: '+91 98765 00002', desc: 'Prepared with Pioneer hybrid maize at 33% dry matter with imported bacterial inoculant. Flieg score 91.', status: 'Active', img: '/assets/silage_bale.jpg' },
      { id: 'lst_003', uid: 'usr_trader_gupta', name: 'Vikram Gupta', title: 'Commercial 5 HP Electric Chaff Cutter with Reverse Gear', cat: 'Machinery & Tools', price: 38500, qty: 3, unit: 'Units', cond: 'Brand New (1 Yr Warranty)', loc: 'Ludhiana', st: 'Punjab', phone: '+91 98765 00004', desc: 'Heavy-duty 3-roller feeding system, 800-1000 kg/hr cutting capacity for green and dry fodder.', status: 'Active', img: '/assets/chaff_cutter.jpg' },
      { id: 'lst_004', uid: 'usr_engineer_anand', name: 'Er. Anand Kulkarni', title: 'Automated Solar Smart Drip Controller (LoRaWAN / 4G)', cat: 'Irrigation & Precision Ag', price: 18500, qty: 5, unit: 'Sets', cond: 'Tested Prototype', loc: 'Pune', st: 'Maharashtra', phone: '+91 98765 00003', desc: 'Monitors soil moisture sensors and triggers solenoid valves. Solar-powered with 3-day battery backup.', status: 'Active', img: '/assets/smart_drip.jpg' }
    ];

    const insertListing = db.prepare(`
      INSERT INTO marketplace_listings (id, user_id, seller_name, title, category, price_inr, quantity, unit, product_condition, location, state, contact_phone, description, status, image_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const l of listings) {
      insertListing.run(l.id, l.uid, l.name, l.title, l.cat, l.price, l.qty, l.unit, l.cond, l.loc, l.st, l.phone, l.desc, l.status, l.img);
    }
  }

  // 11. Seed Agricultural Engineering Companies
  const compCheck = db.prepare('SELECT count(*) as count FROM agri_companies').get();
  if (compCheck.count === 0) {
    const companies = [
      { id: 'cmp_01', name: 'Jain Irrigation Systems Ltd.', cat: 'Drip & Sprinkler Systems', country: 'India', state: 'Maharashtra', city: 'Jalgaon', web: 'https://www.jains.com', email: 'jisl@jains.com', phone: '+91 257 2258011', prod: 'Micro-irrigation, Tissue Culture, Solar Pumps, HDPE Pipes', desc: 'Pioneer of micro-irrigation systems and water conservation technologies in India and over 120 nations.', verify: 1, app: 'Approved' },
      { id: 'cmp_02', name: 'Mahindra Farm Equipment (FES)', cat: 'Agricultural Machinery Manufacturers', country: 'India', state: 'Maharashtra', city: 'Mumbai', web: 'https://www.mahindratractor.com', email: 'tractorsupport@mahindra.com', phone: '+91 1800 425 6576', prod: 'Tractors (15HP to 75HP), Rotavators, Combine Harvesters, Implements', desc: 'World’s largest tractor manufacturer by volume, offering mechanization solutions for small to large farm holdings.', verify: 1, app: 'Approved' },
      { id: 'cmp_03', name: 'Escorts Kubota Limited', cat: 'Farm Automation & Robotics', country: 'India', state: 'Haryana', city: 'Faridabad', web: 'https://www.escortskubota.com', email: 'info@escortskubota.com', phone: '+91 129 2275321', prod: 'Farmtrac, Powertrac, Rice Transplanters, Precision Sprayers', desc: 'Joint venture between Escorts India and Kubota Japan engineering world-class mechanized rice farming and tractors.', verify: 1, app: 'Approved' },
      { id: 'cmp_04', name: 'DeLaval India Pvt. Ltd.', cat: 'Livestock & Dairy Equipment', country: 'India / Sweden', state: 'Maharashtra', city: 'Pune', web: 'https://www.delaval.com', email: 'delaval.india@delaval.com', phone: '+91 20 6625 7000', prod: 'Milking Parlors, Herd Management Systems, Milk Cooling Tanks, Automatic Scraping', desc: 'Global leader in dairy farming solutions with 135+ years of dairy engineering expertise.', verify: 1, app: 'Approved' },
      { id: 'cmp_05', name: 'Kirloskar Brothers Limited', cat: 'Irrigation & Pump Companies', country: 'India', state: 'Maharashtra', city: 'Pune', web: 'https://www.kirloskarpumps.com', email: 'kblinquiry@kbl.co.in', phone: '+91 20 2721 4444', prod: 'Submersible Pumps, Solar Agri Pumps, Openwell Monoblocs', desc: 'Indias pioneer pump engineering conglomerate serving irrigation projects and borewell pumping needs.', verify: 1, app: 'Approved' },
      { id: 'cmp_06', name: 'Fasal (Wiredcraft Agtech)', cat: 'Precision Agriculture & IoT', country: 'India', state: 'Karnataka', city: 'Bengaluru', web: 'https://fasal.co', email: 'hello@fasal.co', phone: '+91 80 4718 5555', prod: 'AI-powered Microclimate IoT Nodes, Disease Prediction Sensors, Irrigation AI', desc: 'Full-stack precision horticulture platform helping growers reduce irrigation water and predict pest attacks.', verify: 1, app: 'Approved' }
    ];

    const insertComp = db.prepare(`
      INSERT INTO agri_companies (id, name, category, country, state, city, website, contact_email, contact_phone, products, description, is_verified, approval_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const c of companies) {
      insertComp.run(c.id, c.name, c.cat, c.country, c.state, c.city, c.web, c.email, c.phone, c.prod, c.desc, c.verify, c.app);
    }
  }

  // 12. Seed Machinery & Equipment
  const machCheck = db.prepare('SELECT count(*) as count FROM machinery').get();
  if (machCheck.count === 0) {
    const machines = [
      { id: 'mch_01', name: 'Mahindra Yuvo Tech+ 575 DI', cat: 'Tractor', mfr: 'Mahindra & Mahindra', mdl: 'Yuvo Tech+ 575', hp: '47 HP @ 2000 RPM', price: '₹7.60 Lakh - ₹8.10 Lakh', apps: 'Plowing, Rotavator, Laser Leveler, Seed Drill, Haulage', specs: '4-Cylinder m-Zip engine, 12 Forward + 3 Reverse gears, 1700 kg hydraulic lift capacity', manual: 'https://mahindratractor.com/manuals/yuvo575.pdf' },
      { id: 'mch_02', name: 'Kubota Harvesking DC-68G', cat: 'Combine Harvester', mfr: 'Kubota Corporation', mdl: 'DC-68G Paddy Harvester', hp: '68 HP Turbocharged Diesel', price: '₹24.50 Lakh - ₹26.00 Lakh', apps: 'Rice Paddy harvesting in wet/marshy soil conditions', specs: 'Rubber crawler tracks with low ground pressure (0.20 kgf/cm²), 1250L grain tank capacity', manual: 'https://kubota.co.in/manuals/dc68g.pdf' },
      { id: 'mch_03', name: 'Round Silage Baler & Wrapper Machine', cat: 'Silage Equipment', mfr: 'Sonalika / Agromaster', mdl: 'SB-500 Pro Wrap', hp: 'Requires 40-50 HP Tractor PTO', price: '₹6.80 Lakh - ₹7.50 Lakh', apps: 'Baling green corn and napier grass into airtight 60-100 kg anaerobic silage bales', specs: 'Capacity 40-50 bales/hr, 2-layer stretch film wrapping, automatic twine binding', manual: 'https://agromaster.in/baler-manual.pdf' },
      { id: 'mch_04', name: 'Laser Land Leveler Transmitter & Scraper', cat: 'Land Leveling', mfr: 'Spectra Precision / Kisan Kraft', mdl: 'LL-800 Dual Grade', hp: 'Requires 50+ HP Tractor', price: '₹3.20 Lakh - ₹3.60 Lakh', apps: 'Precision soil leveling to save up to 30% irrigation water and improve crop emergence', specs: 'Laser range 800m diameter, 2.5m hydraulic scraper bucket, digital control receiver box', manual: 'https://kisankraft.com/laser-leveler.pdf' },
      { id: 'mch_05', name: 'IoTech Agri Drone Sprayer 16L', cat: 'Agricultural Drone', mfr: 'Marut Drones / IoTech', mdl: 'Kisan Drone 16X', hp: 'Lithium Smart Battery 22000 mAh', price: '₹4.50 Lakh (Subsidy up to 50%)', apps: 'Micro-spraying of bio-pesticides, micronutrients, and liquid urea in tall crops', specs: 'Spray swath 4-6m, radar terrain-following, obstacle avoidance, coverage 3-4 acres/hr', manual: 'https://marutdrones.com/specs.pdf' }
    ];

    const insertMach = db.prepare(`
      INSERT INTO machinery (id, name, category, manufacturer, model, hp_specs, price_estimate, applications, operating_specs, manual_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const m of machines) {
      insertMach.run(m.id, m.name, m.cat, m.mfr, m.mdl, m.hp, m.price, m.apps, m.specs, m.manual);
    }
  }

  // 13. Seed Government Schemes & Subsidies
  const schemeCheck = db.prepare('SELECT count(*) as count FROM govt_schemes').get();
  if (schemeCheck.count === 0) {
    const schemes = [
      { id: 'sch_01', title: 'Sub-Mission on Agricultural Mechanization (SMAM)', dept: 'Ministry of Agriculture & Farmers Welfare', ben: 'Small & Marginal Farmers, SC/ST, Women Farmers, FPOs', st: 'All India (Central + State)', cat: 'Farm Machinery Subsidies', ben_desc: '40% to 50% financial subsidy on purchase of tractors, rotavators, power tillers, drone sprayers and custom hiring centres.', elig: 'Valid Land Records (7/12, RoR), Aadhaar card, Bank passbook, Priority to women and smallholders.', docs: 'Aadhaar, Land ownership extract, Bank Passbook, Caste certificate if applicable, Quotation from authorized dealer.', url: 'https://agrimachinery.nic.in', deadline: 'Ongoing (Annual fiscal cycle)', last_ver: '2026-09-15' },
      { id: 'sch_02', title: 'National Livestock Mission (NLM) - Feed & Fodder Scheme', dept: 'Department of Animal Husbandry and Dairying', ben: 'Dairy Farmers, Livestock Cooperatives, Private Entrepreneurs, SHGs', st: 'All India', cat: 'Livestock & Silage Infrastructure', ben_desc: '50% capital subsidy up to ₹50 Lakh for establishing Total Mixed Ration (TMR) feed plants, Silage Making Units, and fodder seed production.', elig: 'Minimum owned or leased land for fodder cultivation, bank loan approval or self-financing capability.', docs: 'Detailed Project Report (DPR), Land deed, KYC documents, Net worth certificate, Bank sanction letter.', url: 'https://nlm.udyamimitra.in', deadline: 'Ongoing', last_ver: '2026-08-20' },
      { id: 'sch_03', title: 'Pradhan Mantri Krishi Sinchayee Yojana (PMKSY) - Per Drop More Crop', dept: 'Ministry of Water Resources & Agriculture', ben: 'All Categories of Farmers with Irrigable Land', st: 'All India', cat: 'Micro Irrigation (Drip & Sprinkler)', ben_desc: 'Up to 55% subsidy for Small & Marginal farmers and 45% for Other farmers on installing Drip and Sprinkler irrigation systems.', elig: 'Electricity connection / solar pump or borewell water source available on registered farm parcel.', docs: 'Aadhaar, Water source proof, Land registry 8A / 7/12, Soil test report, System design map from approved vendor.', url: 'https://pmksy.gov.in', deadline: 'Open rolling registration', last_ver: '2026-09-01' },
      { id: 'sch_04', title: 'Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)', dept: 'Ministry of Agriculture & Farmers Welfare', ben: 'All Landholding Farmer Families', st: 'All India', cat: 'Direct Income Support', ben_desc: '₹6,000 per year in 3 equal installments of ₹2,000 transferred directly via DBT into bank accounts.', elig: 'Farmer families owning cultivable land, subject to exclusion criteria (income tax payers and institutional holders excluded).', docs: 'Aadhaar, Land ownership details, Bank Account linked to Aadhaar (e-KYC verified).', url: 'https://pmkisan.gov.in', deadline: 'Continuous', last_ver: '2026-10-01' },
      { id: 'sch_05', title: 'Pradhan Mantri Fasal Bima Yojana (PMFBY)', dept: 'Ministry of Agriculture & Farmers Welfare', ben: 'Loanee & Non-loanee Farmers Growing Notified Crops', st: 'All India (State notified)', cat: 'Crop Insurance', ben_desc: 'Comprehensive risk insurance against non-preventable natural risks from pre-sowing to post-harvest. Farmer premium is only 2% for Kharif, 1.5% for Rabi, and 5% for Annual Commercial crops.', elig: 'Farmers cultivating notified food crops and oilseeds in notified insurance units.', docs: 'Sowing certificate, Land records, Bank account, Aadhaar, Crop insurance proposal form.', url: 'https://pmfby.gov.in', deadline: 'July 31 (Kharif) / Dec 31 (Rabi)', last_ver: '2026-09-28' }
    ];

    const insertScheme = db.prepare(`
      INSERT INTO govt_schemes (id, title, department, beneficiary, state, category, benefits, eligibility, documents_needed, apply_url, deadline, last_verified_date)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const s of schemes) {
      insertScheme.run(s.id, s.title, s.dept, s.ben, s.st, s.cat, s.ben_desc, s.elig, s.docs, s.url, s.deadline, s.last_ver);
    }
  }

  // 14. Seed Weather Stations & Climate Intelligence
  const weatherCheck = db.prepare('SELECT count(*) as count FROM weather_stations').get();
  if (weatherCheck.count === 0) {
    const stations = [
      { id: 'ws_01', loc: 'Karnal Agro-Met Observatory', st: 'Haryana', lat: 29.6857, lon: 76.9905, t: 28.5, h: 62.0, rain: 0.0, wind: 8.5, heat: 'Normal (THI 74 - Safe for Dairy Cattle)', drought: 'Low Risk (Soil Moisture Adequacy 78%)', water: '3.8 mm/day Evapotranspiration', fc: 'Partly cloudy, light north-westerly winds 10 km/h, rain probability 10% over next 48h', proj: 'CMIP6 Model Projection: +1.2°C temperature anomaly and +6% monsoon precipitation variability through 2035', src: 'IMD Agro-Meteorological Network & Open-Meteo Verified Feed', rec: '2026-10-10 18:00' },
      { id: 'ws_02', loc: 'Anand Agronomy Research Station', st: 'Gujarat', lat: 22.5645, lon: 72.9289, t: 32.2, h: 58.0, rain: 0.0, wind: 11.2, heat: 'Moderate Stress (THI 79 - Provide Shade & Electrolytes)', drought: 'Mild Stress (Canal Irrigation Active)', water: '4.5 mm/day Evapotranspiration', fc: 'Clear sunny sky, dry conditions, suitable for silage bunker opening and field drying', proj: 'High heat index episodes projected to increase by 8-12 days per annum under RCP 4.5', src: 'Anand Agricultural University Agromet Cell', rec: '2026-10-10 18:00' },
      { id: 'ws_03', loc: 'Pune Central Agricultural College', st: 'Maharashtra', lat: 18.5204, lon: 73.8567, t: 26.8, h: 71.0, rain: 4.2, wind: 9.0, heat: 'Low / Optimal (THI 72)', drought: 'Zero Risk (Ample Post-Monsoon Soil Reservoir)', water: '3.2 mm/day Evapotranspiration', fc: 'Scattered light showers during evening hours, moderate humidity, ideal for rabi sowing', proj: 'Rainfall distribution shifting towards intense short-duration convective pulses', src: 'IMD Pune Weather Forecasting Division', rec: '2026-10-10 18:00' }
    ];

    const insertWeather = db.prepare(`
      INSERT INTO weather_stations (id, location_name, state, latitude, longitude, temp_c, humidity_pct, rainfall_mm, wind_speed_kmh, heat_stress_index, drought_risk_indicator, crop_water_demand, forecast_summary, climate_projection_trend, data_source, recorded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const w of stations) {
      insertWeather.run(w.id, w.loc, w.st, w.lat, w.lon, w.t, w.h, w.rain, w.wind, w.heat, w.drought, w.water, w.fc, w.proj, w.src, w.rec);
    }
  }

  // 15. Seed External API Integrations Status
  const apiCheck = db.prepare('SELECT count(*) as count FROM api_integrations').get();
  if (apiCheck.count === 0) {
    const apis = [
      { id: 'api_sms', name: 'SMS OTP Gateway (DLT Certified)', ep: 'https://api.msg91.com/api/v5/otp', st: 'Simulated Mode (Dev Testing Active)', auth: 'Bearer API Key' },
      { id: 'api_agmarknet', name: 'Agmarknet APMC Mandi Rates', ep: 'https://api.data.gov.in/resource/9ef84268', st: 'Connected (Live Cache Sync)', auth: 'Govt Open Data API Key' },
      { id: 'api_meteo', name: 'Agro-Meteorology Global Service', ep: 'https://api.open-meteo.com/v1/forecast', st: 'Connected', auth: 'Public HTTPS' },
      { id: 'api_ml_python', name: 'Python ML Inference & Training Microservice', ep: 'http://localhost:5001/api/v1/predict', st: 'Pending Setup (Displaying fallback guidance)', auth: 'Internal mTLS / Token' }
    ];

    const insertApi = db.prepare(`
      INSERT INTO api_integrations (id, service_name, endpoint, status, auth_mode, last_ping)
      VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `);

    for (const a of apis) {
      insertApi.run(a.id, a.name, a.ep, a.st, a.auth);
    }
  }

  // 16. Seed Sample Dataset in Catalog
  const dsCheck = db.prepare('SELECT count(*) as count FROM datasets').get();
  if (dsCheck.count === 0) {
    const insertDs = db.prepare(`
      INSERT INTO datasets (id, name, animal_category, filename, file_size_bytes, row_count, columns_json, validation_status, missing_values_count, duplicate_count, uploaded_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertDs.run('ds_001', 'ICAR NDRI Bovine Lactation & Ration Trials 2024', 'Cattle', 'ndri_gir_lactation_ration_2024.csv', 142850, 1850, JSON.stringify(['animal_id', 'body_weight_kg', 'milk_yield_liters', 'fat_pct', 'dmi_kg', 'crude_protein_g', 'tdn_kg']), 'Validated', 0, 0, 'Dr. Rajesh Verma');
    insertDs.run('ds_002', 'Corn Silage Fermentation & Flieg Quality Index', 'Silage Quality', 'maize_silage_lab_trials.csv', 86400, 920, JSON.stringify(['sample_id', 'ph', 'dry_matter', 'lactic_acid', 'butyric_acid', 'ammonia_n', 'flieg_score', 'grade']), 'Validated', 2, 0, 'Dr. Meera Nambiar');
  }
}

initSchema();
seedData();

module.exports = {
  db,
  hashPassword
};
