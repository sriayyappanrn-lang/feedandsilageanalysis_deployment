/**
 * Plantiva Tech - AI Agricultural Assistant Advisory & Knowledge Engine
 * Implements rule-based domain reasoning, validated agronomic advisory,
 * and integration contracts for future LLM / PyTorch models.
 */

const AGRI_KNOWLEDGE_BASE = [
  {
    keywords: ['silage', 'flieg', 'fermentation', 'corn', 'pit', 'bunker'],
    category: 'Livestock & Feed Engineering',
    responseType: 'Verified Advisory',
    title: 'Optimal Silage Fermentation Protocol',
    content: `For high-quality maize (corn) silage:\n1. Harvest at 32-35% Dry Matter (1/2 to 2/3 milk-line in kernel).\n2. Chop length should be 10-15 mm with adequate kernel processing.\n3. Pack densely (>240 kg DM/m³) within 24-48 hours to expel oxygen.\n4. Seal immediately with dual-layer UV-stabilized polythene and weight down.\n5. Target pH after 21 days: 3.8 - 4.2. Avoid opening during active fermentation.`
  },
  {
    keywords: ['mastitis', 'swelling', 'udder', 'milk', 'clot', 'cow', 'buffalo'],
    category: 'Dairy Veterinary Health',
    responseType: 'Verified Advisory',
    title: 'Bovine Mastitis Detection & Management',
    content: `Key prevention protocols:\n1. Perform strip-cup test or California Mastitis Test (CMT) weekly.\n2. Post-milking teat dipping in 0.5% povidone-iodine reduces bacterial entry by 50%.\n3. Keep cows standing for 30-45 minutes post-milking by providing fresh feed.\n4. If clots or heat are detected in the quarter, isolate milk and consult your local veterinary surgeon immediately for culture sensitivity testing.`
  },
  {
    keywords: ['drip', 'irrigation', 'water', 'per drop', 'subsidy', 'pmksy'],
    category: 'Agricultural Engineering',
    responseType: 'Verified Advisory',
    title: 'Micro-Irrigation & PMKSY Subsidy Procedure',
    content: `Drip irrigation efficiency:\n1. Water savings: 40-60% compared to flood irrigation, with 30-40% fertilizer saving via fertigation.\n2. Subsidy: Under PMKSY 'Per Drop More Crop', small/marginal farmers receive up to 55% subsidy.\n3. Required Documents: Land title (7/12 or RoR), Aadhaar card, electricity/solar water pump connection proof.\n4. Design: Emitter spacing should match root spread (e.g., 40cm for vegetables, 1.5m for orchards).`
  },
  {
    keywords: ['yellow rust', 'wheat', 'fungus', 'stripes', 'leaves'],
    category: 'Crop Pathology',
    responseType: 'Verified Advisory',
    title: 'Wheat Yellow Rust (Puccinia striiformis) Advisory',
    content: `Diagnostic features: Yellow powdery pustules arranged in linear stripes on upper leaf surface.\nControl measures:\n1. Grow resistant cultivars (e.g., HD-2967, HD-3086, DBW-187).\n2. At initial appearance of symptoms, spray Propiconazole 25% EC @ 1 ml/liter of water.\n3. Repeat after 15 days if cool humid weather (10-18°C) persists.`
  },
  {
    keywords: ['bollworm', 'pink', 'cotton', 'pest', 'bt'],
    category: 'Pest Management',
    responseType: 'Verified Advisory',
    title: 'Cotton Pink Bollworm (Pectinophora gossypiella) IPM',
    content: `Integrated Pest Management (IPM):\n1. Install Delta pheromone traps @ 5 traps/acre for pest monitoring.\n2. ETL (Economic Threshold Level): 8 moths/trap/night for 3 consecutive days or 10% rosette flowers.\n3. Release egg parasitoid Trichogramma bactrae @ 60,000/acre at weekly intervals.\n4. Spray Chlorantraniliprole 18.5% SC @ 0.3 ml/L or Emamectin Benzoate 5% SG @ 0.4 g/L if threshold exceeded.`
  },
  {
    keywords: ['npk', 'fertilizer', 'soil', 'urea', 'dap', 'potash'],
    category: 'Soil & Plant Nutrition',
    responseType: 'Informational Calculation',
    title: 'Balanced Fertilizer Application Protocol',
    content: `Always base nutrient dosing on your official Soil Health Card.\nStandard recommendation guidelines for cereals:\n- Apply full Dose of Phosphorus (DAP/SSP) and Potash (MOP) as basal at sowing.\n- Split Nitrogen (Urea) into 3 equal splits: 1/3 basal, 1/3 at crown root initiation/tillering, 1/3 at panicle initiation.\n- Use Neem-coated urea to retard nitrogen volatilization and improve NUE by 10-15%.`
  }
];

function processAgriQuery(query, modelSelected = 'Rule-based Agricultural Advisory Engine') {
  const cleanQuery = (query || '').toLowerCase().trim();

  if (!cleanQuery) {
    return {
      success: false,
      error: 'Query string cannot be empty.'
    };
  }

  // Look for match in knowledge base
  let bestMatch = null;
  let maxScore = 0;

  for (const item of AGRI_KNOWLEDGE_BASE) {
    let score = 0;
    for (const kw of item.keywords) {
      if (cleanQuery.includes(kw)) {
        score += 1;
      }
    }
    if (score > maxScore) {
      maxScore = score;
      bestMatch = item;
    }
  }

  if (bestMatch && maxScore >= 1) {
    return {
      success: true,
      query,
      modelUsed: modelSelected,
      responseType: bestMatch.responseType, // Verified Advisory vs Informational
      category: bestMatch.category,
      title: bestMatch.title,
      response: bestMatch.content,
      disclaimer: 'This recommendation is generated by the Plantiva Agricultural Expert Knowledge Engine based on ICAR agronomic research. Always inspect field conditions before large-scale pesticide or medical interventions.'
    };
  }

  // Fallback agricultural response
  return {
    success: true,
    query,
    modelUsed: modelSelected,
    responseType: 'Informational Calculation',
    category: 'General Agronomic Guidance',
    title: 'Agronomic Guidance for: "' + query.slice(0, 40) + '..."',
    response: `Regarding your query about "${query}":\n\n1. Soil & Environment Context: Evaluate local weather, soil moisture, and current crop growth stage before making agronomic decisions.\n2. Livestock Health Notice: If this is an animal health emergency or drop in milk yield, please verify body temperature and consult your block veterinary officer.\n3. Feed & Silage Planning: You can use Plantiva's dedicated "Feed & Silage Recommendation" module to calculate precision rations tailored to your animal's weight, milk production, and stage.\n4. Market Rates: Refer to the "Agricultural Marketing" module to check current Mandi modal prices in your district.\n\n(Future AI Model Integration: An advanced domain-fine-tuned agricultural LLM is currently being prepared by the administrator in the Model Management console.)`,
    disclaimer: 'General informational response. Detailed specialized model integration pending in Admin Dashboard.'
  };
}

module.exports = {
  AGRI_KNOWLEDGE_BASE,
  processAgriQuery
};
