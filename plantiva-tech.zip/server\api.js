const { db, hashPassword } = require('./db.js');
const {
  checkRateLimit,
  logAudit,
  createSession,
  getSessionUser,
  destroySession,
  generateOtp,
  verifyOtp
} = require('./auth.js');
const {
  calculateNutrientRequirements,
  recommendRation,
  assessSilageQuality
} = require('./feedEngine.js');
const { processAgriQuery } = require('./assistantEngine.js');
const crypto = require('node:crypto');

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 5 * 1024 * 1024) { // 5MB limit
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        if (!body.trim()) return resolve({});
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON format'));
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store, no-cache, must-revalidate',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY'
  });
  res.end(JSON.stringify(data));
}

// Authentication & RBAC Middleware
function authenticateRequest(req) {
  const authHeader = req.headers['authorization'];
  let token = null;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7).trim();
  } else if (req.headers['cookie']) {
    const cookies = req.headers['cookie'].split(';');
    for (const c of cookies) {
      const [k, v] = c.trim().split('=');
      if (k === 'plantiva_session') {
        token = v;
        break;
      }
    }
  }

  if (!token) return null;
  return getSessionUser(token);
}

function handleApiRequest(req, res, pathname, queryParams, clientIp) {
  const method = req.method.toUpperCase();

  // 1. PUBLIC: Get Branding Config
  if (method === 'GET' && pathname === '/api/branding') {
    const branding = db.prepare('SELECT * FROM branding_config WHERE id = 1').get();
    return sendJson(res, 200, { success: true, branding });
  }

  // 2. PUBLIC: Request SMS OTP
  if (method === 'POST' && pathname === '/api/auth/otp/send') {
    return parseJsonBody(req).then(body => {
      const phone = String(body.phone || '').trim().replace(/[^0-9]/g, '');
      if (phone.length !== 10) {
        return sendJson(res, 400, { success: false, error: 'Please enter a valid 10-digit Indian mobile number.' });
      }

      try {
        const result = generateOtp(phone, clientIp);
        return sendJson(res, 200, result);
      } catch (err) {
        return sendJson(res, 429, { success: false, error: err.message });
      }
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 3. PUBLIC: Register New User
  if (method === 'POST' && pathname === '/api/auth/register') {
    return parseJsonBody(req).then(body => {
      const phone = String(body.phone || '').trim().replace(/[^0-9]/g, '');
      const fullName = String(body.full_name || '').trim();
      const password = String(body.password || '').trim();
      const role = String(body.role || 'Farmer').trim();
      const organization = String(body.organization || '').trim();
      const email = String(body.email || '').trim().toLowerCase();
      const otpCode = String(body.otp_code || '').trim();

      if (phone.length !== 10) {
        return sendJson(res, 400, { success: false, error: 'A valid 10-digit phone number is required.' });
      }
      if (!fullName) {
        return sendJson(res, 400, { success: false, error: 'Full name is required.' });
      }
      if (!password || password.length < 6) {
        return sendJson(res, 400, { success: false, error: 'Password must be at least 6 characters.' });
      }

      // Check if user already exists
      const existing = db.prepare('SELECT id FROM users WHERE phone = ?').get(phone);
      if (existing) {
        return sendJson(res, 400, { success: false, error: 'An account with this phone number already exists. Please log in.' });
      }

      // Verify OTP if supplied or require OTP
      try {
        verifyOtp(phone, otpCode, clientIp);
      } catch (otpErr) {
        return sendJson(res, 400, { success: false, error: 'OTP Verification Failed: ' + otpErr.message });
      }

      // Hash password
      const salt = crypto.randomBytes(16).toString('hex');
      const hash = hashPassword(password, salt);
      const userId = 'usr_' + crypto.randomBytes(8).toString('hex');

      // Valid roles
      const validRoles = [
        'Farmer',
        'Livestock Owner',
        'Agricultural Engineer',
        'Agricultural Business / Company',
        'Buyer / Seller / Trader',
        'Researcher / Student',
        'Agricultural Consultant',
        'General Registered User'
      ];
      const assignedRole = validRoles.includes(role) ? role : 'Farmer';

      db.prepare(`
        INSERT INTO users (id, phone, email, password_hash, salt, full_name, role, organization)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(userId, phone, email || null, hash, salt, fullName, assignedRole, organization || null);

      logAudit(userId, 'USER_REGISTERED', clientIp, { phone, role: assignedRole });

      // Create session
      const session = createSession(userId);
      const user = db.prepare('SELECT id, phone, email, full_name, role, organization FROM users WHERE id = ?').get(userId);

      return sendJson(res, 201, {
        success: true,
        message: 'Registration successful! Welcome to Plantiva Tech.',
        token: session.token,
        user
      });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 4. PUBLIC: Login (Phone + Password OR Phone + OTP)
  if (method === 'POST' && pathname === '/api/auth/login') {
    return parseJsonBody(req).then(body => {
      const phone = String(body.phone || '').trim().replace(/[^0-9]/g, '');
      const password = String(body.password || '').trim();
      const otpCode = String(body.otp_code || '').trim();
      const loginMethod = body.login_method || 'password'; // 'password' or 'otp'

      if (phone.length !== 10) {
        return sendJson(res, 400, { success: false, error: 'A valid 10-digit mobile number is required.' });
      }

      // Check login rate limit
      const rate = checkRateLimit(`login_${phone}`, 5, 5 * 60 * 1000);
      if (!rate.allowed) {
        return sendJson(res, 429, { success: false, error: `Too many login attempts. Please wait ${rate.resetInSec} seconds.` });
      }

      const user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
      if (!user) {
        return sendJson(res, 404, { success: false, error: 'No registered user found with this mobile number. Please register.' });
      }

      if (user.status !== 'active') {
        return sendJson(res, 403, { success: false, error: 'Account is deactivated. Please contact support.' });
      }

      if (loginMethod === 'otp') {
        try {
          verifyOtp(phone, otpCode, clientIp);
        } catch (otpErr) {
          return sendJson(res, 400, { success: false, error: otpErr.message });
        }
      } else {
        // Password authentication
        const computedHash = hashPassword(password, user.salt);
        if (computedHash !== user.password_hash) {
          logAudit(user.id, 'LOGIN_FAILED_PASSWORD', clientIp, { phone });
          return sendJson(res, 401, { success: false, error: 'Invalid password. Please check your credentials or login via OTP.' });
        }
      }

      logAudit(user.id, 'LOGIN_SUCCESS', clientIp, { method: loginMethod });
      const session = createSession(user.id);

      return sendJson(res, 200, {
        success: true,
        token: session.token,
        user: {
          id: user.id,
          phone: user.phone,
          email: user.email,
          full_name: user.full_name,
          role: user.role,
          organization: user.organization
        }
      });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 5. PUBLIC: Logout
  if (method === 'POST' && pathname === '/api/auth/logout') {
    const user = authenticateRequest(req);
    const authHeader = req.headers['authorization'];
    if (authHeader && authHeader.startsWith('Bearer ')) {
      destroySession(authHeader.substring(7).trim());
    }
    if (user) logAudit(user.id, 'LOGOUT', clientIp, {});
    return sendJson(res, 200, { success: true, message: 'Logged out successfully.' });
  }

  // ==========================================
  // PROTECTED ENDPOINTS (Mandatory Authentication)
  // ==========================================
  const currentUser = authenticateRequest(req);
  if (!currentUser) {
    return sendJson(res, 401, {
      success: false,
      error: 'Unauthorized: Mandatory authentication required. Please log in to access Plantiva Tech.'
    });
  }

  // 6. PROTECTED: Get Current User
  if (method === 'GET' && pathname === '/api/auth/me') {
    return sendJson(res, 200, { success: true, user: currentUser });
  }

  // 7. PROTECTED: Get Available Modules
  if (method === 'GET' && pathname === '/api/modules') {
    const modules = db.prepare(`
      SELECT * FROM modules_config 
      WHERE is_enabled = 1 
      ORDER BY sort_order ASC
    `).all();

    // Filter modules based on role
    const filtered = modules.filter(m => {
      if (m.allowed_roles === 'ALL') return true;
      const roles = m.allowed_roles.split(',').map(r => r.trim());
      return roles.includes(currentUser.role);
    });

    return sendJson(res, 200, { success: true, modules: filtered });
  }

  // 8. PROTECTED: Animals CRUD
  if (method === 'GET' && pathname === '/api/animals') {
    const species = queryParams.get('species');
    let animals;
    if (currentUser.role === 'Super Administrator' || currentUser.role === 'Researcher / Student') {
      if (species) {
        animals = db.prepare('SELECT * FROM animals WHERE species = ? ORDER BY created_at DESC').all(species);
      } else {
        animals = db.prepare('SELECT * FROM animals ORDER BY created_at DESC').all();
      }
    } else {
      if (species) {
        animals = db.prepare('SELECT * FROM animals WHERE user_id = ? AND species = ? ORDER BY created_at DESC').all(currentUser.id, species);
      } else {
        animals = db.prepare('SELECT * FROM animals WHERE user_id = ? ORDER BY created_at DESC').all(currentUser.id);
      }
    }
    return sendJson(res, 200, { success: true, animals });
  }

  if (method === 'POST' && pathname === '/api/animals') {
    return parseJsonBody(req).then(body => {
      const animalTag = String(body.animal_tag || '').trim();
      const species = String(body.species || 'Cattle').trim();
      const breed = String(body.breed || 'Gir').trim();
      const ageMonths = parseInt(body.age_months) || 24;
      const bodyWeightKg = parseFloat(body.body_weight_kg) || 400;
      const sex = String(body.sex || 'Female').trim();
      const stage = String(body.stage || 'Lactating').trim();
      const milkYield = parseFloat(body.milk_yield_liters) || 0;
      const pregnancyStatus = String(body.pregnancy_status || 'None').trim();
      const healthNotes = String(body.health_notes || '').trim();

      if (!animalTag) {
        return sendJson(res, 400, { success: false, error: 'Animal ID / Tag is required.' });
      }

      const id = 'anim_' + crypto.randomBytes(6).toString('hex');

      db.prepare(`
        INSERT INTO animals (id, user_id, animal_tag, species, breed, age_months, body_weight_kg, sex, stage, milk_yield_liters, pregnancy_status, health_notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, currentUser.id, animalTag, species, breed, ageMonths, bodyWeightKg, sex, stage, milkYield, pregnancyStatus, healthNotes);

      logAudit(currentUser.id, 'ANIMAL_ADDED', clientIp, { animalTag, species });

      const newAnimal = db.prepare('SELECT * FROM animals WHERE id = ?').get(id);
      return sendJson(res, 201, { success: true, animal: newAnimal });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 9. PROTECTED: Feed Calculation & Ration Optimizer
  if (method === 'POST' && pathname === '/api/feed/calculate') {
    return parseJsonBody(req).then(body => {
      const species = body.species || 'Cattle';
      const weight = parseFloat(body.body_weight_kg) || 450;
      const stage = body.stage || 'Lactating';
      const milk = parseFloat(body.milk_yield_liters) || 0;
      const fat = parseFloat(body.fat_pct) || 4.2;
      const isPregnant = body.pregnancy_status && body.pregnancy_status !== 'None';

      const requirements = calculateNutrientRequirements(species, weight, stage, milk, fat, isPregnant);
      return sendJson(res, 200, { success: true, requirements });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  if (method === 'POST' && pathname === '/api/feed/ration') {
    return parseJsonBody(req).then(body => {
      const species = body.species || 'Cattle';
      const weight = parseFloat(body.body_weight_kg) || 450;
      const stage = body.stage || 'Lactating';
      const milk = parseFloat(body.milk_yield_liters) || 0;
      const fat = parseFloat(body.fat_pct) || 4.2;
      const includeSilage = body.include_silage !== false;

      const recommendation = recommendRation(species, weight, stage, milk, fat, includeSilage);

      // Save ration record if animal specified
      if (body.animal_id) {
        const rationId = 'rat_' + crypto.randomBytes(6).toString('hex');
        db.prepare(`
          INSERT INTO feed_rations (id, user_id, animal_id, animal_tag, species, formula_type, ingredients_json, dmi_kg, cp_g, tdn_kg, total_cost_inr)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          rationId,
          currentUser.id,
          body.animal_id,
          body.animal_tag || 'ANIMAL',
          species,
          'ICAR 2013 Precision Formula',
          JSON.stringify(recommendation.rationFreshKg),
          recommendation.requirements.dmiKg,
          recommendation.requirements.cpGrams,
          recommendation.requirements.tdnKg,
          recommendation.costEstimate.totalDailyCostInr
        );
      }

      return sendJson(res, 200, { success: true, recommendation });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 10. PROTECTED: Silage Assessment CRUD
  if (method === 'GET' && pathname === '/api/silage/tests') {
    const tests = db.prepare('SELECT * FROM feed_silage_tests ORDER BY created_at DESC').all();
    return sendJson(res, 200, { success: true, tests });
  }

  if (method === 'POST' && pathname === '/api/silage/assess') {
    return parseJsonBody(req).then(body => {
      const assessment = assessSilageQuality(body);

      const id = 'sil_' + crypto.randomBytes(6).toString('hex');
      const sampleName = String(body.sample_name || 'Silage Sample ' + new Date().toLocaleDateString()).trim();
      const species = String(body.animal_species || 'Cattle').trim();
      const silageType = String(body.silage_type || 'Corn / Maize Silage').trim();
      const notes = String(body.notes || '').trim();

      db.prepare(`
        INSERT INTO feed_silage_tests (
          id, user_id, sample_name, animal_species, silage_type,
          ph, dry_matter_pct, crude_protein_pct, crude_fibre_pct,
          moisture_pct, lactic_acid_pct, butyric_acid_pct, ammonia_n_pct,
          measurement_type, lab_verified, quality_grade, flieg_score, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        id, currentUser.id, sampleName, species, silageType,
        assessment.parametersAnalyzed.ph,
        assessment.parametersAnalyzed.dryMatterPct,
        assessment.parametersAnalyzed.crudeProteinPct,
        parseFloat(body.crude_fibre_pct) || 25.0,
        assessment.parametersAnalyzed.moisturePct,
        assessment.parametersAnalyzed.lacticAcidPct,
        assessment.parametersAnalyzed.butyricAcidPct,
        assessment.parametersAnalyzed.ammoniaNitrogenPct,
        assessment.measurementType,
        assessment.labVerified ? 1 : 0,
        assessment.grade,
        assessment.fliegScore,
        notes
      );

      logAudit(currentUser.id, 'SILAGE_ASSESSED', clientIp, { sampleName, fliegScore: assessment.fliegScore });

      return sendJson(res, 201, {
        success: true,
        recordId: id,
        assessment
      });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 11. PROTECTED: ML Models Management & Dataset Upload
  if (method === 'GET' && pathname === '/api/ml/models') {
    const models = db.prepare('SELECT * FROM ml_models ORDER BY last_update DESC').all();
    return sendJson(res, 200, { success: true, models });
  }

  if (method === 'GET' && pathname === '/api/ml/datasets') {
    const datasets = db.prepare('SELECT * FROM datasets ORDER BY created_at DESC').all();
    return sendJson(res, 200, { success: true, datasets });
  }

  if (method === 'POST' && pathname === '/api/ml/datasets/upload') {
    return parseJsonBody(req).then(body => {
      const name = String(body.name || '').trim();
      const animalCategory = String(body.animal_category || 'Cattle').trim();
      const filename = String(body.filename || 'dataset.csv').trim();
      const rawData = String(body.raw_data || '').trim();

      if (!name || !rawData) {
        return sendJson(res, 400, { success: false, error: 'Dataset name and content are required.' });
      }

      // Parse CSV rows
      const lines = rawData.split('\n').map(l => l.trim()).filter(Boolean);
      if (lines.length < 2) {
        return sendJson(res, 400, { success: false, error: 'Dataset must have at least 1 header row and 1 data row.' });
      }

      const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
      const rowCount = lines.length - 1;
      let missingCount = 0;
      let duplicates = 0;
      const seen = new Set();

      for (let i = 1; i < lines.length; i++) {
        const row = lines[i];
        if (seen.has(row)) duplicates++;
        seen.add(row);
        const cols = row.split(',');
        if (cols.some(c => c.trim() === '' || c.trim().toLowerCase() === 'na' || c.trim().toLowerCase() === 'null')) {
          missingCount++;
        }
      }

      const id = 'ds_' + crypto.randomBytes(6).toString('hex');
      const fileSize = Buffer.byteLength(rawData, 'utf8');

      db.prepare(`
        INSERT INTO datasets (id, name, animal_category, filename, file_size_bytes, row_count, columns_json, validation_status, missing_values_count, duplicate_count, uploaded_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, name, animalCategory, filename, fileSize, rowCount, JSON.stringify(headers), 'Pending Approval', missingCount, duplicates, currentUser.full_name);

      logAudit(currentUser.id, 'DATASET_UPLOADED', clientIp, { datasetId: id, name, rowCount });

      return sendJson(res, 201, {
        success: true,
        message: 'Dataset uploaded and validated successfully. Under administrator review for model training approval.',
        dataset: {
          id,
          name,
          animalCategory,
          rowCount,
          columns: headers,
          missingValues: missingCount,
          duplicates,
          validationStatus: 'Pending Approval'
        }
      });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 12. PROTECTED: AI Agricultural Assistant
  if (method === 'POST' && pathname === '/api/assistant/chat') {
    return parseJsonBody(req).then(body => {
      const query = String(body.query || '').trim();
      const model = String(body.model || 'Rule-based Agricultural Advisory Engine').trim();

      const result = processAgriQuery(query, model);

      if (result.success) {
        const chatId = 'chat_' + crypto.randomBytes(6).toString('hex');
        db.prepare(`
          INSERT INTO assistant_chats (id, user_id, query, response, response_type, model_used)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(chatId, currentUser.id, query, result.response, result.responseType, model);
        result.chatId = chatId;
      }

      return sendJson(res, 200, result);
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  if (method === 'POST' && pathname === '/api/assistant/feedback') {
    return parseJsonBody(req).then(body => {
      const chatId = body.chat_id;
      const rating = parseInt(body.rating) || 1; // 1 = helpful, -1 = unhelpful
      if (chatId) {
        db.prepare('UPDATE assistant_chats SET rating = ? WHERE id = ? AND user_id = ?').run(rating, chatId, currentUser.id);
      }
      return sendJson(res, 200, { success: true, message: 'Feedback recorded.' });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 13. PROTECTED: Agricultural Marketing & Mandi Prices
  if (method === 'GET' && pathname === '/api/marketing/prices') {
    const commodity = queryParams.get('commodity');
    const state = queryParams.get('state');
    const search = queryParams.get('search');

    let query = 'SELECT * FROM market_prices WHERE 1=1';
    const params = [];

    if (commodity) {
      query += ' AND commodity LIKE ?';
      params.push(`%${commodity}%`);
    }
    if (state) {
      query += ' AND state LIKE ?';
      params.push(`%${state}%`);
    }
    if (search) {
      query += ' AND (commodity LIKE ? OR mandi_name LIKE ? OR district LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY price_date DESC, modal_price_per_quintal DESC';
    const prices = db.prepare(query).all(...params);
    return sendJson(res, 200, { success: true, prices });
  }

  if (method === 'POST' && pathname === '/api/marketing/prices') {
    return parseJsonBody(req).then(body => {
      const id = 'mandi_' + crypto.randomBytes(6).toString('hex');
      const commodity = String(body.commodity || '').trim();
      const category = String(body.category || 'General').trim();
      const mandi = String(body.mandi_name || '').trim();
      const dist = String(body.district || '').trim();
      const state = String(body.state || '').trim();
      const modal = parseFloat(body.modal_price) || 0;
      const min = parseFloat(body.min_price) || modal * 0.9;
      const max = parseFloat(body.max_price) || modal * 1.1;
      const date = String(body.price_date || new Date().toISOString().slice(0, 10)).trim();

      if (!commodity || !mandi || modal <= 0) {
        return sendJson(res, 400, { success: false, error: 'Commodity name, Mandi name and modal price are required.' });
      }

      db.prepare(`
        INSERT INTO market_prices (id, commodity, category, mandi_name, district, state, modal_price_per_quintal, min_price, max_price, price_date, data_source, is_verified)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, commodity, category, mandi, dist, state, modal, min, max, date, 'User-submitted Mandi Price', 0);

      logAudit(currentUser.id, 'MARKET_PRICE_SUBMITTED', clientIp, { commodity, mandi, modal });

      return sendJson(res, 201, { success: true, message: 'Price submitted successfully for review.' });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 14. PROTECTED: Buy & Sell Marketplace
  if (method === 'GET' && pathname === '/api/marketplace/listings') {
    const category = queryParams.get('category');
    let listings;
    if (category && category !== 'All') {
      listings = db.prepare("SELECT * FROM marketplace_listings WHERE category = ? AND status = 'Active' ORDER BY created_at DESC").all(category);
    } else {
      listings = db.prepare("SELECT * FROM marketplace_listings WHERE status = 'Active' ORDER BY created_at DESC").all();
    }
    return sendJson(res, 200, { success: true, listings });
  }

  if (method === 'POST' && pathname === '/api/marketplace/listings') {
    return parseJsonBody(req).then(body => {
      const title = String(body.title || '').trim();
      const category = String(body.category || 'Agricultural Produce').trim();
      const price = parseFloat(body.price_inr) || 0;
      const qty = parseFloat(body.quantity) || 1;
      const unit = String(body.unit || 'Kg').trim();
      const cond = String(body.product_condition || 'Good').trim();
      const loc = String(body.location || '').trim();
      const state = String(body.state || '').trim();
      const phone = String(body.contact_phone || currentUser.phone).trim();
      const desc = String(body.description || '').trim();
      const img = String(body.image_url || '/assets/agri_default.jpg').trim();

      if (!title || price <= 0) {
        return sendJson(res, 400, { success: false, error: 'Product title and price are required.' });
      }

      const id = 'lst_' + crypto.randomBytes(6).toString('hex');
      db.prepare(`
        INSERT INTO marketplace_listings (id, user_id, seller_name, title, category, price_inr, quantity, unit, product_condition, location, state, contact_phone, description, status, image_url)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?)
      `).run(id, currentUser.id, currentUser.full_name, title, category, price, qty, unit, cond, loc, state, phone, desc, img);

      logAudit(currentUser.id, 'MARKETPLACE_LISTING_CREATED', clientIp, { title, price });
      return sendJson(res, 201, { success: true, message: 'Marketplace listing published successfully!' });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  if (method === 'POST' && pathname === '/api/marketplace/enquire') {
    return parseJsonBody(req).then(body => {
      const listingId = body.listing_id;
      const buyerName = String(body.buyer_name || currentUser.full_name).trim();
      const buyerPhone = String(body.buyer_phone || currentUser.phone).trim();
      const message = String(body.message || '').trim();

      if (!listingId || !message) {
        return sendJson(res, 400, { success: false, error: 'Listing ID and enquiry message are required.' });
      }

      const id = 'enq_' + crypto.randomBytes(6).toString('hex');
      db.prepare(`
        INSERT INTO marketplace_enquiries (id, listing_id, buyer_name, buyer_phone, message)
        VALUES (?, ?, ?, ?, ?)
      `).run(id, listingId, buyerName, buyerPhone, message);

      return sendJson(res, 201, { success: true, message: 'Enquiry dispatched to seller.' });
    }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
  }

  // 15. PROTECTED: Agri Engineering Companies Directory
  if (method === 'GET' && pathname === '/api/companies') {
    const category = queryParams.get('category');
    let companies;
    if (category && category !== 'All') {
      companies = db.prepare("SELECT * FROM agri_companies WHERE category LIKE ? AND approval_status = 'Approved' ORDER BY name ASC").all(`%${category}%`);
    } else {
      companies = db.prepare("SELECT * FROM agri_companies WHERE approval_status = 'Approved' ORDER BY name ASC").all();
    }
    return sendJson(res, 200, { success: true, companies });
  }

  // 16. PROTECTED: Machinery & Equipment Directory
  if (method === 'GET' && pathname === '/api/machinery') {
    const category = queryParams.get('category');
    let machinery;
    if (category && category !== 'All') {
      machinery = db.prepare('SELECT * FROM machinery WHERE category LIKE ? ORDER BY name ASC').all(`%${category}%`);
    } else {
      machinery = db.prepare('SELECT * FROM machinery ORDER BY name ASC').all();
    }
    return sendJson(res, 200, { success: true, machinery });
  }

  // 17. PROTECTED: Government Schemes & Subsidies
  if (method === 'GET' && pathname === '/api/schemes') {
    const state = queryParams.get('state');
    const category = queryParams.get('category');

    let query = 'SELECT * FROM govt_schemes WHERE is_active = 1';
    const params = [];

    if (state && state !== 'All India') {
      query += " AND (state LIKE ? OR state = 'All India')";
      params.push(`%${state}%`);
    }
    if (category && category !== 'All') {
      query += ' AND category LIKE ?';
      params.push(`%${category}%`);
    }

    query += ' ORDER BY id ASC';
    const schemes = db.prepare(query).all(...params);
    return sendJson(res, 200, { success: true, schemes });
  }

  // 18. PROTECTED: Weather & Climate Models
  if (method === 'GET' && pathname === '/api/weather') {
    const stations = db.prepare('SELECT * FROM weather_stations ORDER BY recorded_at DESC').all();
    return sendJson(res, 200, { success: true, stations });
  }

  // ==========================================
  // SUPER ADMINISTRATOR ONLY ENDPOINTS
  // ==========================================
  const isSuperAdmin = currentUser.role === 'Super Administrator';

  if (pathname.startsWith('/api/admin/')) {
    if (!isSuperAdmin) {
      logAudit(currentUser.id, 'UNAUTHORIZED_ADMIN_ATTEMPT', clientIp, { path: pathname });
      return sendJson(res, 403, { success: false, error: 'Forbidden: Super Administrator privileges required.' });
    }

    // A. Branding & Theme Update
    if (method === 'PUT' && pathname === '/api/admin/branding') {
      return parseJsonBody(req).then(body => {
        db.prepare(`
          UPDATE branding_config SET
            website_name = COALESCE(?, website_name),
            tagline = COALESCE(?, tagline),
            logo_url = COALESCE(?, logo_url),
            favicon_url = COALESCE(?, favicon_url),
            primary_color = COALESCE(?, primary_color),
            secondary_color = COALESCE(?, secondary_color),
            accent_color = COALESCE(?, accent_color),
            font_family = COALESCE(?, font_family),
            support_email = COALESCE(?, support_email),
            support_phone = COALESCE(?, support_phone),
            footer_text = COALESCE(?, footer_text),
            hero_title = COALESCE(?, hero_title),
            hero_subtitle = COALESCE(?, hero_subtitle),
            updated_at = CURRENT_TIMESTAMP
          WHERE id = 1
        `).run(
          body.website_name || null,
          body.tagline || null,
          body.logo_url || null,
          body.favicon_url || null,
          body.primary_color || null,
          body.secondary_color || null,
          body.accent_color || null,
          body.font_family || null,
          body.support_email || null,
          body.support_phone || null,
          body.footer_text || null,
          body.hero_title || null,
          body.hero_subtitle || null
        );

        logAudit(currentUser.id, 'BRANDING_UPDATED', clientIp, body);
        const updated = db.prepare('SELECT * FROM branding_config WHERE id = 1').get();
        return sendJson(res, 200, { success: true, message: 'Branding updated successfully without rebuild!', branding: updated });
      }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
    }

    // B. Modules Configuration Update (Enable, disable, rename, reorder)
    if (method === 'PUT' && pathname === '/api/admin/modules') {
      return parseJsonBody(req).then(body => {
        const { module_key, name, description, is_enabled, sort_order, allowed_roles } = body;
        if (!module_key) {
          return sendJson(res, 400, { success: false, error: 'Module key is required.' });
        }

        db.prepare(`
          UPDATE modules_config SET
            name = COALESCE(?, name),
            description = COALESCE(?, description),
            is_enabled = COALESCE(?, is_enabled),
            sort_order = COALESCE(?, sort_order),
            allowed_roles = COALESCE(?, allowed_roles)
          WHERE module_key = ?
        `).run(name, description, is_enabled, sort_order, allowed_roles, module_key);

        logAudit(currentUser.id, 'MODULE_CONFIG_UPDATED', clientIp, { module_key, is_enabled });
        return sendJson(res, 200, { success: true, message: 'Module configuration updated.' });
      }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
    }

    // C. User Management
    if (method === 'GET' && pathname === '/api/admin/users') {
      const users = db.prepare('SELECT id, phone, email, full_name, role, organization, status, created_at, last_login FROM users ORDER BY created_at DESC').all();
      return sendJson(res, 200, { success: true, users });
    }

    if (method === 'PUT' && pathname.startsWith('/api/admin/users/')) {
      const targetUserId = pathname.split('/')[4];
      return parseJsonBody(req).then(body => {
        const { role, status } = body;
        db.prepare('UPDATE users SET role = COALESCE(?, role), status = COALESCE(?, status) WHERE id = ?').run(role, status, targetUserId);
        logAudit(currentUser.id, 'USER_UPDATED_BY_ADMIN', clientIp, { targetUserId, role, status });
        return sendJson(res, 200, { success: true, message: 'User updated successfully.' });
      }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
    }

    // D. Security Audit Logs
    if (method === 'GET' && pathname === '/api/admin/audit-logs') {
      const logs = db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100').all();
      return sendJson(res, 200, { success: true, logs });
    }

    // E. SMS Gateway Configuration
    if (method === 'GET' && pathname === '/api/admin/sms-config') {
      const config = db.prepare('SELECT * FROM sms_config WHERE id = 1').get();
      return sendJson(res, 200, { success: true, config });
    }

    if (method === 'PUT' && pathname === '/api/admin/sms-config') {
      return parseJsonBody(req).then(body => {
        const { provider, is_live, api_key, sender_id, dev_test_mode } = body;
        const maskedKey = api_key ? ('SK_LIVE_*******' + api_key.slice(-4)) : 'NOT_CONFIGURED';

        db.prepare(`
          UPDATE sms_config SET
            provider = COALESCE(?, provider),
            is_live = COALESCE(?, is_live),
            api_key_masked = ?,
            sender_id = COALESCE(?, sender_id),
            dev_test_mode = COALESCE(?, dev_test_mode),
            updated_at = CURRENT_TIMESTAMP
          WHERE id = 1
        `).run(provider, is_live, maskedKey, sender_id, dev_test_mode);

        logAudit(currentUser.id, 'SMS_CONFIG_UPDATED', clientIp, { provider, is_live, dev_test_mode });
        const updated = db.prepare('SELECT * FROM sms_config WHERE id = 1').get();
        return sendJson(res, 200, { success: true, message: 'SMS Gateway configuration updated.', config: updated });
      }).catch(err => sendJson(res, 400, { success: false, error: err.message }));
    }

    // F. External API Integrations
    if (method === 'GET' && pathname === '/api/admin/integrations') {
      const integrations = db.prepare('SELECT * FROM api_integrations').all();
      return sendJson(res, 200, { success: true, integrations });
    }

    // G. System Health & Database Backup Export
    if (method === 'GET' && pathname === '/api/admin/backup') {
      const tables = ['branding_config', 'users', 'modules_config', 'animal_categories', 'animals', 'feed_silage_tests', 'ml_models', 'datasets', 'market_prices', 'marketplace_listings', 'agri_companies', 'machinery', 'govt_schemes', 'weather_stations'];
      const backupData = {};
      for (const t of tables) {
        backupData[t] = db.prepare(`SELECT * FROM ${t}`).all();
      }
      return sendJson(res, 200, { success: true, timestamp: new Date().toISOString(), platform: 'Plantiva Tech', data: backupData });
    }

    if (method === 'GET' && pathname === '/api/admin/stats') {
      const stats = {
        totalUsers: db.prepare('SELECT count(*) as c FROM users').get().c,
        totalAnimals: db.prepare('SELECT count(*) as c FROM animals').get().c,
        totalSilageTests: db.prepare('SELECT count(*) as c FROM feed_silage_tests').get().c,
        totalListings: db.prepare('SELECT count(*) as c FROM marketplace_listings').get().c,
        totalMandiPrices: db.prepare('SELECT count(*) as c FROM market_prices').get().c,
        totalCompanies: db.prepare('SELECT count(*) as c FROM agri_companies').get().c,
        uptimeSeconds: Math.floor(process.uptime()),
        memoryUsageMb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024)
      };
      return sendJson(res, 200, { success: true, stats });
    }
  }

  // If endpoint is not matched
  return sendJson(res, 404, { success: false, error: 'API endpoint not found: ' + pathname });
}

module.exports = {
  handleApiRequest
};
