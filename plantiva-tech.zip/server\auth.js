const crypto = require('node:crypto');
const { db, hashPassword } = require('./db.js');

// Rate limiting in-memory store
const rateLimitMap = new Map();

function checkRateLimit(key, maxRequests = 10, windowMs = 60000) {
  const now = Date.now();
  const record = rateLimitMap.get(key) || { count: 0, resetTime: now + windowMs };

  if (now > record.resetTime) {
    record.count = 1;
    record.resetTime = now + windowMs;
    rateLimitMap.set(key, record);
    return { allowed: true, remaining: maxRequests - 1 };
  }

  if (record.count >= maxRequests) {
    return { allowed: false, remaining: 0, resetInSec: Math.ceil((record.resetTime - now) / 1000) };
  }

  record.count += 1;
  rateLimitMap.set(key, record);
  return { allowed: true, remaining: maxRequests - record.count };
}

// Audit logging helper
function logAudit(userId, action, ip, details) {
  try {
    const detailsStr = typeof details === 'object' ? JSON.stringify(details) : String(details || '');
    db.prepare(`
      INSERT INTO audit_logs (user_id, action, ip, details)
      VALUES (?, ?, ?, ?)
    `).run(userId || 'anonymous', action, ip || '127.0.0.1', detailsStr);
  } catch (err) {
    console.error('Audit log failed:', err.message);
  }
}

// Session generation & validation
function createSession(userId) {
  const token = 'plnt_' + crypto.randomBytes(32).toString('hex');
  // 24 hour expiry
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

  db.prepare(`
    INSERT INTO sessions (token, user_id, expires_at)
    VALUES (?, ?, ?)
  `).run(token, userId, expiresAt);

  // Update last login
  db.prepare(`
    UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
  `).run(userId);

  return { token, expiresAt };
}

function getSessionUser(token) {
  if (!token) return null;

  const session = db.prepare(`
    SELECT s.token, s.expires_at, u.id, u.phone, u.email, u.full_name, u.role, u.organization, u.status
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.token = ?
  `).get(token);

  if (!session) return null;

  if (new Date(session.expires_at) < new Date()) {
    // expired session
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    return null;
  }

  if (session.status !== 'active') {
    return null;
  }

  return session;
}

function destroySession(token) {
  if (!token) return;
  db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
}

// Generate secure 6-digit OTP
function generateOtp(phone, ip) {
  // Check rate limit: max 4 OTP requests per phone per 10 mins
  const rateKey = `otp_phone_${phone}`;
  const rate = checkRateLimit(rateKey, 4, 10 * 60 * 1000);
  if (!rate.allowed) {
    throw new Error(`Too many OTP requests. Please wait ${rate.resetInSec} seconds before retrying.`);
  }

  // 6 digit secure code
  const otpCode = Math.floor(100000 + crypto.randomInt(900000)).toString();
  const salt = 'plantiva_otp_salt';
  const otpHash = crypto.createHash('sha256').update(otpCode + salt).digest('hex');
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString(); // 5 min expiry

  const smsConfig = db.prepare('SELECT * FROM sms_config WHERE id = 1').get();

  // If live SMS gateway is configured, send via gateway API; otherwise store plain_otp_dev for development-only testing mode
  let devMode = true;
  let devOtpCode = null;

  if (smsConfig && smsConfig.is_live === 1 && smsConfig.api_key_masked !== 'NOT_CONFIGURED') {
    devMode = false;
    // In production, dispatch through configured SMS provider (e.g., MSG91/Twilio)
    // Never reveal OTP in response or db when live
  } else {
    devMode = true;
    devOtpCode = otpCode; // Saved in plain_otp_dev strictly for development testing mode
  }

  // Upsert OTP record
  db.prepare(`
    INSERT INTO otp_records (phone, otp_hash, plain_otp_dev, expires_at, attempts, resend_count)
    VALUES (?, ?, ?, ?, 0, 1)
    ON CONFLICT(phone) DO UPDATE SET
      otp_hash = excluded.otp_hash,
      plain_otp_dev = excluded.plain_otp_dev,
      expires_at = excluded.expires_at,
      attempts = 0,
      resend_count = otp_records.resend_count + 1
  `).run(phone, otpHash, devOtpCode, expiresAt);

  logAudit(null, 'OTP_REQUESTED', ip, { phone: phone.slice(-4), devMode });

  return {
    success: true,
    expiresInSeconds: 300,
    devMode,
    devTestOtp: devMode ? devOtpCode : undefined,
    message: devMode
      ? `[DEV TESTING MODE: Live SMS Gateway Not Configured] Test OTP: ${devOtpCode}. Valid for 5 minutes.`
      : `OTP dispatched to +91 ${phone.slice(0, 2)}****${phone.slice(-4)} via registered DLT SMS Gateway.`
  };
}

function verifyOtp(phone, otpCode, ip) {
  const record = db.prepare('SELECT * FROM otp_records WHERE phone = ?').get(phone);

  if (!record) {
    throw new Error('No active OTP found for this phone number. Please request a new OTP.');
  }

  if (new Date(record.expires_at) < new Date()) {
    db.prepare('DELETE FROM otp_records WHERE phone = ?').run(phone);
    throw new Error('OTP has expired. Please request a new OTP.');
  }

  if (record.attempts >= 3) {
    db.prepare('DELETE FROM otp_records WHERE phone = ?').run(phone);
    logAudit(null, 'OTP_BLOCKED_BRUTE_FORCE', ip, { phone: phone.slice(-4) });
    throw new Error('Maximum incorrect OTP attempts exceeded. This OTP has been invalidated for security.');
  }

  const salt = 'plantiva_otp_salt';
  const computedHash = crypto.createHash('sha256').update(String(otpCode).trim() + salt).digest('hex');

  if (computedHash !== record.otp_hash) {
    db.prepare('UPDATE otp_records SET attempts = attempts + 1 WHERE phone = ?').run(phone);
    const remaining = 2 - record.attempts;
    throw new Error(`Invalid OTP code. ${remaining > 0 ? remaining + ' attempt(s) remaining.' : 'OTP will now be invalidated.'}`);
  }

  // OTP verified successfully - purge record
  db.prepare('DELETE FROM otp_records WHERE phone = ?').run(phone);
  logAudit(null, 'OTP_VERIFIED_SUCCESS', ip, { phone: phone.slice(-4) });

  return true;
}

module.exports = {
  checkRateLimit,
  logAudit,
  createSession,
  getSessionUser,
  destroySession,
  generateOtp,
  verifyOtp
};
