@echo off
set ELECTRON_RUN_AS_NODE=1
set "PATH=%APPDATA%\Antigravity\bin;%PATH%"
title Plantiva Tech - Agricultural Technology Platform

echo =========================================================================
echo   PLANTIVA TECH - UNIVERSAL AGRICULTURAL TECHNOLOGY PLATFORM
echo   Official Agricultural & Livestock Intelligence Operating System
echo =========================================================================
echo.
echo Launching local server at http://localhost:3000 ...
echo Opening your web browser automatically...
echo.

start http://localhost:3000

if exist "%APPDATA%\Antigravity\bin\node.cmd" (
    call "%APPDATA%\Antigravity\bin\node.cmd" server\index.js
) else (
    "C:\Users\LENOVO\AppData\Local\Programs\antigravity\Antigravity.exe" server\index.js
)

pause
