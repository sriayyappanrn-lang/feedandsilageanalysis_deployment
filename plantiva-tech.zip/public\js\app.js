/**
 * Plantiva Tech - Main Application Orchestrator
 * Manages global UI elements: toast messages, modal dialogs, responsive drawer,
 * and boots the application once the user session is authenticated.
 */

// Toast Notifications System
function showToast(message, type = 'info', duration = 5000) {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `p-4 rounded-xl shadow-2xl text-xs font-semibold flex items-start space-x-3 pointer-events-auto transform transition-all duration-300 animate-fade-in border ${
    type === 'success' ? 'bg-emerald-950/95 border-emerald-500/40 text-emerald-200' :
    type === 'error' ? 'bg-red-950/95 border-red-500/40 text-red-200' :
    type === 'warning' ? 'bg-amber-950/95 border-amber-500/40 text-amber-200' :
    'bg-slate-900/95 border-slate-700 text-slate-200'
  }`;

  const icon = type === 'success' ? '✓' : type === 'error' ? '✕' : type === 'warning' ? '⚠' : 'ℹ';

  toast.innerHTML = `
    <span class="text-sm font-black flex-shrink-0 mt-0.5">${icon}</span>
    <div class="flex-1 leading-snug">${message}</div>
    <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-white ml-2">✕</button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// Global Modal Controller
function openModal(contentHtml) {
  const overlay = document.getElementById('modalOverlay');
  const content = document.getElementById('modalContent');
  if (overlay && content) {
    content.innerHTML = contentHtml;
    overlay.classList.remove('hidden');
  }
}

function closeModal() {
  const overlay = document.getElementById('modalOverlay');
  if (overlay) {
    overlay.classList.add('hidden');
  }
}

// Sidebar Drawer Toggle for Mobile / Tablet
function toggleSidebar() {
  const sidebar = document.getElementById('mainSidebar');
  const backdrop = document.getElementById('sidebarBackdrop');
  if (sidebar) {
    sidebar.classList.toggle('open');
    if (backdrop) {
      backdrop.classList.toggle('hidden');
    }
  }
}

// Boot application upon successful session verification
async function initAppDashboard(user) {
  // Update user profile badges in topbar
  const fullNameEl = document.getElementById('userFullName');
  const roleBadgeEl = document.getElementById('userRoleBadge');
  const avatarCharEl = document.getElementById('userAvatarChar');

  if (fullNameEl) fullNameEl.innerText = user.full_name || 'Farmer';
  if (roleBadgeEl) roleBadgeEl.innerText = user.role || 'Farmer';
  if (avatarCharEl) avatarCharEl.innerText = (user.full_name || 'P').charAt(0).toUpperCase();

  // Load modules list based on permissions and render navigation
  await loadModulesList();

  // Route to overview dashboard
  navigateToModule('overview');
}

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});
