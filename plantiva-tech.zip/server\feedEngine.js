/**
 * Plantiva Tech - Animal Feed & Silage Scientific Calculation Engine
 * Implements ICAR (Indian Council of Agricultural Research) & NRC (National Research Council)
 * nutritional standard equations for Indian tropical livestock.
 */

// Nutrient Composition Database for standard Indian tropical feedstuffs
const FEED_INGREDIENTS = {
  // Green Fodders
  'hybrid_napier': { name: 'Hybrid Napier (CO-4 / CO-5)', dm_pct: 20, cp_pct: 9.5, tdn_pct: 55, ca_pct: 0.55, p_pct: 0.32, cost_per_kg: 2.8, type: 'Green Fodder' },
  'maize_green': { name: 'Green Maize (Fodder Corn)', dm_pct: 25, cp_pct: 8.5, tdn_pct: 62, ca_pct: 0.45, p_pct: 0.28, cost_per_kg: 3.2, type: 'Green Fodder' },
  'sorghum_chari': { name: 'Sorghum (Chari)', dm_pct: 24, cp_pct: 7.2, tdn_pct: 56, ca_pct: 0.40, p_pct: 0.25, cost_per_kg: 2.6, type: 'Green Fodder' },
  'lucerne_alfalfa': { name: 'Lucerne / Alfalfa', dm_pct: 22, cp_pct: 18.5, tdn_pct: 60, ca_pct: 1.40, p_pct: 0.35, cost_per_kg: 4.5, type: 'Legume Green' },
  'berseem_clover': { name: 'Berseem (Egyptian Clover)', dm_pct: 18, cp_pct: 17.0, tdn_pct: 62, ca_pct: 1.50, p_pct: 0.38, cost_per_kg: 4.0, type: 'Legume Green' },
  
  // Dry Roughages
  'wheat_straw': { name: 'Wheat Straw (Bhusa)', dm_pct: 90, cp_pct: 3.2, tdn_pct: 42, ca_pct: 0.30, p_pct: 0.10, cost_per_kg: 8.5, type: 'Dry Roughage' },
  'paddy_straw': { name: 'Paddy Straw (Parali)', dm_pct: 88, cp_pct: 3.0, tdn_pct: 40, ca_pct: 0.25, p_pct: 0.08, cost_per_kg: 5.0, type: 'Dry Roughage' },
  
  // Silages
  'corn_silage': { name: 'Ensiled Maize Silage', dm_pct: 32, cp_pct: 8.8, tdn_pct: 66, ca_pct: 0.38, p_pct: 0.26, cost_per_kg: 5.5, type: 'Silage' },
  'sorghum_silage': { name: 'Sorghum Silage', dm_pct: 30, cp_pct: 7.5, tdn_pct: 58, ca_pct: 0.35, p_pct: 0.22, cost_per_kg: 4.8, type: 'Silage' },

  // Concentrates & Grains
  'dairy_compound_feed': { name: 'BIS Type-II Cattle Feed (20% CP)', dm_pct: 90, cp_pct: 20.0, tdn_pct: 72, ca_pct: 0.80, p_pct: 0.50, cost_per_kg: 28.0, type: 'Concentrate' },
  'mustard_cake': { name: 'Mustard / Rapeseed Cake (Sarson Khali)', dm_pct: 90, cp_pct: 35.0, tdn_pct: 74, ca_pct: 0.70, p_pct: 1.10, cost_per_kg: 32.0, type: 'Protein Concentrate' },
  'cottonseed_cake': { name: 'Cottonseed Cake (Binaula)', dm_pct: 91, cp_pct: 24.0, tdn_pct: 73, ca_pct: 0.30, p_pct: 0.85, cost_per_kg: 34.0, type: 'Protein Concentrate' },
  'wheat_bran': { name: 'Wheat Bran (Choker)', dm_pct: 88, cp_pct: 14.5, tdn_pct: 65, ca_pct: 0.15, p_pct: 1.15, cost_per_kg: 22.0, type: 'Energy Supplement' },
  'mineral_mixture': { name: 'Chelated Area-Specific Mineral Mix', dm_pct: 98, cp_pct: 0.0, tdn_pct: 0, ca_pct: 22.0, p_pct: 12.0, cost_per_kg: 75.0, type: 'Mineral' }
};

/**
 * Calculate Nutritional Requirements (ICAR 2013 Standards)
 */
function calculateNutrientRequirements(species, bodyWeightKg, stage, milkYieldLiters = 0, fatPct = 4.0, isPregnant = false) {
  const bw = Math.max(10, Number(bodyWeightKg) || 400);
  const milk = Math.max(0, Number(milkYieldLiters) || 0);
  const fat = Math.max(2.5, Number(fatPct) || 4.0);
  const sp = (species || 'Cattle').toLowerCase();

  let dmiKg = 0;
  let cpGrams = 0;
  let tdnKg = 0;
  let caGrams = 0;
  let pGrams = 0;
  let explanation = [];

  if (sp.includes('cattle') || sp.includes('cow')) {
    // Cattle: Maintenance DMI = 2.0% - 2.5% of Body Weight
    const baseDmi = bw * 0.022;
    // Plus 1 kg DMI per 3 kg milk
    const lactationDmi = milk * 0.33;
    dmiKg = baseDmi + lactationDmi;

    // Maintenance Crude Protein: ~350g per 400kg BW (approx 0.85g CP / kg BW)
    const maintCp = bw * 0.88;
    // Milk Production CP: ~75g CP per liter of 4% fat milk
    const milkCp = milk * (70 + (fat - 4.0) * 8);
    // Pregnancy requirement (last trimester): +200g CP
    const pregCp = isPregnant ? 220 : 0;
    cpGrams = maintCp + milkCp + pregCp;

    // TDN (Energy): Maintenance ~0.75% of BW, Milk ~0.35 kg TDN / kg milk
    const maintTdn = bw * 0.0075;
    const milkTdn = milk * (0.33 + (fat - 4.0) * 0.03);
    const pregTdn = isPregnant ? 1.0 : 0;
    tdnKg = maintTdn + milkTdn + pregTdn;

    caGrams = (bw * 0.05) + (milk * 2.8) + (isPregnant ? 15 : 0);
    pGrams = (bw * 0.035) + (milk * 2.0) + (isPregnant ? 10 : 0);

    explanation.push(`ICAR Standard: Cattle DMI calculated at 2.2% BW (${baseDmi.toFixed(1)}kg) + ${lactationDmi.toFixed(1)}kg for ${milk}L milk yield.`);
    explanation.push(`CP requirement: Maintenance ${maintCp.toFixed(0)}g + Lactation ${milkCp.toFixed(0)}g.`);
  } else if (sp.includes('buffalo')) {
    // Buffalo: Higher body weight & fat content (avg 6.5 - 8% fat)
    const baseDmi = bw * 0.025; // Buffaloes have higher rumen capacity (2.5% - 2.8% of BW)
    const lactationDmi = milk * 0.36;
    dmiKg = baseDmi + lactationDmi;

    const maintCp = bw * 0.95;
    const milkCp = milk * (85 + (fat - 6.5) * 10);
    const pregCp = isPregnant ? 250 : 0;
    cpGrams = maintCp + milkCp + pregCp;

    const maintTdn = bw * 0.008;
    const milkTdn = milk * (0.38 + (fat - 6.5) * 0.04);
    const pregTdn = isPregnant ? 1.2 : 0;
    tdnKg = maintTdn + milkTdn + pregTdn;

    caGrams = (bw * 0.06) + (milk * 3.4) + (isPregnant ? 18 : 0);
    pGrams = (bw * 0.04) + (milk * 2.4) + (isPregnant ? 12 : 0);

    explanation.push(`ICAR Standard: Murrah/Buffalo DMI at 2.5% BW (${baseDmi.toFixed(1)}kg) with higher energy coefficient for ${fat}% butterfat.`);
  } else if (sp.includes('goat')) {
    // Small Ruminant (Caprine): DMI 3.5% - 4.5% of body weight
    dmiKg = bw * 0.038 + (milk * 0.4);
    cpGrams = (bw * 1.1) + (milk * 70) + (isPregnant ? 35 : 0);
    tdnKg = (bw * 0.011) + (milk * 0.4);
    caGrams = 8 + milk * 3;
    pGrams = 5 + milk * 2;
    explanation.push(`ICAR Caprine Guideline: 3.8% BW dry matter basis with high roughage browsing coefficient.`);
  } else if (sp.includes('sheep')) {
    dmiKg = bw * 0.035;
    cpGrams = bw * 1.05 + (isPregnant ? 40 : 0);
    tdnKg = bw * 0.010;
    caGrams = 7;
    pGrams = 4.5;
    explanation.push(`ICAR Ovine Nutrient Model: Focused on wool follicle nutrition and body conditioning score.`);
  } else if (sp.includes('pig')) {
    dmiKg = Math.max(1.2, bw * 0.035);
    cpGrams = bw * 3.2; // High protein requirement for swine
    tdnKg = bw * 0.024;
    caGrams = 18;
    pGrams = 14;
    explanation.push(`NRC Swine Guideline: High-energy mash feeding with balanced amino acid spectrum.`);
  } else if (sp.includes('poultry')) {
    // Grams per bird basis
    dmiKg = Math.min(0.18, bw * 0.075); // approx 110-150g feed/bird/day
    cpGrams = dmiKg * 1000 * 0.18; // 18% CP
    tdnKg = dmiKg * 0.75;
    caGrams = 3.8; // High Ca for egg shell calcification
    pGrams = 0.55;
    explanation.push(`CARI Broiler/Layer Metric: Balanced ME 2800 kcal/kg with 18% Crude Protein.`);
  } else {
    dmiKg = bw * 0.025;
    cpGrams = bw * 0.9;
    tdnKg = bw * 0.008;
    caGrams = 25;
    pGrams = 18;
    explanation.push(`Generic tropical livestock baseline model.`);
  }

  return {
    dmiKg: Number(dmiKg.toFixed(2)),
    cpGrams: Number(cpGrams.toFixed(1)),
    tdnKg: Number(tdnKg.toFixed(2)),
    caGrams: Number(caGrams.toFixed(1)),
    pGrams: Number(pGrams.toFixed(1)),
    scientificBasis: 'ICAR Nutritional Requirements of Tropical Livestock & Dairy Animals',
    formulaType: 'Calculated Scientific Estimate (Rule-based ICAR standard, NOT AI/ML hallucination)',
    explanation
  };
}

/**
 * Generate Optimal Feed Ration & Daily Schedule
 */
function recommendRation(species, bodyWeightKg, stage, milkYieldLiters = 0, fatPct = 4.0, includeSilage = true) {
  const req = calculateNutrientRequirements(species, bodyWeightKg, stage, milkYieldLiters, fatPct);
  const totalDmi = req.dmiKg;
  const sp = (species || 'Cattle').toLowerCase();

  // Typical Indian Dairy Ration Split:
  // 60-70% Roughage (Green Fodder + Dry Fodder / Silage) and 30-40% Concentrates
  let concentrateDmi = 0;
  let silageDmi = 0;
  let greenFodderDmi = 0;
  let dryStrawDmi = 0;

  if (sp.includes('poultry') || sp.includes('pig')) {
    // Monogastric
    concentrateDmi = totalDmi;
  } else {
    // Ruminants
    if (milkYieldLiters > 0) {
      // 1 kg concentrate for every 2.5 - 3 kg milk + 1.5 kg maintenance concentrate
      concentrateDmi = Math.min(totalDmi * 0.45, (1.5 + milkYieldLiters * 0.35) * 0.9);
    } else {
      concentrateDmi = Math.min(totalDmi * 0.25, 1.5 * 0.9);
    }

    const remainingRoughageDmi = totalDmi - concentrateDmi;

    if (includeSilage) {
      // 40% Silage DM, 35% Green Fodder DM, 25% Dry Straw DM
      silageDmi = remainingRoughageDmi * 0.40;
      greenFodderDmi = remainingRoughageDmi * 0.35;
      dryStrawDmi = remainingRoughageDmi * 0.25;
    } else {
      greenFodderDmi = remainingRoughageDmi * 0.65;
      dryStrawDmi = remainingRoughageDmi * 0.35;
    }
  }

  // Convert Dry Matter basis to As-Fed Fresh Weight basis:
  // Fresh Weight = DM Weight / (DM% / 100)
  const freshSilageKg = silageDmi > 0 ? silageDmi / 0.32 : 0; // Silage ~32% DM
  const freshGreenFodderKg = greenFodderDmi > 0 ? greenFodderDmi / 0.22 : 0; // Green ~22% DM
  const freshDryStrawKg = dryStrawDmi > 0 ? dryStrawDmi / 0.90 : 0; // Straw ~90% DM
  const freshConcentrateKg = concentrateDmi > 0 ? concentrateDmi / 0.90 : 0; // Mash/Pellet ~90% DM
  const mineralMixGrams = sp.includes('buffalo') || sp.includes('cattle') ? 50 + milkYieldLiters * 3 : 15;
  const commonSaltGrams = sp.includes('buffalo') || sp.includes('cattle') ? 40 : 10;

  // Cost Estimation (in Indian Rupees INR)
  const silageCost = freshSilageKg * FEED_INGREDIENTS['corn_silage'].cost_per_kg;
  const greenCost = freshGreenFodderKg * FEED_INGREDIENTS['hybrid_napier'].cost_per_kg;
  const strawCost = freshDryStrawKg * FEED_INGREDIENTS['wheat_straw'].cost_per_kg;
  const concCost = freshConcentrateKg * FEED_INGREDIENTS['dairy_compound_feed'].cost_per_kg;
  const mineralCost = (mineralMixGrams / 1000) * FEED_INGREDIENTS['mineral_mixture'].cost_per_kg;
  const totalDailyCostInr = silageCost + greenCost + strawCost + concCost + mineralCost;

  return {
    requirements: req,
    rationFreshKg: {
      silageCornKg: Number(freshSilageKg.toFixed(1)),
      greenFodderKg: Number(freshGreenFodderKg.toFixed(1)),
      dryStrawKg: Number(freshDryStrawKg.toFixed(1)),
      compoundConcentrateKg: Number(freshConcentrateKg.toFixed(1)),
      mineralMixGrams: Math.round(mineralMixGrams),
      commonSaltGrams: Math.round(commonSaltGrams)
    },
    costEstimate: {
      totalDailyCostInr: Number(totalDailyCostInr.toFixed(2)),
      costPerLiterMilkInr: milkYieldLiters > 0 ? Number((totalDailyCostInr / milkYieldLiters).toFixed(2)) : null,
      breakdown: {
        silage: Number(silageCost.toFixed(1)),
        greenFodder: Number(greenCost.toFixed(1)),
        dryStraw: Number(strawCost.toFixed(1)),
        concentrate: Number(concCost.toFixed(1)),
        minerals: Number(mineralCost.toFixed(1))
      }
    },
    feedingSchedule: [
      { time: '06:00 AM', task: 'Milking & Morning Concentrate', details: `${(freshConcentrateKg * 0.5).toFixed(1)} kg Concentrate + ${(mineralMixGrams * 0.5).toFixed(0)}g Mineral Mix` },
      { time: '08:00 AM', task: 'Morning Forage Feeding', details: `${(freshSilageKg * 0.6).toFixed(1)} kg Silage + ${(freshDryStrawKg * 0.5).toFixed(1)} kg Dry Straw (chaffed & mixed)` },
      { time: '01:00 PM', task: 'Midday Green Feeding & Water', details: `${(freshGreenFodderKg * 0.5).toFixed(1)} kg Fresh Green Napier + Ad-libitum clean drinking water` },
      { time: '05:30 PM', task: 'Evening Milking & Concentrate', details: `${(freshConcentrateKg * 0.5).toFixed(1)} kg Concentrate + ${(mineralMixGrams * 0.5).toFixed(0)}g Mineral Mix` },
      { time: '07:00 PM', task: 'Night Roughage Feeding', details: `${(freshSilageKg * 0.4).toFixed(1)} kg Silage + ${(freshGreenFodderKg * 0.5).toFixed(1)} kg Green + ${(freshDryStrawKg * 0.5).toFixed(1)} kg Straw` }
    ]
  };
}

/**
 * Silage Quality Assessment & Flieg Score Calculator
 * Based on Flieg-Zimmer Index and ICAR Silage Quality Standards
 */
function assessSilageQuality(params) {
  const ph = Number(params.ph) || 4.2;
  const dm = Number(params.dry_matter_pct) || 30.0;
  const moisture = Number(params.moisture_pct) || (100 - dm);
  const cp = Number(params.crude_protein_pct) || 8.5;
  const lactic = Number(params.lactic_acid_pct) || 5.0;
  const butyric = Number(params.butyric_acid_pct) || 0.1;
  const ammoniaN = Number(params.ammonia_n_pct) || 7.0; // NH3-N as % of Total N
  const measurementType = params.measurement_type || 'User-entered';
  const labVerified = Boolean(params.lab_verified);

  // Standard Flieg Index Formula:
  // Flieg Score = 220 + (2 * DryMatter% - 15) - 40 * pH
  let fliegScore = 220 + (2 * dm - 15) - (40 * ph);

  // Penalize for high butyric acid (spoilage indicator)
  if (butyric > 0.3) {
    fliegScore -= (butyric - 0.3) * 20;
  }
  // Penalize for high ammonia nitrogen (protein breakdown indicator)
  if (ammoniaN > 10.0) {
    fliegScore -= (ammoniaN - 10.0) * 3;
  }

  fliegScore = Math.max(0, Math.min(100, fliegScore));

  let grade = 'Fair / Average';
  let colorBadge = 'text-amber-500';
  let safetyVerdict = 'Suitable with caution';
  let observations = [];

  if (fliegScore >= 85) {
    grade = 'Excellent (Class I)';
    colorBadge = 'text-emerald-500';
    safetyVerdict = 'Highly safe and nutritious forage for high-yield dairy animals.';
    observations.push('Lactic acid fermentation is dominant, ensuring rapid drop in pH and maximum nutrient preservation.');
  } else if (fliegScore >= 70) {
    grade = 'Very Good (Class II)';
    colorBadge = 'text-green-500';
    safetyVerdict = 'Safe for general herd feeding.';
    observations.push('Satisfactory fermentation. Good preservation of soluble carbohydrates.');
  } else if (fliegScore >= 50) {
    grade = 'Good to Moderate (Class III)';
    colorBadge = 'text-yellow-500';
    safetyVerdict = 'Acceptable for maintenance herds. Avoid feeding to high-yielding cows in peak lactation.';
    observations.push('Sub-optimal pH or moisture level noted. Slight secondary fermentation risk.');
  } else if (fliegScore >= 30) {
    grade = 'Poor (Class IV)';
    colorBadge = 'text-orange-500';
    safetyVerdict = 'Low quality. Risk of digestive upsets. Feed in limited quantities only.';
    observations.push('Clostridial activity suspected due to elevated butyric acid or high pH > 4.8.');
  } else {
    grade = 'Very Poor / Spoiled (Class V)';
    colorBadge = 'text-red-500';
    safetyVerdict = 'UNSAFE. Silage has undergone putrefaction or molding. DO NOT FEED.';
    observations.push('Severe spoilage. High risk of mycotoxins and listeriosis.');
  }

  if (ph > 4.5 && dm < 28) {
    observations.push('WARNING: Wet silage (DM < 28%) with pH > 4.5 is at high risk of Clostridium butyricum proliferation.');
  }

  if (lactic / (butyric + 0.01) < 3.0) {
    observations.push('Low Lactic-to-Butyric acid ratio indicates sluggish initial fermentation.');
  }

  return {
    fliegScore: Number(fliegScore.toFixed(1)),
    grade,
    safetyVerdict,
    measurementType, // User-entered, Laboratory-verified, Calculated estimate, AI/ML prediction
    labVerified,
    parametersAnalyzed: {
      ph,
      dryMatterPct: dm,
      moisturePct: moisture,
      crudeProteinPct: cp,
      lacticAcidPct: lactic,
      butyricAcidPct: butyric,
      ammoniaNitrogenPct: ammoniaN
    },
    observations,
    disclaimer: 'Note: Biological feed safety cannot be verified by photo visual inspection alone. Always obtain physical lab moisture and volatile fatty acid tests for commercial herds.'
  };
}

module.exports = {
  FEED_INGREDIENTS,
  calculateNutrientRequirements,
  recommendRation,
  assessSilageQuality
};
