/**
 * Plantiva Tech - Modular Universal Agriculture System
 * Implements interactive renderers and workflows for all 19 agricultural technology modules.
 */

let activeModulesList = [];
let currentModuleKey = 'overview';

// Navigation Manager
async function loadModulesList() {
  try {
    const res = await apiFetch('/api/modules');
    const data = await res.json();
    if (data.success && data.modules) {
      activeModulesList = data.modules;
      renderSidebarNavigation();
    }
  } catch (err) {
    console.error('Failed to load modules list:', err);
  }
}

function renderSidebarNavigation() {
  const container = document.getElementById('sidebarNavList');
  if (!container) return;

  const countBadge = document.getElementById('activeModulesCountBadge');
  if (countBadge) countBadge.innerText = `${activeModulesList.length} Active`;

  let html = `
    <button onclick="navigateToModule('overview')" class="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${currentModuleKey === 'overview' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800'}">
      <div class="flex items-center space-x-2.5">
        <svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
        <span>Overview Dashboard</span>
      </div>
    </button>
  `;

  for (const m of activeModulesList) {
    const isActive = currentModuleKey === m.module_key;
    const badgeHtml = m.badge ? `<span class="text-[9px] px-1.5 py-0.5 rounded-md ${isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'} font-medium">${m.badge}</span>` : '';

    html += `
      <button onclick="navigateToModule('${m.module_key}')" class="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${isActive ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800'}">
        <div class="flex items-center space-x-2.5 truncate">
          <span class="text-base">${getModuleEmoji(m.module_key)}</span>
          <span class="truncate">${m.name}</span>
        </div>
        ${badgeHtml}
      </button>
    `;
  }

  container.innerHTML = html;

  // Show Admin button in footer if Super Admin
  const adminPill = document.getElementById('adminDirectPill');
  if (adminPill && currentUserSession && currentUserSession.role === 'Super Administrator') {
    adminPill.classList.remove('hidden');
  }
}

function getModuleEmoji(key) {
  const map = {
    'feed-silage': '🌾',
    'livestock': '🐄',
    'assistant': '🤖',
    'marketing': '📈',
    'marketplace': '🛒',
    'companies': '🏢',
    'machinery': '🚜',
    'schemes': '🏛️',
    'climate': '🌤️',
    'crop-farm': '🌱',
    'soil-water': '🧪',
    'irrigation': '💧',
    'precision-agri': '🎯',
    'post-harvest': '📦',
    'research-data': '📊',
    'analytics': '📉',
    'profile': '👤',
    'notifications': '🔔',
    'admin': '🛡️'
  };
  return map[key] || '🌿';
}

function navigateToModule(key) {
  currentModuleKey = key;
  renderSidebarNavigation();

  // Close mobile sidebar if open
  const sidebar = document.getElementById('mainSidebar');
  const backdrop = document.getElementById('sidebarBackdrop');
  if (sidebar && sidebar.classList.contains('open')) {
    sidebar.classList.remove('open');
    if (backdrop) backdrop.classList.add('hidden');
  }

  const main = document.getElementById('mainContentArea');
  if (!main) return;

  switch (key) {
    case 'overview':
      renderOverviewDashboard(main);
      break;
    case 'feed-silage':
      renderFeedSilageModule(main);
      break;
    case 'livestock':
      renderLivestockModule(main);
      break;
    case 'assistant':
      renderAssistantModule(main);
      break;
    case 'marketing':
      renderMarketingModule(main);
      break;
    case 'marketplace':
      renderMarketplaceModule(main);
      break;
    case 'companies':
      renderCompaniesModule(main);
      break;
    case 'machinery':
      renderMachineryModule(main);
      break;
    case 'schemes':
      renderSchemesModule(main);
      break;
    case 'climate':
      renderClimateModule(main);
      break;
    case 'crop-farm':
      renderCropFarmModule(main);
      break;
    case 'soil-water':
      renderSoilWaterModule(main);
      break;
    case 'irrigation':
      renderIrrigationModule(main);
      break;
    case 'precision-agri':
      renderPrecisionAgriModule(main);
      break;
    case 'post-harvest':
      renderPostHarvestModule(main);
      break;
    case 'research-data':
      renderResearchDataModule(main);
      break;
    case 'analytics':
      renderAnalyticsModule(main);
      break;
    case 'profile':
      renderProfileModule(main);
      break;
    case 'notifications':
      renderNotificationsModule(main);
      break;
    case 'admin':
      renderAdminModule(main);
      break;
    default:
      main.innerHTML = `<div class="p-8 text-center"><h2 class="text-xl font-bold">Module: ${key}</h2><p class="text-slate-400 mt-2">Module is loaded and ready.</p></div>`;
  }
}

// =========================================================================
// MODULE 0: OVERVIEW / PERSONALIZED ROLE DASHBOARD
// =========================================================================
function renderOverviewDashboard(container) {
  const role = currentUserSession ? currentUserSession.role : 'Farmer';
  const name = currentUserSession ? currentUserSession.full_name : 'Valued User';

  container.innerHTML = `
    <div class="space-y-6 animate-fade-in">
      <!-- Role Hero Banner -->
      <div class="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border border-emerald-500/20 p-6 sm:p-8">
        <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div class="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-3">
              <span>🌾 Role: ${role}</span>
              <span>•</span>
              <span>ICAR Verified Standards</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-white">Welcome, ${name}</h1>
            <p class="text-slate-400 text-xs sm:text-sm mt-1 max-w-2xl">
              Plantiva Tech Universal Agricultural Platform — Personalized dashboard for cattle feed optimization, Mandi market discovery, precision agronomy, and agricultural engineering directories.
            </p>
          </div>
          <div class="flex flex-wrap gap-2">
            <button onclick="navigateToModule('feed-silage')" class="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-900/40 flex items-center space-x-1.5 transition-all">
              <span>🌾 Precision Feed Calculator</span>
            </button>
            <button onclick="navigateToModule('assistant')" class="px-4 py-2.5 bg-purple-900/60 hover:bg-purple-800 text-purple-200 border border-purple-500/40 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all">
              <span>🤖 AI Agritech Assistant</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Quick Metrics Strip -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="glass-panel rounded-2xl p-4 border border-slate-800 flex items-center space-x-3.5">
          <div class="p-3 rounded-xl bg-emerald-950 text-emerald-400 text-xl font-bold">🐄</div>
          <div>
            <div class="text-[11px] text-slate-400 uppercase font-semibold">Active Livestock</div>
            <div class="text-xl font-extrabold text-white">5 Tagged Animals</div>
            <div class="text-[10px] text-emerald-400">Gir, Murrah &amp; Jamnapari</div>
          </div>
        </div>

        <div class="glass-panel rounded-2xl p-4 border border-slate-800 flex items-center space-x-3.5">
          <div class="p-3 rounded-xl bg-amber-950 text-amber-400 text-xl font-bold">🧪</div>
          <div>
            <div class="text-[11px] text-slate-400 uppercase font-semibold">Silage Quality Tests</div>
            <div class="text-xl font-extrabold text-white">Flieg Score: 92</div>
            <div class="text-[10px] text-emerald-400">Class I (Excellent Maize)</div>
          </div>
        </div>

        <div class="glass-panel rounded-2xl p-4 border border-slate-800 flex items-center space-x-3.5">
          <div class="p-3 rounded-xl bg-blue-950 text-blue-400 text-xl font-bold">📈</div>
          <div>
            <div class="text-[11px] text-slate-400 uppercase font-semibold">Mandi Rate Feed</div>
            <div class="text-xl font-extrabold text-white">₹2,650 / Qtl</div>
            <div class="text-[10px] text-blue-400">Indore Sharbati Wheat</div>
          </div>
        </div>

        <div class="glass-panel rounded-2xl p-4 border border-slate-800 flex items-center space-x-3.5">
          <div class="p-3 rounded-xl bg-sky-950 text-sky-400 text-xl font-bold">🌤️</div>
          <div>
            <div class="text-[11px] text-slate-400 uppercase font-semibold">Dairy THI Index</div>
            <div class="text-xl font-extrabold text-white">THI 74 (Normal)</div>
            <div class="text-[10px] text-emerald-400">Optimal Thermal Comfort</div>
          </div>
        </div>
      </div>

      <!-- All 19 Modules Grid -->
      <div>
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-lg font-bold text-white flex items-center space-x-2">
            <span>Universal Agricultural Technology Modules</span>
            <span class="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-normal">All 19 Subsystems</span>
          </h2>
          <span class="text-xs text-slate-400">Configurable via Admin Console</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          ${activeModulesList.map(m => `
            <div onclick="navigateToModule('${m.module_key}')" class="glass-panel hover:glass-panel-glow rounded-2xl p-5 border border-slate-800 hover:border-emerald-500/40 cursor-pointer transition-all flex flex-col justify-between group">
              <div>
                <div class="flex items-center justify-between mb-3">
                  <div class="w-10 h-10 rounded-xl bg-slate-800 group-hover:bg-emerald-950 flex items-center justify-center text-xl transition-colors">
                    ${getModuleEmoji(m.module_key)}
                  </div>
                  ${m.badge ? `<span class="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 group-hover:bg-emerald-900/60 text-emerald-400 font-medium">${m.badge}</span>` : ''}
                </div>
                <h3 class="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">${m.name}</h3>
                <p class="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">${m.description}</p>
              </div>
              <div class="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-emerald-400">
                <span>Explore Module</span>
                <svg class="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

// =========================================================================
// MODULE 1: FEED & SILAGE RECOMMENDATION SYSTEM
// =========================================================================
let cachedAnimals = [];

async function renderFeedSilageModule(container) {
  container.innerHTML = `
    <div class="space-y-6 animate-fade-in theme-feed-silage p-2 rounded-2xl">
      <!-- Module Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">🌾</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">Feed and Silage Recommendation System</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            Precision ration planning, nutrient formulas &amp; silage lab analysis for cattle, buffaloes, goats, sheep, pigs &amp; poultry.
          </p>
        </div>
        <div class="flex items-center space-x-2">
          <button onclick="showAddAnimalModal()" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center space-x-1.5 shadow-md">
            <span>+ Add Animal Profile</span>
          </button>
        </div>
      </div>

      <!-- Sub Tabs: 1. Animal Profiles, 2. Feed Requirement Calculator, 3. Silage Lab Analyzer, 4. Historical Tests -->
      <div class="flex overflow-x-auto space-x-2 border-b border-slate-800 pb-2 text-xs">
        <button id="tabFeedProfiles" onclick="switchFeedTab('profiles')" class="px-4 py-2 rounded-lg font-semibold bg-emerald-600 text-white">Animal Profiles &amp; Herds</button>
        <button id="tabFeedCalc" onclick="switchFeedTab('calc')" class="px-4 py-2 rounded-lg font-semibold bg-slate-800 text-slate-300 hover:text-white">ICAR Feed Requirement Calculator</button>
        <button id="tabSilageAssess" onclick="switchFeedTab('silage')" class="px-4 py-2 rounded-lg font-semibold bg-slate-800 text-slate-300 hover:text-white">Silage Quality Assessment (Flieg Index)</button>
        <button id="tabSilageHistory" onclick="switchFeedTab('history')" class="px-4 py-2 rounded-lg font-semibold bg-slate-800 text-slate-300 hover:text-white">Lab Test Archives &amp; Records</button>
      </div>

      <!-- Tab Content Area -->
      <div id="feedTabContent" class="space-y-6">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;

  // Load animals and render initial tab
  loadAnimalsForFeed();
}

async function loadAnimalsForFeed() {
  try {
    const res = await apiFetch('/api/animals');
    const data = await res.json();
    if (data.success) {
      cachedAnimals = data.animals;
      switchFeedTab('profiles');
    }
  } catch (err) {
    console.error('Error fetching animals:', err);
  }
}

function switchFeedTab(tab) {
  const tabs = ['profiles', 'calc', 'silage', 'history'];
  tabs.forEach(t => {
    const btn = document.getElementById(`tab${t.charAt(0).toUpperCase() + t.slice(1)}`);
    if (btn) {
      if (t === tab) {
        btn.className = 'px-4 py-2 rounded-lg font-semibold bg-emerald-600 text-white shadow-md';
      } else {
        btn.className = 'px-4 py-2 rounded-lg font-semibold bg-slate-800 text-slate-300 hover:text-white';
      }
    }
  });

  const content = document.getElementById('feedTabContent');
  if (!content) return;

  if (tab === 'profiles') {
    renderFeedProfilesTab(content);
  } else if (tab === 'calc') {
    renderFeedCalcTab(content);
  } else if (tab === 'silage') {
    renderSilageAssessTab(content);
  } else if (tab === 'history') {
    renderSilageHistoryTab(content);
  }
}

function renderFeedProfilesTab(container) {
  if (cachedAnimals.length === 0) {
    container.innerHTML = `
      <div class="glass-panel rounded-2xl p-8 text-center border border-slate-800">
        <p class="text-slate-400 text-sm">No animals registered yet in your herd.</p>
        <button onclick="showAddAnimalModal()" class="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-semibold">
          Register Your First Animal
        </button>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      ${cachedAnimals.map(a => `
        <div class="glass-panel rounded-2xl p-5 border border-slate-800 flex flex-col justify-between space-y-4">
          <div>
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold">${a.animal_tag}</span>
              <span class="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-medium">${a.species}</span>
            </div>
            <h3 class="text-base font-bold text-white mt-2">${a.breed} (${a.sex})</h3>
            <p class="text-xs text-slate-400">Stage: <strong class="text-slate-200">${a.stage}</strong> • Age: ${a.age_months} Months</p>
            <div class="mt-3 grid grid-cols-2 gap-2 text-xs bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
              <div>
                <span class="text-slate-400 block text-[10px]">Body Weight</span>
                <span class="text-white font-bold text-sm">${a.body_weight_kg} kg</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">Milk Yield</span>
                <span class="text-emerald-400 font-bold text-sm">${a.milk_yield_liters > 0 ? a.milk_yield_liters + ' L/day' : 'Dry / Draught'}</span>
              </div>
            </div>
            ${a.health_notes ? `<p class="text-[11px] text-slate-400 mt-2 italic">"${a.health_notes}"</p>` : ''}
          </div>
          <div class="pt-2 border-t border-slate-800 flex items-center justify-between">
            <button onclick="calculateForAnimal('${a.id}')" class="w-full py-2 bg-emerald-600/80 hover:bg-emerald-600 text-white rounded-xl text-xs font-semibold">
              Optimize Ration for This Animal
            </button>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

function calculateForAnimal(animalId) {
  const anim = cachedAnimals.find(a => a.id === animalId);
  if (!anim) return;
  switchFeedTab('calc');
  setTimeout(() => {
    document.getElementById('calcSpecies').value = anim.species;
    document.getElementById('calcWeight').value = anim.body_weight_kg;
    document.getElementById('calcMilk').value = anim.milk_yield_liters;
    document.getElementById('calcStage').value = anim.stage;
    runNutrientCalculation();
  }, 100);
}

function renderFeedCalcTab(container) {
  container.innerHTML = `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <!-- Calculator Inputs Form -->
      <div class="lg:col-span-5 glass-panel rounded-2xl p-6 border border-slate-800 space-y-4">
        <h3 class="text-base font-bold text-white flex items-center space-x-2">
          <span>ICAR 2013 Livestock Ration Formulator</span>
        </h3>
        <p class="text-xs text-slate-400">
          Enter verified animal physiological parameters. Scientific calculations follow Indian Council of Agricultural Research guidelines.
        </p>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Livestock Species</label>
          <select id="calcSpecies" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
            <option value="Cattle">Cattle (Gir, Sahiwal, HF cross)</option>
            <option value="Buffaloes">Buffaloes (Murrah, Mehsana)</option>
            <option value="Goats">Goats (Jamnapari, Barbari)</option>
            <option value="Sheep">Sheep (Nellore, Mandya)</option>
            <option value="Pigs">Pigs (Large White Yorkshire)</option>
            <option value="Poultry">Poultry (Layers / Broilers)</option>
          </select>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Body Weight (kg)</label>
            <input type="number" id="calcWeight" value="450" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Milk Yield (L/day)</label>
            <input type="number" id="calcMilk" value="12" step="0.5" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Production Stage</label>
            <select id="calcStage" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
              <option value="Lactating">Lactating</option>
              <option value="Dry & Pregnant">Dry &amp; Pregnant</option>
              <option value="Heifer Growing">Growing / Heifer</option>
              <option value="Draught Bull">Draught Bull</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Butterfat %</label>
            <input type="number" id="calcFat" value="4.2" step="0.1" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
          </div>
        </div>

        <div class="flex items-center space-x-2 pt-1">
          <input type="checkbox" id="calcIncludeSilage" checked class="rounded text-emerald-500 focus:ring-emerald-500">
          <label for="calcIncludeSilage" class="text-xs text-slate-300">Include Fermented Maize Silage in Daily Ration</label>
        </div>

        <button onclick="runNutrientCalculation()" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-xs shadow-md">
          Calculate Nutritional Requirement &amp; Daily Ration
        </button>
      </div>

      <!-- Results Display Container -->
      <div id="calcResultsContainer" class="lg:col-span-7 glass-panel rounded-2xl p-6 border border-slate-800 space-y-5">
        <div class="text-center py-12 text-slate-500 text-xs">
          Fill the parameters on the left and click "Calculate Nutritional Requirement" to generate precision ICAR ration.
        </div>
      </div>
    </div>
  `;
}

async function runNutrientCalculation() {
  const species = document.getElementById('calcSpecies').value;
  const weight = parseFloat(document.getElementById('calcWeight').value) || 450;
  const milk = parseFloat(document.getElementById('calcMilk').value) || 0;
  const stage = document.getElementById('calcStage').value;
  const fat = parseFloat(document.getElementById('calcFat').value) || 4.2;
  const includeSilage = document.getElementById('calcIncludeSilage').checked;

  const resultsBox = document.getElementById('calcResultsContainer');
  resultsBox.innerHTML = `<div class="text-center py-8"><span class="animate-spin inline-block w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full"></span><p class="text-xs text-slate-400 mt-2">Computing ICAR stoichiometric balance...</p></div>`;

  try {
    const res = await apiFetch('/api/feed/ration', {
      method: 'POST',
      body: JSON.stringify({
        species,
        body_weight_kg: weight,
        milk_yield_liters: milk,
        stage,
        fat_pct: fat,
        include_silage: includeSilage
      })
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    const rec = data.recommendation;
    const req = rec.requirements;
    const fresh = rec.rationFreshKg;
    const cost = rec.costEstimate;

    resultsBox.innerHTML = `
      <div class="space-y-5">
        <!-- Scientific Tag -->
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <span class="inline-block px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider badge-calculated">
              Calculated Scientific Estimate
            </span>
            <span class="text-xs text-slate-400 ml-2">ICAR Tropical Standards</span>
          </div>
          <span class="text-xs text-emerald-400 font-bold">Estimated Cost: ₹${cost.totalDailyCostInr}/day</span>
        </div>

        <!-- Macro Nutrient Requirements (DM basis) -->
        <div class="grid grid-cols-3 gap-3 text-center">
          <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span class="text-[10px] text-slate-400 uppercase block font-semibold">Dry Matter Intake (DMI)</span>
            <span class="text-lg font-black text-white">${req.dmiKg} kg</span>
            <span class="text-[10px] text-slate-500 block">Total Dry Matter/day</span>
          </div>
          <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span class="text-[10px] text-slate-400 uppercase block font-semibold">Crude Protein (CP)</span>
            <span class="text-lg font-black text-emerald-400">${req.cpGrams} g</span>
            <span class="text-[10px] text-slate-500 block">Required for ${milk}L milk</span>
          </div>
          <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span class="text-[10px] text-slate-400 uppercase block font-semibold">Energy (TDN)</span>
            <span class="text-lg font-black text-amber-400">${req.tdnKg} kg</span>
            <span class="text-[10px] text-slate-500 block">Total Digestible Nutrients</span>
          </div>
        </div>

        <!-- As-Fed Fresh Weight Ration Breakdown -->
        <div>
          <h4 class="text-xs font-bold text-white uppercase tracking-wider mb-2">Recommended Fresh Feeding Quantities (As-Fed Basis):</h4>
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div class="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/20">
              <span class="text-slate-400 block text-[10px]">Ensiled Silage</span>
              <span class="text-emerald-300 font-extrabold text-sm">${fresh.silageCornKg} kg</span>
            </div>
            <div class="p-2.5 rounded-xl bg-teal-950/40 border border-teal-500/20">
              <span class="text-slate-400 block text-[10px]">Fresh Green Fodder</span>
              <span class="text-teal-300 font-extrabold text-sm">${fresh.greenFodderKg} kg</span>
            </div>
            <div class="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/20">
              <span class="text-slate-400 block text-[10px]">Dry Straw (Bhusa)</span>
              <span class="text-amber-300 font-extrabold text-sm">${fresh.dryStrawKg} kg</span>
            </div>
            <div class="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-500/20">
              <span class="text-slate-400 block text-[10px]">Compound Feed</span>
              <span class="text-indigo-300 font-extrabold text-sm">${fresh.compoundConcentrateKg} kg</span>
            </div>
          </div>
          <div class="mt-2 text-[11px] text-slate-400 flex items-center justify-between bg-slate-900/50 p-2 rounded-lg">
            <span>Mineral Mixture: <strong>${fresh.mineralMixGrams} g/day</strong></span>
            <span>Common Salt: <strong>${fresh.commonSaltGrams} g/day</strong></span>
            <span>Feed Cost/Liter Milk: <strong>${cost.costPerLiterMilkInr ? '₹' + cost.costPerLiterMilkInr : 'N/A'}</strong></span>
          </div>
        </div>

        <!-- Daily 5-Stage Schedule -->
        <div>
          <h4 class="text-xs font-bold text-white uppercase tracking-wider mb-2">Daily Feeding &amp; Milking Schedule:</h4>
          <div class="space-y-1.5 text-xs">
            ${rec.feedingSchedule.map(s => `
              <div class="flex items-start space-x-3 p-2 bg-slate-900 rounded-xl border border-slate-800">
                <span class="px-2 py-0.5 rounded bg-slate-800 text-emerald-400 font-mono text-[10px] font-bold whitespace-nowrap">${s.time}</span>
                <div>
                  <span class="font-bold text-white">${s.task}:</span>
                  <span class="text-slate-400 ml-1">${s.details}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  } catch (err) {
    resultsBox.innerHTML = `<div class="p-4 bg-red-950/50 border border-red-500/40 rounded-xl text-red-300 text-xs">${err.message}</div>`;
  }
}

// 3. SILAGE QUALITY ASSESSMENT TAB (FLIEG INDEX & LAB SIMULATOR)
function renderSilageAssessTab(container) {
  container.innerHTML = `
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <!-- Input Parameters -->
      <div class="lg:col-span-5 glass-panel rounded-2xl p-6 border border-slate-800 space-y-4">
        <h3 class="text-base font-bold text-white">Silage Quality Assessment &amp; Flieg Index</h3>
        <p class="text-xs text-slate-400">
          Enter laboratory or field measurements. Note: Visual image examination alone cannot verify microbiological feed safety.
        </p>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Sample Name</label>
          <input type="text" id="silSampleName" value="Karnal Maize Bunker #2" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Silage pH (Target: 3.8 - 4.2)</label>
            <input type="number" id="silPh" value="3.9" step="0.1" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Dry Matter % (Target: 30-35%)</label>
            <input type="number" id="silDm" value="33.0" step="0.5" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Lactic Acid % (Target: >4%)</label>
            <input type="number" id="silLactic" value="5.8" step="0.1" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Butyric Acid % (Max: &lt;0.2%)</label>
            <input type="number" id="silButyric" value="0.08" step="0.01" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Ammonia-N (% of Total N)</label>
            <input type="number" id="silAmmonia" value="6.5" step="0.5" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Measurement Source</label>
            <select id="silMeasurementType" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
              <option value="User-entered">User-entered Field Observation</option>
              <option value="Laboratory-verified">Laboratory-verified Wet Chemistry</option>
              <option value="Calculated estimate">Calculated Estimate</option>
              <option value="AI/ML prediction">AI/ML Prediction (Testing)</option>
            </select>
          </div>
        </div>

        <button onclick="runSilageAssessment()" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-xs shadow-md">
          Assess Silage Quality &amp; Flieg Score
        </button>
      </div>

      <!-- Assessment Output Box -->
      <div id="silageResultsContainer" class="lg:col-span-7 glass-panel rounded-2xl p-6 border border-slate-800 space-y-4">
        <div class="text-center py-12 text-slate-500 text-xs">
          Enter parameters and click "Assess Silage Quality" to evaluate fermentation score and safety grade.
        </div>
      </div>
    </div>
  `;
}

async function runSilageAssessment() {
  const sample_name = document.getElementById('silSampleName').value;
  const ph = parseFloat(document.getElementById('silPh').value) || 4.0;
  const dry_matter_pct = parseFloat(document.getElementById('silDm').value) || 32.0;
  const lactic_acid_pct = parseFloat(document.getElementById('silLactic').value) || 5.0;
  const butyric_acid_pct = parseFloat(document.getElementById('silButyric').value) || 0.1;
  const ammonia_n_pct = parseFloat(document.getElementById('silAmmonia').value) || 7.0;
  const measurement_type = document.getElementById('silMeasurementType').value;
  const lab_verified = measurement_type === 'Laboratory-verified';

  const resultsBox = document.getElementById('silageResultsContainer');

  try {
    const res = await apiFetch('/api/silage/assess', {
      method: 'POST',
      body: JSON.stringify({
        sample_name,
        animal_species: 'Cattle & Buffaloes',
        silage_type: 'Corn / Maize Silage',
        ph,
        dry_matter_pct,
        lactic_acid_pct,
        butyric_acid_pct,
        ammonia_n_pct,
        measurement_type,
        lab_verified
      })
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    const a = data.assessment;

    resultsBox.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <span class="text-xs font-bold text-white">${sample_name}</span>
            <div class="mt-1">
              <span class="px-2 py-0.5 rounded text-[10px] font-bold ${getMeasurementBadgeClass(a.measurementType)}">
                ${a.measurementType}
              </span>
            </div>
          </div>
          <div class="text-right">
            <span class="text-[10px] text-slate-400 uppercase block font-semibold">Flieg Index Score</span>
            <span class="text-2xl font-black text-emerald-400">${a.fliegScore} / 100</span>
          </div>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800">
          <div class="text-xs font-bold text-slate-300">Fermentation Grade:</div>
          <div class="text-base font-extrabold text-white mt-0.5">${a.grade}</div>
          <p class="text-xs text-emerald-300 mt-1 font-medium">${a.safetyVerdict}</p>
        </div>

        <!-- Key Parameter Highlights -->
        <div class="grid grid-cols-3 gap-2 text-xs">
          <div class="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
            <span class="text-slate-400 text-[10px] block">pH Acidity</span>
            <span class="font-bold text-white">${a.parametersAnalyzed.ph}</span>
          </div>
          <div class="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
            <span class="text-slate-400 text-[10px] block">Dry Matter</span>
            <span class="font-bold text-white">${a.parametersAnalyzed.dryMatterPct}%</span>
          </div>
          <div class="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
            <span class="text-slate-400 text-[10px] block">Lactic Acid</span>
            <span class="font-bold text-white">${a.parametersAnalyzed.lacticAcidPct}%</span>
          </div>
        </div>

        <!-- Technical Observations -->
        <div>
          <h5 class="text-xs font-bold text-slate-300 uppercase mb-1.5">Biochemical Observations:</h5>
          <ul class="space-y-1 text-xs text-slate-400 list-disc list-inside">
            ${a.observations.map(o => `<li>${o}</li>`).join('')}
          </ul>
        </div>

        <div class="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl text-[11px] text-amber-200">
          ⚠️ <strong>Biosecurity Disclaimer:</strong> ${a.disclaimer}
        </div>
      </div>
    `;
    showToast('Silage assessment saved to audit archive.', 'success');
  } catch (err) {
    resultsBox.innerHTML = `<div class="p-4 bg-red-950/50 border border-red-500/40 rounded-xl text-red-300 text-xs">${err.message}</div>`;
  }
}

function getMeasurementBadgeClass(type) {
  if (type === 'Laboratory-verified') return 'badge-lab';
  if (type === 'AI/ML prediction') return 'badge-ml';
  if (type === 'Calculated estimate') return 'badge-calculated';
  return 'badge-user';
}

// 4. SILAGE TEST ARCHIVES TAB
async function renderSilageHistoryTab(container) {
  container.innerHTML = `<div class="text-center py-8"><span class="animate-spin inline-block w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full"></span></div>`;
  try {
    const res = await apiFetch('/api/silage/tests');
    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    if (data.tests.length === 0) {
      container.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">No historical silage tests recorded yet.</div>`;
      return;
    }

    container.innerHTML = `
      <div class="glass-panel rounded-2xl overflow-hidden border border-slate-800">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase">
              <tr>
                <th class="py-3 px-4">Sample / Lot</th>
                <th class="py-3 px-4">Silage Crop</th>
                <th class="py-3 px-4">pH</th>
                <th class="py-3 px-4">DM %</th>
                <th class="py-3 px-4">Flieg Score</th>
                <th class="py-3 px-4">Grade</th>
                <th class="py-3 px-4">Verification</th>
                <th class="py-3 px-4">Date</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800 text-slate-300">
              ${data.tests.map(t => `
                <tr class="hover:bg-slate-900/60 transition-colors">
                  <td class="py-3 px-4 font-bold text-white">${t.sample_name}</td>
                  <td class="py-3 px-4">${t.silage_type}</td>
                  <td class="py-3 px-4 font-mono font-bold ${t.ph <= 4.2 ? 'text-emerald-400' : 'text-amber-400'}">${t.ph}</td>
                  <td class="py-3 px-4 font-mono">${t.dry_matter_pct}%</td>
                  <td class="py-3 px-4 font-mono font-black text-emerald-400">${t.flieg_score || 'N/A'}</td>
                  <td class="py-3 px-4">${t.quality_grade}</td>
                  <td class="py-3 px-4">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ${getMeasurementBadgeClass(t.measurement_type)}">
                      ${t.measurement_type}
                    </span>
                  </td>
                  <td class="py-3 px-4 text-slate-500 font-mono text-[10px]">${t.created_at ? t.created_at.slice(0, 10) : 'Recent'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 border border-red-500/40 rounded-xl text-red-300 text-xs">${err.message}</div>`;
  }
}

// Add Animal Modal
function showAddAnimalModal() {
  openModal(`
    <div class="space-y-4">
      <h3 class="text-base font-bold text-white flex items-center space-x-2">
        <span>Register New Livestock Profile</span>
      </h3>
      <p class="text-xs text-slate-400">
        Add individual animal ear tag to maintain precision lactation, body weight and ration records.
      </p>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Ear Tag / Animal ID</label>
          <input type="text" id="newAnimTag" placeholder="e.g. IN-GJ-9021" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Species</label>
          <select id="newAnimSpecies" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
            <option value="Cattle">Cattle (Cow)</option>
            <option value="Buffaloes">Buffaloes</option>
            <option value="Goats">Goats</option>
            <option value="Sheep">Sheep</option>
            <option value="Pigs">Pigs</option>
            <option value="Poultry">Poultry</option>
          </select>
        </div>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Breed Name</label>
          <input type="text" id="newAnimBreed" placeholder="Gir / Murrah / Sahiwal" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Body Weight (kg)</label>
          <input type="number" id="newAnimWeight" value="420" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
      </div>

      <div class="grid grid-cols-3 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Age (Months)</label>
          <input type="number" id="newAnimAge" value="36" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Sex</label>
          <select id="newAnimSex" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
            <option value="Female">Female</option>
            <option value="Male">Male</option>
          </select>
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Milk Yield (L)</label>
          <input type="number" id="newAnimMilk" value="10" step="0.5" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Veterinary / Health Notes</label>
        <textarea id="newAnimNotes" rows="2" placeholder="Vaccination dates, deworming, breeding history..." class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"></textarea>
      </div>

      <div class="flex justify-end space-x-3 pt-2">
        <button onclick="closeModal()" class="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs">Cancel</button>
        <button onclick="handleSaveNewAnimal()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold">Save Animal Profile</button>
      </div>
    </div>
  `);
}

async function handleSaveNewAnimal() {
  const animal_tag = document.getElementById('newAnimTag').value.trim();
  const species = document.getElementById('newAnimSpecies').value;
  const breed = document.getElementById('newAnimBreed').value.trim() || 'Indigenous Breed';
  const body_weight_kg = parseFloat(document.getElementById('newAnimWeight').value) || 400;
  const age_months = parseInt(document.getElementById('newAnimAge').value) || 24;
  const sex = document.getElementById('newAnimSex').value;
  const milk_yield_liters = parseFloat(document.getElementById('newAnimMilk').value) || 0;
  const health_notes = document.getElementById('newAnimNotes').value.trim();

  if (!animal_tag) {
    showToast('Animal tag is required.', 'error');
    return;
  }

  try {
    const res = await apiFetch('/api/animals', {
      method: 'POST',
      body: JSON.stringify({
        animal_tag,
        species,
        breed,
        body_weight_kg,
        age_months,
        sex,
        stage: milk_yield_liters > 0 ? 'Lactating' : 'Dry',
        milk_yield_liters,
        health_notes
      })
    });
    const data = await res.json();
    if (data.success) {
      showToast('Animal profile saved successfully.', 'success');
      closeModal();
      loadAnimalsForFeed();
    } else {
      showToast(data.error || 'Failed to save animal.', 'error');
    }
  } catch (err) {
    showToast('Network error while saving animal.', 'error');
  }
}

// =========================================================================
// MODULE 2: LIVESTOCK MANAGEMENT
// =========================================================================
function renderLivestockModule(container) {
  renderFeedSilageModule(container);
}

// =========================================================================
// MODULE 3: AI AGRICULTURAL ASSISTANT
// =========================================================================
function renderAssistantModule(container) {
  container.innerHTML = `
    <div class="space-y-4 max-w-4xl mx-auto animate-fade-in theme-assistant p-2 rounded-2xl">
      <div class="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">🤖</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">AI Agricultural Assistant</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            ICAR-grounded agricultural intelligence, livestock health triage, crop pathology, and feed engineering advisory.
          </p>
        </div>
        <div>
          <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-purple-950/80 text-purple-300 border border-purple-500/30">
            Model: Rule-based Advisory (Domain Fine-Tuned LLM Pending)
          </span>
        </div>
      </div>

      <!-- Chat History Container -->
      <div id="assistantChatLog" class="glass-panel rounded-2xl p-4 sm:p-6 border border-slate-800 min-h-[420px] max-h-[520px] overflow-y-auto space-y-4">
        <!-- Default Welcome Assistant Message -->
        <div class="flex items-start space-x-3">
          <div class="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-sm font-bold flex-shrink-0">
            🤖
          </div>
          <div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 max-w-2xl text-xs space-y-2">
            <div class="font-bold text-purple-300">Plantiva Agri-Intelligence Assistant:</div>
            <p class="text-slate-300 leading-relaxed">
              Namaste! I am your Agricultural Technology and Livestock Advisory Assistant. You can ask me questions regarding:
            </p>
            <ul class="list-disc list-inside text-slate-400 space-y-1">
              <li>High-quality maize silage fermentation &amp; Flieg scores</li>
              <li>Bovine mastitis detection &amp; dairy hygiene protocols</li>
              <li>Micro-irrigation and PMKSY subsidy application rules</li>
              <li>Wheat Yellow Rust (Puccinia striiformis) IPM treatments</li>
              <li>Cotton Pink Bollworm economic threshold levels (ETL)</li>
              <li>Soil Health Card NPK fertilizer dosage calculation</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Suggested Quick Prompts -->
      <div class="flex flex-wrap gap-2 text-xs">
        <button onclick="sendQuickPrompt('What is the optimal Dry Matter % and harvest stage for corn silage?')" class="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300">
          🌽 Corn Silage Dry Matter?
        </button>
        <button onclick="sendQuickPrompt('How do I prevent bovine mastitis in dairy cattle post-milking?')" class="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300">
          🐄 Post-milking Mastitis Prevention
        </button>
        <button onclick="sendQuickPrompt('What are the symptoms and fungicide spray for Wheat Yellow Rust?')" class="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300">
          🌾 Wheat Yellow Rust Control
        </button>
        <button onclick="sendQuickPrompt('How to get 55% subsidy on Drip Irrigation under PMKSY?')" class="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300">
          💧 PMKSY Drip Subsidy Rules
        </button>
      </div>

      <!-- Input Message Bar -->
      <div class="flex items-center space-x-2">
        <input type="text" id="assistantInput" onkeydown="if(event.key==='Enter') handleSendAssistantQuery()" placeholder="Type your agricultural or livestock question..." class="flex-1 px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 text-xs sm:text-sm">
        <button onclick="handleSendAssistantQuery()" class="px-5 py-3 bg-purple-600 hover:bg-purple-500 text-white font-semibold rounded-xl text-xs sm:text-sm shadow-md transition-all flex items-center space-x-1.5">
          <span>Ask</span>
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
        </button>
      </div>
    </div>
  `;
}

function sendQuickPrompt(text) {
  const input = document.getElementById('assistantInput');
  if (input) {
    input.value = text;
    handleSendAssistantQuery();
  }
}

async function handleSendAssistantQuery() {
  const input = document.getElementById('assistantInput');
  const query = input.value.trim();
  if (!query) return;

  const log = document.getElementById('assistantChatLog');
  input.value = '';

  // Append user bubble
  log.innerHTML += `
    <div class="flex items-start justify-end space-x-3">
      <div class="bg-emerald-600 text-white rounded-2xl p-3.5 max-w-xl text-xs shadow-md">
        ${query}
      </div>
      <div class="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold flex-shrink-0">
        👤
      </div>
    </div>
  `;
  log.scrollTop = log.scrollHeight;

  // Add typing bubble
  const typingId = 'typing_' + Date.now();
  log.innerHTML += `
    <div id="${typingId}" class="flex items-start space-x-3">
      <div class="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-sm font-bold flex-shrink-0">🤖</div>
      <div class="bg-slate-900 border border-slate-800 rounded-2xl p-3 max-w-md text-xs text-slate-400 flex items-center space-x-2">
        <span class="animate-spin inline-block w-3.5 h-3.5 border-2 border-purple-400 border-t-transparent rounded-full"></span>
        <span>Consulting ICAR Agricultural Knowledge Base...</span>
      </div>
    </div>
  `;
  log.scrollTop = log.scrollHeight;

  try {
    const res = await apiFetch('/api/assistant/chat', {
      method: 'POST',
      body: JSON.stringify({ query })
    });
    const data = await res.json();
    document.getElementById(typingId)?.remove();

    if (data.success) {
      const typeBadge = data.responseType === 'Verified Advisory' 
        ? '<span class="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold">Verified Advisory</span>' 
        : '<span class="px-2 py-0.5 rounded text-[10px] bg-amber-950 text-amber-400 border border-amber-500/30 font-bold">Informational Calculation</span>';

      log.innerHTML += `
        <div class="flex items-start space-x-3">
          <div class="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-sm font-bold flex-shrink-0">🤖</div>
          <div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 max-w-2xl text-xs space-y-2">
            <div class="flex items-center justify-between pb-1 border-b border-slate-800">
              <span class="font-bold text-white">${data.title || 'Agronomic Advisory'}</span>
              ${typeBadge}
            </div>
            <div class="text-slate-300 whitespace-pre-line leading-relaxed">${data.response}</div>
            <div class="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
              <span>${data.disclaimer}</span>
              <div class="flex items-center space-x-1.5">
                <button onclick="rateAssistantResponse('${data.chatId}', 1, this)" class="hover:text-emerald-400 p-1" title="Helpful">👍</button>
                <button onclick="rateAssistantResponse('${data.chatId}', -1, this)" class="hover:text-red-400 p-1" title="Unhelpful">👎</button>
              </div>
            </div>
          </div>
        </div>
      `;
    } else {
      log.innerHTML += `<div class="text-red-400 text-xs p-2">Error: ${data.error}</div>`;
    }
  } catch (err) {
    document.getElementById(typingId)?.remove();
    log.innerHTML += `<div class="text-red-400 text-xs p-2">Network error while querying assistant.</div>`;
  }
  log.scrollTop = log.scrollHeight;
}

async function rateAssistantResponse(chatId, rating, btn) {
  if (!chatId) return;
  try {
    await apiFetch('/api/assistant/feedback', {
      method: 'POST',
      body: JSON.stringify({ chat_id: chatId, rating })
    });
    btn.parentNode.innerHTML = `<span class="text-emerald-400 text-[10px]">Feedback recorded</span>`;
  } catch (e) {
    // ignore
  }
}

// =========================================================================
// MODULE 4: AGRICULTURAL MARKETING (APMC MANDI RATES)
// =========================================================================
async function renderMarketingModule(container) {
  container.innerHTML = `
    <div class="space-y-6 animate-fade-in theme-marketing p-2 rounded-2xl">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">📈</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">Agricultural Marketing &amp; Mandi Prices</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            Agmarknet APMC procurement rates, modal market prices, and commodity trends across Indian states.
          </p>
        </div>
        <button onclick="showSubmitPriceModal()" class="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-md">
          + Submit Local Mandi Price
        </button>
      </div>

      <!-- Search & Filters -->
      <div class="glass-panel rounded-2xl p-4 border border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Search Commodity or Mandi</label>
          <input type="text" id="mandiSearchInput" oninput="loadMandiPrices()" placeholder="e.g. Wheat, Basmati, Indore..." class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Filter by State</label>
          <select id="mandiStateFilter" onchange="loadMandiPrices()" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
            <option value="">All Indian States</option>
            <option value="Madhya Pradesh">Madhya Pradesh</option>
            <option value="Haryana">Haryana</option>
            <option value="Punjab">Punjab</option>
            <option value="Gujarat">Gujarat</option>
            <option value="Rajasthan">Rajasthan</option>
            <option value="Karnataka">Karnataka</option>
            <option value="Maharashtra">Maharashtra</option>
          </select>
        </div>
        <div class="flex items-end">
          <button onclick="loadMandiPrices()" class="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold">
            Refresh Rates Feed
          </button>
        </div>
      </div>

      <!-- Mandi Prices Table -->
      <div id="mandiTableContainer" class="glass-panel rounded-2xl overflow-hidden border border-slate-800">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;

  loadMandiPrices();
}

async function loadMandiPrices() {
  const container = document.getElementById('mandiTableContainer');
  if (!container) return;

  const search = document.getElementById('mandiSearchInput')?.value || '';
  const state = document.getElementById('mandiStateFilter')?.value || '';

  try {
    let url = `/api/marketing/prices?1=1`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (state) url += `&state=${encodeURIComponent(state)}`;

    const res = await apiFetch(url);
    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    container.innerHTML = `
      <div class="overflow-x-auto">
        <table class="w-full text-left text-xs">
          <thead class="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase">
            <tr>
              <th class="py-3 px-4">Commodity</th>
              <th class="py-3 px-4">Mandi / APMC</th>
              <th class="py-3 px-4">State</th>
              <th class="py-3 px-4">Modal Price (₹/Qtl)</th>
              <th class="py-3 px-4">Price Range (Min - Max)</th>
              <th class="py-3 px-4">Data Source</th>
              <th class="py-3 px-4">Recorded Date</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-800 text-slate-300">
            ${data.prices.map(p => `
              <tr class="hover:bg-slate-900/60 transition-colors">
                <td class="py-3 px-4 font-bold text-white">${p.commodity}</td>
                <td class="py-3 px-4">${p.mandi_name} (${p.district})</td>
                <td class="py-3 px-4">${p.state}</td>
                <td class="py-3 px-4 font-mono font-black text-emerald-400 text-sm">₹${p.modal_price_per_quintal.toLocaleString('en-IN')}</td>
                <td class="py-3 px-4 font-mono text-slate-400">₹${p.min_price} - ₹${p.max_price}</td>
                <td class="py-3 px-4">
                  <span class="px-2 py-0.5 rounded text-[10px] ${p.is_verified ? 'bg-blue-950 text-blue-400 border border-blue-500/30' : 'bg-slate-800 text-slate-400'}">
                    ${p.data_source}
                  </span>
                </td>
                <td class="py-3 px-4 font-mono text-[10px] text-slate-500">${p.price_date}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}

function showSubmitPriceModal() {
  openModal(`
    <div class="space-y-4">
      <h3 class="text-base font-bold text-white">Submit APMC Mandi Price Observation</h3>
      <p class="text-xs text-slate-400">All submitted prices are marked as user-submitted until verified by field enumerators.</p>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Commodity Name</label>
          <input type="text" id="newMandiCommodity" placeholder="e.g. Mustard / Chana" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Mandi Name</label>
          <input type="text" id="newMandiName" placeholder="e.g. Alwar APMC" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">District</label>
          <input type="text" id="newMandiDist" placeholder="Alwar" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">State</label>
          <input type="text" id="newMandiState" placeholder="Rajasthan" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
      </div>
      <div class="grid grid-cols-3 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Modal Price (₹)</label>
          <input type="number" id="newMandiModal" placeholder="5600" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Min Price (₹)</label>
          <input type="number" id="newMandiMin" placeholder="5300" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Max Price (₹)</label>
          <input type="number" id="newMandiMax" placeholder="5800" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
      </div>
      <div class="flex justify-end space-x-3 pt-2">
        <button onclick="closeModal()" class="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs">Cancel</button>
        <button onclick="handleSubmitPrice()" class="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-semibold">Submit Price</button>
      </div>
    </div>
  `);
}

async function handleSubmitPrice() {
  const commodity = document.getElementById('newMandiCommodity').value.trim();
  const mandi_name = document.getElementById('newMandiName').value.trim();
  const district = document.getElementById('newMandiDist').value.trim();
  const state = document.getElementById('newMandiState').value.trim();
  const modal_price = parseFloat(document.getElementById('newMandiModal').value) || 0;
  const min_price = parseFloat(document.getElementById('newMandiMin').value) || modal_price;
  const max_price = parseFloat(document.getElementById('newMandiMax').value) || modal_price;

  if (!commodity || !mandi_name || modal_price <= 0) {
    showToast('Please fill all required commodity and price fields.', 'error');
    return;
  }

  try {
    const res = await apiFetch('/api/marketing/prices', {
      method: 'POST',
      body: JSON.stringify({ commodity, mandi_name, district, state, modal_price, min_price, max_price })
    });
    const data = await res.json();
    if (data.success) {
      showToast('Price submitted successfully.', 'success');
      closeModal();
      loadMandiPrices();
    }
  } catch (err) {
    showToast('Failed to submit price.', 'error');
  }
}

// =========================================================================
// MODULE 5: BUY AND SELL MARKETPLACE
// =========================================================================
async function renderMarketplaceModule(container) {
  container.innerHTML = `
    <div class="space-y-6 animate-fade-in theme-marketplace p-2 rounded-2xl">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">🛒</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">Buy and Sell Marketplace</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            Direct peer-to-peer agricultural marketplace for livestock heifers, fodder silage bales, machinery &amp; organic inputs.
          </p>
        </div>
        <button onclick="showCreateListingModal()" class="px-3.5 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-semibold shadow-md">
          + Post Agricultural Ad
        </button>
      </div>

      <!-- Categories Filter -->
      <div class="flex overflow-x-auto space-x-2 text-xs">
        <button onclick="filterMarketplace('All')" class="px-3.5 py-1.5 rounded-lg bg-teal-600 text-white font-medium">All Goods</button>
        <button onclick="filterMarketplace('Livestock')" class="px-3.5 py-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white font-medium">Livestock Animals</button>
        <button onclick="filterMarketplace('Animal Feed & Silage')" class="px-3.5 py-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white font-medium">Silage &amp; Feed Bales</button>
        <button onclick="filterMarketplace('Machinery & Tools')" class="px-3.5 py-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white font-medium">Machinery &amp; Implements</button>
        <button onclick="filterMarketplace('Irrigation & Precision Ag')" class="px-3.5 py-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white font-medium">Precision &amp; Irrigation</button>
      </div>

      <!-- Listings Grid -->
      <div id="marketplaceGridContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;

  loadMarketplaceListings();
}

let currentMarketCategory = 'All';

async function loadMarketplaceListings(category = 'All') {
  currentMarketCategory = category;
  const container = document.getElementById('marketplaceGridContainer');
  if (!container) return;

  try {
    const res = await apiFetch(`/api/marketplace/listings?category=${encodeURIComponent(category)}`);
    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    if (data.listings.length === 0) {
      container.innerHTML = `<div class="col-span-full p-8 text-center text-slate-400 text-xs">No active listings found in this category.</div>`;
      return;
    }

    container.innerHTML = data.listings.map(l => `
      <div class="glass-panel rounded-2xl overflow-hidden border border-slate-800 flex flex-col justify-between hover:border-teal-500/40 transition-all">
        <div>
          <div class="h-44 bg-slate-900 relative flex items-center justify-center overflow-hidden">
            <div class="text-4xl text-slate-700">🌾</div>
            <span class="absolute top-3 right-3 text-[10px] px-2.5 py-0.5 rounded-full bg-slate-900/90 text-teal-400 font-bold border border-teal-500/30">
              ${l.category}
            </span>
          </div>
          <div class="p-5">
            <div class="flex items-center justify-between">
              <span class="text-base font-extrabold text-white">₹${l.price_inr.toLocaleString('en-IN')}</span>
              <span class="text-xs text-slate-400">${l.quantity} ${l.unit}</span>
            </div>
            <h3 class="text-sm font-bold text-white mt-1.5 line-clamp-1">${l.title}</h3>
            <p class="text-xs text-slate-400 mt-1 line-clamp-2">${l.description}</p>
            <div class="mt-3 flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800">
              <span>📍 ${l.location}, ${l.state}</span>
              <span>Seller: ${l.seller_name}</span>
            </div>
          </div>
        </div>
        <div class="p-4 pt-0">
          <button onclick="showEnquireModal('${l.id}', '${l.title}', '${l.seller_name}')" class="w-full py-2 bg-teal-600/90 hover:bg-teal-600 text-white rounded-xl text-xs font-semibold transition-all">
            Contact Seller / Enquire
          </button>
        </div>
      </div>
    `).join('');
  } catch (err) {
    container.innerHTML = `<div class="col-span-full p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}

function filterMarketplace(cat) {
  loadMarketplaceListings(cat);
}

function showCreateListingModal() {
  openModal(`
    <div class="space-y-4">
      <h3 class="text-base font-bold text-white">Post New Agricultural Marketplace Listing</h3>
      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Item Title</label>
        <input type="text" id="newListingTitle" placeholder="e.g. First Calver Sahiwal Cow with Calf" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Category</label>
          <select id="newListingCat" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
            <option value="Livestock">Livestock Animals</option>
            <option value="Animal Feed & Silage">Animal Feed &amp; Silage</option>
            <option value="Machinery & Tools">Machinery &amp; Tools</option>
            <option value="Irrigation & Precision Ag">Irrigation &amp; Precision Ag</option>
          </select>
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Price (₹ INR)</label>
          <input type="number" id="newListingPrice" placeholder="50000" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Quantity &amp; Unit</label>
          <input type="text" id="newListingQty" placeholder="1 Animal / 50 Bales" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Location / District</label>
          <input type="text" id="newListingLoc" placeholder="e.g. Karnal, Haryana" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
        </div>
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Detailed Description</label>
        <textarea id="newListingDesc" rows="3" placeholder="Condition, pedigree, lactation stage or technical specs..." class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"></textarea>
      </div>
      <div class="flex justify-end space-x-3 pt-2">
        <button onclick="closeModal()" class="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs">Cancel</button>
        <button onclick="handleSaveListing()" class="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-semibold">Publish Listing</button>
      </div>
    </div>
  `);
}

async function handleSaveListing() {
  const title = document.getElementById('newListingTitle').value.trim();
  const category = document.getElementById('newListingCat').value;
  const price_inr = parseFloat(document.getElementById('newListingPrice').value) || 0;
  const qtyStr = document.getElementById('newListingQty').value.trim() || '1 Unit';
  const loc = document.getElementById('newListingLoc').value.trim() || 'Local';
  const desc = document.getElementById('newListingDesc').value.trim();

  if (!title || price_inr <= 0) {
    showToast('Title and price are required.', 'error');
    return;
  }

  try {
    const res = await apiFetch('/api/marketplace/listings', {
      method: 'POST',
      body: JSON.stringify({
        title,
        category,
        price_inr,
        quantity: 1,
        unit: qtyStr,
        location: loc,
        state: 'India',
        description: desc
      })
    });
    const data = await res.json();
    if (data.success) {
      showToast('Listing published successfully!', 'success');
      closeModal();
      loadMarketplaceListings();
    }
  } catch (err) {
    showToast('Failed to post listing.', 'error');
  }
}

function showEnquireModal(listingId, title, seller) {
  openModal(`
    <div class="space-y-4">
      <h3 class="text-base font-bold text-white">Send Direct Enquiry to Seller</h3>
      <p class="text-xs text-slate-400">Regarding item: <strong class="text-teal-400">${title}</strong> (Seller: ${seller})</p>
      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Your Message</label>
        <textarea id="enquiryMsg" rows="3" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs" placeholder="I am interested in this item. Is it available for inspection?"></textarea>
      </div>
      <div class="flex justify-end space-x-3 pt-2">
        <button onclick="closeModal()" class="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs">Cancel</button>
        <button onclick="handleSendEnquiry('${listingId}')" class="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-semibold">Dispatch Enquiry</button>
      </div>
    </div>
  `);
}

async function handleSendEnquiry(listingId) {
  const message = document.getElementById('enquiryMsg').value.trim();
  if (!message) return;

  try {
    const res = await apiFetch('/api/marketplace/enquire', {
      method: 'POST',
      body: JSON.stringify({ listing_id: listingId, message })
    });
    const data = await res.json();
    if (data.success) {
      showToast('Enquiry sent to seller!', 'success');
      closeModal();
    }
  } catch (err) {
    showToast('Failed to send enquiry.', 'error');
  }
}

// =========================================================================
// MODULE 6: AGRI-ENGINEERING COMPANIES DIRECTORY
// =========================================================================
async function renderCompaniesModule(container) {
  container.innerHTML = `
    <div class="space-y-6 animate-fade-in theme-companies p-2 rounded-2xl">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">🏢</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">Agricultural Engineering Companies Directory</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            Searchable index of verified farm machinery manufacturers, micro-irrigation pioneers, dairy automation &amp; agritech corporations.
          </p>
        </div>
      </div>

      <div id="companiesGridContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;

  loadCompaniesDirectory();
}

async function loadCompaniesDirectory() {
  const container = document.getElementById('companiesGridContainer');
  if (!container) return;

  try {
    const res = await apiFetch('/api/companies');
    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    container.innerHTML = data.companies.map(c => `
      <div class="glass-panel rounded-2xl p-5 border border-slate-800 flex flex-col justify-between hover:border-indigo-500/40 transition-all">
        <div>
          <div class="flex items-start justify-between">
            <span class="text-xs px-2.5 py-0.5 rounded-full bg-indigo-950 text-indigo-300 font-semibold border border-indigo-500/30">
              ${c.category}
            </span>
            ${c.is_verified ? '<span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold">✓ Verified Company</span>' : ''}
          </div>
          <h3 class="text-base font-extrabold text-white mt-3">${c.name}</h3>
          <p class="text-xs text-slate-400 mt-1 leading-relaxed">${c.description}</p>
          <div class="mt-3 text-xs bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 space-y-1">
            <div class="text-slate-300"><strong>Products:</strong> ${c.products}</div>
            <div class="text-slate-400"><strong>Location:</strong> ${c.city}, ${c.state}, ${c.country}</div>
          </div>
        </div>
        <div class="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
          <a href="${c.website}" target="_blank" rel="noopener noreferrer" class="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center space-x-1">
            <span>Official Portal</span>
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
          </a>
          <span class="text-xs text-slate-400">${c.contact_phone}</span>
        </div>
      </div>
    `).join('');
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}

// =========================================================================
// MODULE 7: MACHINERY & EQUIPMENT DIRECTORY
// =========================================================================
async function renderMachineryModule(container) {
  container.innerHTML = `
    <div class="space-y-6 animate-fade-in theme-machinery p-2 rounded-2xl">
      <div class="flex items-center justify-between pb-4 border-b border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">🚜</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">Machinery &amp; Equipment Directory</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            Technical specifications, HP ratings, PTO requirements, and operation manuals for farm implements.
          </p>
        </div>
      </div>

      <div id="machineryGridContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;

  try {
    const res = await apiFetch('/api/machinery');
    const data = await res.json();
    const box = document.getElementById('machineryGridContainer');
    if (!box) return;

    box.innerHTML = data.machinery.map(m => `
      <div class="glass-panel rounded-2xl p-5 border border-slate-800 flex flex-col justify-between hover:border-orange-500/40 transition-all">
        <div>
          <div class="flex items-center justify-between">
            <span class="text-xs px-2.5 py-0.5 rounded-full bg-orange-950 text-orange-300 font-semibold border border-orange-500/30">
              ${m.category}
            </span>
            <span class="text-xs text-emerald-400 font-bold">${m.price_estimate}</span>
          </div>
          <h3 class="text-base font-extrabold text-white mt-2">${m.name}</h3>
          <p class="text-xs text-slate-400">${m.manufacturer} • Model: ${m.model}</p>
          <div class="mt-3 text-xs bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 space-y-1">
            <div class="text-slate-300"><strong>Engine / Power:</strong> ${m.hp_specs}</div>
            <div class="text-slate-400"><strong>Operating Specs:</strong> ${m.operating_specs}</div>
            <div class="text-slate-400"><strong>Applications:</strong> ${m.applications}</div>
          </div>
        </div>
        <div class="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
          <a href="${m.manual_url || '#'}" target="_blank" class="text-xs text-orange-400 hover:underline flex items-center space-x-1">
            <span>Technical Manual &amp; Specs PDF</span>
          </a>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.error(err);
  }
}

// =========================================================================
// MODULE 8: GOVERNMENT SCHEMES AND SUBSIDIES
// =========================================================================
async function renderSchemesModule(container) {
  container.innerHTML = `
    <div class="space-y-6 animate-fade-in theme-schemes p-2 rounded-2xl">
      <div class="flex items-center justify-between pb-4 border-b border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">🏛️</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">Government Schemes &amp; Subsidies</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            Central &amp; State subsidy programs, PM-KISAN, SMAM mechanization, NLM silage units, and PMKSY micro-irrigation.
          </p>
        </div>
      </div>

      <div id="schemesListContainer" class="space-y-4">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;

  try {
    const res = await apiFetch('/api/schemes');
    const data = await res.json();
    const box = document.getElementById('schemesListContainer');
    if (!box) return;

    box.innerHTML = data.schemes.map(s => `
      <div class="glass-panel rounded-2xl p-6 border border-slate-800 hover:border-rose-500/40 transition-all space-y-3">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span class="text-xs px-2.5 py-0.5 rounded-full bg-rose-950 text-rose-300 font-semibold border border-rose-500/30">
              ${s.category}
            </span>
            <h3 class="text-base font-extrabold text-white mt-1.5">${s.title}</h3>
            <p class="text-xs text-slate-400">${s.department} • Jurisdiction: <strong>${s.state}</strong></p>
          </div>
          <a href="${s.apply_url}" target="_blank" rel="noopener noreferrer" class="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold whitespace-nowrap self-start sm:self-center shadow-md">
            Official Application Portal ↗
          </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs bg-slate-900/60 p-3 rounded-xl border border-slate-800">
          <div>
            <span class="text-slate-400 uppercase font-semibold text-[10px] block">Benefits &amp; Subsidies</span>
            <p class="text-slate-200 mt-0.5">${s.benefits}</p>
          </div>
          <div>
            <span class="text-slate-400 uppercase font-semibold text-[10px] block">Eligibility Criteria</span>
            <p class="text-slate-200 mt-0.5">${s.eligibility}</p>
          </div>
          <div>
            <span class="text-slate-400 uppercase font-semibold text-[10px] block">Required Documents</span>
            <p class="text-slate-200 mt-0.5">${s.documents_needed}</p>
          </div>
        </div>

        <div class="flex items-center justify-between text-[11px] text-slate-500 pt-1">
          <span>Beneficiary Group: <strong>${s.beneficiary}</strong></span>
          <span>Verified on: <strong>${s.last_verified_date}</strong></span>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.error(err);
  }
}

// =========================================================================
// MODULE 9: GLOBAL CLIMATE AND WEATHER MODELS
// =========================================================================
async function renderClimateModule(container) {
  container.innerHTML = `
    <div class="space-y-6 animate-fade-in theme-climate p-2 rounded-2xl">
      <div class="flex items-center justify-between pb-4 border-b border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">🌤️</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">Global Climate and Weather Models</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            Agro-meteorological telemetry, temperature-humidity index (THI) dairy stress ratings, and CMIP6 climate model projections.
          </p>
        </div>
      </div>

      <div id="weatherStationsGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;

  try {
    const res = await apiFetch('/api/weather');
    const data = await res.json();
    const box = document.getElementById('weatherStationsGrid');
    if (!box) return;

    box.innerHTML = data.stations.map(w => `
      <div class="glass-panel rounded-2xl p-5 border border-slate-800 flex flex-col justify-between space-y-4">
        <div>
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-white">${w.location_name}</span>
            <span class="text-xs px-2 py-0.5 rounded-full bg-sky-950 text-sky-400 font-mono">${w.state}</span>
          </div>

          <!-- Temp & Humidity -->
          <div class="grid grid-cols-3 gap-2 text-center my-3">
            <div class="bg-slate-900 p-2 rounded-xl">
              <span class="text-[10px] text-slate-400 block">Temperature</span>
              <span class="text-base font-extrabold text-amber-400">${w.temp_c}°C</span>
            </div>
            <div class="bg-slate-900 p-2 rounded-xl">
              <span class="text-[10px] text-slate-400 block">Humidity</span>
              <span class="text-base font-extrabold text-sky-400">${w.humidity_pct}%</span>
            </div>
            <div class="bg-slate-900 p-2 rounded-xl">
              <span class="text-[10px] text-slate-400 block">Rainfall</span>
              <span class="text-base font-extrabold text-emerald-400">${w.rainfall_mm} mm</span>
            </div>
          </div>

          <div class="text-xs bg-slate-900/60 p-3 rounded-xl border border-slate-800 space-y-1.5">
            <div>
              <span class="text-slate-400 text-[10px] block">Dairy Cattle Heat Stress (THI):</span>
              <span class="text-emerald-300 font-bold">${w.heat_stress_index}</span>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] block">Short-term Agro Forecast:</span>
              <span class="text-slate-300">${w.forecast_summary}</span>
            </div>
            <div class="pt-1.5 border-t border-slate-800">
              <span class="text-slate-400 text-[10px] block">Long-Term Climate Model Projection:</span>
              <span class="text-amber-200/90 italic">${w.climate_projection_trend}</span>
            </div>
          </div>
        </div>

        <div class="pt-2 text-[10px] text-slate-500 border-t border-slate-800 flex items-center justify-between">
          <span>Source: ${w.data_source}</span>
          <span>Observed: ${w.recorded_at}</span>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.error(err);
  }
}

// Placeholder Renderers for Modules 10-18
function renderCropFarmModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>🌱</span><span>Crop &amp; Farm Management</span></h1>
      <p class="text-xs text-slate-400">Agronomic diary for crop rotations, sowing dates, and harvest yield records.</p>
      <div class="p-4 bg-slate-900 rounded-xl text-xs text-slate-300">
        Active Kharif crop cycle: Basmati Paddy (Karnal) • Expected Harvest: Late October. Sowing dates logged.
      </div>
    </div>
  `;
}

function renderSoilWaterModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>🧪</span><span>Soil &amp; Water Management</span></h1>
      <p class="text-xs text-slate-400">Soil Health Card register: NPK macronutrient and micronutrient balance.</p>
      <div class="grid grid-cols-3 gap-3 text-xs">
        <div class="p-3 bg-slate-900 rounded-xl"><span class="text-slate-400 block">Available Nitrogen (N)</span><span class="text-emerald-400 font-bold">240 kg/ha (Medium)</span></div>
        <div class="p-3 bg-slate-900 rounded-xl"><span class="text-slate-400 block">Available Phosphorus (P)</span><span class="text-amber-400 font-bold">18 kg/ha (Slightly Low)</span></div>
        <div class="p-3 bg-slate-900 rounded-xl"><span class="text-slate-400 block">Available Potassium (K)</span><span class="text-emerald-400 font-bold">290 kg/ha (Optimal)</span></div>
      </div>
    </div>
  `;
}

function renderIrrigationModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>💧</span><span>Irrigation &amp; Water Conservation</span></h1>
      <p class="text-xs text-slate-400">Micro-irrigation scheduler, daily evapotranspiration (ETc) water budget calculation.</p>
      <div class="p-4 bg-slate-900 rounded-xl text-xs text-slate-300">
        Today's crop water requirement: 3.8 mm/day • Drip operational run duration: 1 hr 45 min at 2.0 kg/cm² pressure.
      </div>
    </div>
  `;
}

function renderPrecisionAgriModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>🎯</span><span>Precision Agriculture</span></h1>
      <p class="text-xs text-slate-400">Drone flight logging, NDVI vegetation index analytics, and IoT telemetry.</p>
      <div class="p-4 bg-slate-900 rounded-xl text-xs text-slate-300">
        Drone flight registry: IoTech 16L Drone Sprayer • 12 Acres micronutrient foliar spray completed with 0.35 NDVI index.
      </div>
    </div>
  `;
}

function renderPostHarvestModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>📦</span><span>Processing &amp; Post-Harvest</span></h1>
      <p class="text-xs text-slate-400">Grain aeration, moisture monitoring and cold storage temperature logs.</p>
    </div>
  `;
}

function renderResearchDataModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>📊</span><span>Agricultural Research &amp; Datasets</span></h1>
      <p class="text-xs text-slate-400">Public research repository: ICAR, NDRI, and CIRB peer-reviewed nutritional standards.</p>
    </div>
  `;
}

function renderAnalyticsModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>📉</span><span>Analytics &amp; Farm Reports</span></h1>
      <p class="text-xs text-slate-400">Feed Conversion Ratio (FCR) analytics and dairy profitability charts.</p>
    </div>
  `;
}

function renderProfileModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4 max-w-xl mx-auto">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>👤</span><span>User Profile &amp; Settings</span></h1>
      <div class="space-y-3 text-xs">
        <div><span class="text-slate-400 block font-semibold">Full Name</span><span class="text-white text-sm font-bold">${currentUserSession?.full_name}</span></div>
        <div><span class="text-slate-400 block font-semibold">Registered Phone</span><span class="text-white text-sm font-mono">+91 ${currentUserSession?.phone}</span></div>
        <div><span class="text-slate-400 block font-semibold">Platform Role</span><span class="text-emerald-400 text-sm font-bold">${currentUserSession?.role}</span></div>
        <div><span class="text-slate-400 block font-semibold">Organization / Cooperative</span><span class="text-white">${currentUserSession?.organization || 'Individual Farm'}</span></div>
      </div>
    </div>
  `;
}

function renderNotificationsModule(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-8 border border-slate-800 space-y-4">
      <h1 class="text-2xl font-bold text-white flex items-center space-x-2"><span>🔔</span><span>Notifications &amp; Alerts</span></h1>
      <div class="space-y-2 text-xs">
        <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between">
          <span>🌦️ <strong>Weather Alert:</strong> Dry spell anticipated over Haryana over next 72 hours. Ideal for silage pit opening.</span>
          <span class="text-slate-500 font-mono">Today</span>
        </div>
        <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between">
          <span>📈 <strong>Mandi Alert:</strong> Indore Sharbati wheat modal price increased by ₹50 to ₹2,650/Qtl.</span>
          <span class="text-slate-500 font-mono">Yesterday</span>
        </div>
      </div>
    </div>
  `;
}

// =========================================================================
// MODULE 19: SUPER ADMIN DASHBOARD
// Full control over branding, website name, logo replacement, users, modules,
// ML models, datasets, SMS config, audit logs, and backups.
// =========================================================================
async function renderAdminModule(container) {
  if (currentUserSession?.role !== 'Super Administrator') {
    container.innerHTML = `<div class="p-8 text-center text-red-400 font-bold">Access Denied: Super Administrator privileges required.</div>`;
    return;
  }

  container.innerHTML = `
    <div class="space-y-6 animate-fade-in theme-admin p-2 rounded-2xl">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">🛡️</span>
            <h1 class="text-xl sm:text-2xl font-extrabold text-white">Super Administrator Central Command</h1>
          </div>
          <p class="text-xs sm:text-sm text-slate-400 mt-1">
            Dynamic branding controls, logo replace, module toggles, RBAC user management, AI/ML models &amp; SMS gateway governance.
          </p>
        </div>
      </div>

      <!-- Admin Tabs -->
      <div class="flex overflow-x-auto space-x-2 border-b border-slate-800 pb-2 text-xs font-semibold">
        <button id="admTabBranding" onclick="switchAdminTab('branding')" class="px-4 py-2 rounded-lg bg-red-600 text-white whitespace-nowrap">1. Branding &amp; Logo</button>
        <button id="admTabModules" onclick="switchAdminTab('modules')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 whitespace-nowrap">2. Modules Manager</button>
        <button id="admTabUsers" onclick="switchAdminTab('users')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 whitespace-nowrap">3. Users &amp; Roles</button>
        <button id="admTabModels" onclick="switchAdminTab('models')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 whitespace-nowrap">4. AI/ML Models</button>
        <button id="admTabDatasets" onclick="switchAdminTab('datasets')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 whitespace-nowrap">5. Datasets Upload</button>
        <button id="admTabSms" onclick="switchAdminTab('sms')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 whitespace-nowrap">6. SMS Gateway</button>
        <button id="admTabAudit" onclick="switchAdminTab('audit')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 whitespace-nowrap">7. Security Audit Logs</button>
        <button id="admTabBackup" onclick="switchAdminTab('backup')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 whitespace-nowrap">8. System Backup</button>
      </div>

      <!-- Admin Tab Content Box -->
      <div id="adminTabContentBox" class="space-y-5">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;

  switchAdminTab('branding');
}

function switchAdminTab(tab) {
  const tabs = ['branding', 'modules', 'users', 'models', 'datasets', 'sms', 'audit', 'backup'];
  tabs.forEach(t => {
    const btn = document.getElementById(`admTab${t.charAt(0).toUpperCase() + t.slice(1)}`);
    if (btn) {
      if (t === tab) {
        btn.className = 'px-4 py-2 rounded-lg bg-red-600 text-white whitespace-nowrap shadow-md';
      } else {
        btn.className = 'px-4 py-2 rounded-lg bg-slate-800 text-slate-300 whitespace-nowrap';
      }
    }
  });

  const box = document.getElementById('adminTabContentBox');
  if (!box) return;

  if (tab === 'branding') renderAdminBrandingTab(box);
  else if (tab === 'modules') renderAdminModulesTab(box);
  else if (tab === 'users') renderAdminUsersTab(box);
  else if (tab === 'models') renderAdminModelsTab(box);
  else if (tab === 'datasets') renderAdminDatasetsTab(box);
  else if (tab === 'sms') renderAdminSmsTab(box);
  else if (tab === 'audit') renderAdminAuditTab(box);
  else if (tab === 'backup') renderAdminBackupTab(box);
}

// 1. BRANDING & THEME TAB
function renderAdminBrandingTab(container) {
  const b = currentBranding || {};
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-6 border border-slate-800 space-y-5 max-w-3xl">
      <div>
        <h3 class="text-base font-bold text-white">Website Branding, Name &amp; Logo Configuration</h3>
        <p class="text-xs text-slate-400">
          The platform owner can modify the website name, logo URL, tagline, and theme colors at any time without rebuilding the application. Changes take effect instantly.
        </p>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Website Name</label>
          <input type="text" id="admBrandName" value="${b.website_name || 'Plantiva Tech'}" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Logo Asset URL</label>
          <input type="text" id="admBrandLogo" value="${b.logo_url || '/assets/plantiva_logo.svg'}" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
        </div>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Platform Tagline</label>
        <input type="text" id="admBrandTagline" value="${b.tagline || ''}" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
      </div>

      <div class="grid grid-cols-3 gap-3">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Primary Color</label>
          <input type="color" id="admBrandPrimary" value="${b.primary_color || '#10b981'}" class="w-full h-9 bg-slate-900 border border-slate-700 rounded-xl cursor-pointer">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Secondary Color</label>
          <input type="color" id="admBrandSecondary" value="${b.secondary_color || '#047857'}" class="w-full h-9 bg-slate-900 border border-slate-700 rounded-xl cursor-pointer">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Accent Gold</label>
          <input type="color" id="admBrandAccent" value="${b.accent_color || '#f59e0b'}" class="w-full h-9 bg-slate-900 border border-slate-700 rounded-xl cursor-pointer">
        </div>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Footer Copyright Text</label>
        <input type="text" id="admBrandFooter" value="${b.footer_text || ''}" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
      </div>

      <div class="pt-2">
        <button onclick="handleSaveBranding()" class="px-6 py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl text-xs shadow-md">
          Save &amp; Apply Branding Changes (Live Instant Update)
        </button>
      </div>
    </div>
  `;
}

async function handleSaveBranding() {
  const website_name = document.getElementById('admBrandName').value.trim();
  const logo_url = document.getElementById('admBrandLogo').value.trim();
  const tagline = document.getElementById('admBrandTagline').value.trim();
  const primary_color = document.getElementById('admBrandPrimary').value;
  const secondary_color = document.getElementById('admBrandSecondary').value;
  const accent_color = document.getElementById('admBrandAccent').value;
  const footer_text = document.getElementById('admBrandFooter').value.trim();

  try {
    const res = await apiFetch('/api/admin/branding', {
      method: 'PUT',
      body: JSON.stringify({
        website_name,
        logo_url,
        tagline,
        primary_color,
        secondary_color,
        accent_color,
        footer_text
      })
    });
    const data = await res.json();
    if (data.success) {
      applyBranding(data.branding);
      showToast('Branding updated in real-time across the platform!', 'success');
    }
  } catch (err) {
    showToast('Failed to save branding.', 'error');
  }
}

// 2. MODULES MANAGER TAB
function renderAdminModulesTab(container) {
  container.innerHTML = `
    <div class="glass-panel rounded-2xl p-6 border border-slate-800 space-y-4">
      <div class="flex items-center justify-between">
        <div>
          <h3 class="text-base font-bold text-white">Dynamic Module Configuration</h3>
          <p class="text-xs text-slate-400">Enable, disable, or rename modules dynamically without rebuilding.</p>
        </div>
      </div>

      <div class="divide-y divide-slate-800">
        ${activeModulesList.map(m => `
          <div class="py-3 flex items-center justify-between text-xs">
            <div class="flex items-center space-x-3">
              <span class="text-xl">${getModuleEmoji(m.module_key)}</span>
              <div>
                <span class="font-bold text-white">${m.name}</span>
                <span class="text-slate-500 font-mono text-[10px] ml-2">key: ${m.module_key}</span>
                <p class="text-[11px] text-slate-400">${m.description}</p>
              </div>
            </div>
            <div class="flex items-center space-x-3">
              <span class="px-2 py-0.5 rounded text-[10px] font-bold ${m.is_enabled ? 'bg-emerald-950 text-emerald-400' : 'bg-red-950 text-red-400'}">
                ${m.is_enabled ? 'Active' : 'Disabled'}
              </span>
              <button onclick="toggleModuleActive('${m.module_key}', ${m.is_enabled ? 0 : 1})" class="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold">
                ${m.is_enabled ? 'Disable' : 'Enable'}
              </button>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

async function toggleModuleActive(key, status) {
  try {
    const res = await apiFetch('/api/admin/modules', {
      method: 'PUT',
      body: JSON.stringify({ module_key: key, is_enabled: status })
    });
    const data = await res.json();
    if (data.success) {
      showToast('Module status updated.', 'success');
      await loadModulesList();
      renderAdminModulesTab(document.getElementById('adminTabContentBox'));
    }
  } catch (err) {
    showToast('Failed to update module status.', 'error');
  }
}

// 3. USERS & ROLES TAB
async function renderAdminUsersTab(container) {
  container.innerHTML = `<div class="text-center py-8"><span class="animate-spin inline-block w-6 h-6 border-2 border-red-400 border-t-transparent rounded-full"></span></div>`;
  try {
    const res = await apiFetch('/api/admin/users');
    const data = await res.json();

    container.innerHTML = `
      <div class="glass-panel rounded-2xl overflow-hidden border border-slate-800">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase">
              <tr>
                <th class="py-3 px-4">Full Name</th>
                <th class="py-3 px-4">Mobile</th>
                <th class="py-3 px-4">Email</th>
                <th class="py-3 px-4">Role</th>
                <th class="py-3 px-4">Status</th>
                <th class="py-3 px-4">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800 text-slate-300">
              ${data.users.map(u => `
                <tr class="hover:bg-slate-900/60">
                  <td class="py-3 px-4 font-bold text-white">${u.full_name}</td>
                  <td class="py-3 px-4 font-mono">+91 ${u.phone}</td>
                  <td class="py-3 px-4 text-slate-400">${u.email || 'N/A'}</td>
                  <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-emerald-400 font-bold">${u.role}</span></td>
                  <td class="py-3 px-4"><span class="text-emerald-400 font-semibold">${u.status}</span></td>
                  <td class="py-3 px-4">
                    <button onclick="showChangeRoleModal('${u.id}', '${u.full_name}', '${u.role}')" class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px]">
                      Change Role
                    </button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}

function showChangeRoleModal(userId, name, currentRole) {
  openModal(`
    <div class="space-y-4">
      <h3 class="text-base font-bold text-white">Modify User Role</h3>
      <p class="text-xs text-slate-400">Updating role for user: <strong>${name}</strong></p>
      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Select Role</label>
        <select id="userNewRoleSelect" class="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs">
          <option value="Super Administrator">Super Administrator</option>
          <option value="Farmer">Farmer</option>
          <option value="Livestock Owner">Livestock Owner</option>
          <option value="Agricultural Engineer">Agricultural Engineer</option>
          <option value="Agricultural Business / Company">Agricultural Business / Company</option>
          <option value="Buyer / Seller / Trader">Buyer / Seller / Trader</option>
          <option value="Researcher / Student">Researcher / Student</option>
          <option value="Agricultural Consultant">Agricultural Consultant</option>
          <option value="General Registered User">General Registered User</option>
        </select>
      </div>
      <div class="flex justify-end space-x-3 pt-2">
        <button onclick="closeModal()" class="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs">Cancel</button>
        <button onclick="handleUpdateUserRole('${userId}')" class="px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-semibold">Save Role</button>
      </div>
    </div>
  `);
  setTimeout(() => {
    document.getElementById('userNewRoleSelect').value = currentRole;
  }, 50);
}

async function handleUpdateUserRole(userId) {
  const role = document.getElementById('userNewRoleSelect').value;
  try {
    const res = await apiFetch(`/api/admin/users/${userId}/role`, {
      method: 'PUT',
      body: JSON.stringify({ role })
    });
    const data = await res.json();
    if (data.success) {
      showToast('User role updated.', 'success');
      closeModal();
      renderAdminUsersTab(document.getElementById('adminTabContentBox'));
    }
  } catch (err) {
    showToast('Failed to update role.', 'error');
  }
}

// 4. AI/ML MODELS MANAGEMENT TAB
async function renderAdminModelsTab(container) {
  try {
    const res = await apiFetch('/api/ml/models');
    const data = await res.json();

    container.innerHTML = `
      <div class="glass-panel rounded-2xl p-6 border border-slate-800 space-y-4">
        <div>
          <h3 class="text-base font-bold text-white">AI/ML Models &amp; Inference Registry</h3>
          <p class="text-xs text-slate-400">
            Independent integration contracts for each animal species model. Displays "Model integration pending" until officially approved by administrator.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${data.models.map(m => `
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-3">
              <div>
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-white">${m.name}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold ${m.status.includes('pending') ? 'bg-amber-950 text-amber-400 border border-amber-500/30' : 'bg-emerald-950 text-emerald-400'}">
                    ${m.status}
                  </span>
                </div>
                <p class="text-[11px] text-slate-400 mt-1">Species Category: <strong>${m.animal_category}</strong> • Ver: ${m.version}</p>
                <div class="mt-2 grid grid-cols-3 gap-2 text-center text-xs bg-slate-950 p-2 rounded-lg">
                  <div><span class="text-[10px] text-slate-500 block">Accuracy</span><span class="font-bold text-emerald-400">${m.accuracy_pct}%</span></div>
                  <div><span class="text-[10px] text-slate-500 block">F1-Score</span><span class="font-bold text-white">${m.f1_score}</span></div>
                  <div><span class="text-[10px] text-slate-500 block">RMSE</span><span class="font-bold text-white">${m.rmse}</span></div>
                </div>
              </div>
              <div class="pt-2 border-t border-slate-800 text-[10px] text-slate-500 flex items-center justify-between">
                <span>Training Dataset: ${m.dataset_version}</span>
                <span>ID: ${m.model_key}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}

// 5. DATASET UPLOAD & VALIDATION TAB
async function renderAdminDatasetsTab(container) {
  try {
    const res = await apiFetch('/api/ml/datasets');
    const data = await res.json();

    container.innerHTML = `
      <div class="space-y-6">
        <!-- Dataset Uploader Form -->
        <div class="glass-panel rounded-2xl p-6 border border-slate-800 space-y-4">
          <h3 class="text-base font-bold text-white">Upload Agricultural Training Dataset (CSV / Text)</h3>
          <p class="text-xs text-slate-400">
            Performs missing-value analysis, duplicate checks, schema verification and stores dataset in pending review state.
          </p>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Dataset Name</label>
              <input type="text" id="dsUploadName" placeholder="e.g. Murrah Buffalo Lactation Trials 2024" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Animal Category</label>
              <select id="dsUploadCategory" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
                <option value="Cattle">Cattle</option>
                <option value="Buffaloes">Buffaloes</option>
                <option value="Goats">Goats</option>
                <option value="Sheep">Sheep</option>
                <option value="Pigs">Pigs</option>
                <option value="Poultry">Poultry</option>
                <option value="Silage Quality">Silage Quality</option>
              </select>
            </div>
          </div>

          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Paste CSV Content (Header Row + Data Rows)</label>
            <textarea id="dsUploadRaw" rows="4" placeholder="animal_id,body_weight_kg,milk_yield_liters,fat_pct&#10;GIR-101,450,14.5,4.2&#10;GIR-102,420,12.0,4.5" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs"></textarea>
          </div>

          <button onclick="handleUploadDataset()" class="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl text-xs shadow-md">
            Validate &amp; Ingest Dataset
          </button>
        </div>

        <!-- Ingested Datasets Table -->
        <div class="glass-panel rounded-2xl overflow-hidden border border-slate-800">
          <div class="p-4 border-b border-slate-800 font-bold text-xs uppercase text-slate-300">Curated Dataset Catalog</div>
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase">
              <tr>
                <th class="py-3 px-4">Dataset Name</th>
                <th class="py-3 px-4">Category</th>
                <th class="py-3 px-4">Rows</th>
                <th class="py-3 px-4">Missing Values</th>
                <th class="py-3 px-4">Status</th>
                <th class="py-3 px-4">Uploaded By</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800 text-slate-300">
              ${data.datasets.map(d => `
                <tr class="hover:bg-slate-900/60">
                  <td class="py-3 px-4 font-bold text-white">${d.name}</td>
                  <td class="py-3 px-4">${d.animal_category}</td>
                  <td class="py-3 px-4 font-mono">${d.row_count}</td>
                  <td class="py-3 px-4 font-mono ${d.missing_values_count > 0 ? 'text-amber-400' : 'text-emerald-400'}">${d.missing_values_count}</td>
                  <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-emerald-400 font-bold">${d.validation_status}</span></td>
                  <td class="py-3 px-4 text-slate-400">${d.uploaded_by}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}

async function handleUploadDataset() {
  const name = document.getElementById('dsUploadName').value.trim();
  const animal_category = document.getElementById('dsUploadCategory').value;
  const raw_data = document.getElementById('dsUploadRaw').value.trim();

  if (!name || !raw_data) {
    showToast('Name and CSV data are required.', 'error');
    return;
  }

  try {
    const res = await apiFetch('/api/ml/datasets/upload', {
      method: 'POST',
      body: JSON.stringify({ name, animal_category, raw_data })
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      renderAdminDatasetsTab(document.getElementById('adminTabContentBox'));
    } else {
      showToast(data.error || 'Upload failed.', 'error');
    }
  } catch (err) {
    showToast('Upload error.', 'error');
  }
}

// 6. SMS GATEWAY CONFIGURATION TAB
async function renderAdminSmsTab(container) {
  try {
    const res = await apiFetch('/api/admin/sms-config');
    const data = await res.json();
    const c = data.config;

    container.innerHTML = `
      <div class="glass-panel rounded-2xl p-6 border border-slate-800 space-y-4 max-w-2xl">
        <h3 class="text-base font-bold text-white">SMS OTP Provider &amp; DLT Gateway Configuration</h3>
        <p class="text-xs text-slate-400">
          Configure production credentials for Indian DLT-compliant SMS providers (MSG91, Twilio, Fast2SMS).
        </p>

        <div class="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl text-xs text-amber-200">
          ⚠️ <strong>Development-Only Testing Mode Active:</strong> If credentials are not set, OTPs are provided in interactive test toasts for rapid evaluation.
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Provider Gateway</label>
          <input type="text" id="admSmsProvider" value="${c.provider || ''}" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Sender ID (DLT Header)</label>
          <input type="text" id="admSmsSender" value="${c.sender_id || 'PLANTV'}" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase mb-1">Masked Secret API Key</label>
          <input type="text" id="admSmsKey" value="${c.api_key_masked || 'NOT_CONFIGURED'}" placeholder="Enter new secret key to replace" class="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs">
        </div>

        <div class="flex items-center space-x-2 pt-1">
          <input type="checkbox" id="admSmsDevMode" ${c.dev_test_mode ? 'checked' : ''} class="rounded text-red-500 focus:ring-red-500">
          <label for="admSmsDevMode" class="text-xs text-slate-300">Enable Development-Only Testing Mode</label>
        </div>

        <button onclick="handleSaveSmsConfig()" class="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl text-xs shadow-md">
          Save Gateway Configuration
        </button>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}

async function handleSaveSmsConfig() {
  const provider = document.getElementById('admSmsProvider').value.trim();
  const sender_id = document.getElementById('admSmsSender').value.trim();
  const api_key = document.getElementById('admSmsKey').value.trim();
  const dev_test_mode = document.getElementById('admSmsDevMode').checked ? 1 : 0;

  try {
    const res = await apiFetch('/api/admin/sms-config', {
      method: 'PUT',
      body: JSON.stringify({ provider, sender_id, api_key, dev_test_mode })
    });
    const data = await res.json();
    if (data.success) {
      showToast('SMS configuration updated.', 'success');
    }
  } catch (err) {
    showToast('Failed to update SMS configuration.', 'error');
  }
}

// 7. SECURITY AUDIT LOGS TAB
async function renderAdminAuditTab(container) {
  try {
    const res = await apiFetch('/api/admin/audit-logs');
    const data = await res.json();

    container.innerHTML = `
      <div class="glass-panel rounded-2xl overflow-hidden border border-slate-800">
        <div class="p-4 border-b border-slate-800 font-bold text-xs uppercase text-slate-300 flex items-center justify-between">
          <span>Security Audit Trail &amp; Access Logs</span>
          <span class="text-[10px] text-slate-500 font-mono">${data.logs.length} Recent Events</span>
        </div>
        <div class="overflow-x-auto max-h-[500px]">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase sticky top-0">
              <tr>
                <th class="py-3 px-4">Event Action</th>
                <th class="py-3 px-4">User ID</th>
                <th class="py-3 px-4">IP Address</th>
                <th class="py-3 px-4">Payload Details</th>
                <th class="py-3 px-4">Timestamp</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800 text-slate-300">
              ${data.logs.map(l => `
                <tr class="hover:bg-slate-900/60">
                  <td class="py-2.5 px-4 font-mono font-bold text-emerald-400">${l.action}</td>
                  <td class="py-2.5 px-4 font-mono text-[11px] text-slate-400">${l.user_id || 'guest'}</td>
                  <td class="py-2.5 px-4 font-mono text-[11px] text-slate-400">${l.ip || '127.0.0.1'}</td>
                  <td class="py-2.5 px-4 font-mono text-[10px] text-slate-400 max-w-xs truncate">${l.details}</td>
                  <td class="py-2.5 px-4 font-mono text-[10px] text-slate-500">${l.created_at}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}

// 8. SYSTEM BACKUP & HEALTH TAB
async function renderAdminBackupTab(container) {
  try {
    const res = await apiFetch('/api/admin/stats');
    const data = await res.json();
    const s = data.stats;

    container.innerHTML = `
      <div class="glass-panel rounded-2xl p-6 border border-slate-800 space-y-6 max-w-xl">
        <h3 class="text-base font-bold text-white">Application Health &amp; Database Backup</h3>
        <div class="grid grid-cols-2 gap-3 text-xs">
          <div class="p-3 bg-slate-900 rounded-xl"><span class="text-slate-400 block">Total Users</span><span class="text-lg font-bold text-white">${s.totalUsers}</span></div>
          <div class="p-3 bg-slate-900 rounded-xl"><span class="text-slate-400 block">Livestock Animals</span><span class="text-lg font-bold text-emerald-400">${s.totalAnimals}</span></div>
          <div class="p-3 bg-slate-900 rounded-xl"><span class="text-slate-400 block">Silage Tests</span><span class="text-lg font-bold text-amber-400">${s.totalSilageTests}</span></div>
          <div class="p-3 bg-slate-900 rounded-xl"><span class="text-slate-400 block">Mandi Price Records</span><span class="text-lg font-bold text-blue-400">${s.totalMandiPrices}</span></div>
        </div>

        <div class="pt-2">
          <a href="/api/admin/backup" target="_blank" download="plantiva_backup.json" class="inline-block px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl text-xs shadow-md">
            Download Complete Database Backup (JSON Export)
          </a>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="p-4 bg-red-950/50 text-red-300 text-xs">${err.message}</div>`;
  }
}
