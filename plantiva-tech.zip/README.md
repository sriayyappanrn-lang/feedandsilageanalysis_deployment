# Plantiva Tech — Universal Agricultural Technology Platform

> **Universal Agricultural & Livestock Intelligence Platform**  
> Tailored for Indian farmers, livestock owners, agricultural businesses, agricultural engineers, researchers, traders, and agricultural machinery companies.

---

## 🌟 Executive Summary & Capabilities

**Plantiva Tech** is a full-stack, modular, secure agricultural technology platform developed to professional engineering standards. It eliminates static templates by providing:

1. **Centralized Dynamic Branding & Identity Engine**:
   - Platform name, logo, favicon, tagline, typography, and palette (primary, secondary, and accent colors) can be configured, previewed, and modified in real-time from the **Super Admin Dashboard** without rebuilding or restarting the application.
2. **Mandatory Login-First Security Gate**:
   - The platform opens directly to a hardened authentication gate.
   - All internal dashboards, department features, market data, and private APIs are strictly guarded on the server.
   - Built-in rate limiting, OTP expiry timers, brute-force lockout, and session token verification.
   - DLT-ready SMS OTP gateway integration with a clear, safe **Development-Only Testing Mode**.
3. **Role-Based Access Control (RBAC)**:
   - Dedicated access controls and customized views for:
     * **Super Administrator**
     * **Farmer**
     * **Livestock Owner**
     * **Agricultural Engineer**
     * **Agricultural Business / Company**
     * **Buyer / Seller / Trader**
     * **Researcher / Student**
     * **Agricultural Consultant**
     * **General Registered User**
4. **Feed & Silage Recommendation System**:
   - Animal-specific profiles: **Cattle (Cows), Buffaloes, Goats, Sheep, Pigs, and Poultry**.
   - Scientific nutrition estimations based on **ICAR (Indian Council of Agricultural Research)** and **NRC** standards (Dry Matter Intake, Crude Protein, TDN, Calcium, Phosphorus).
   - Fresh-weight daily ration breakdown (Green Fodder, Corn Silage, Dry Straw, Compound Concentrates, Mineral Mixture).
   - Real-time daily feeding cost estimation (₹ INR) and feed cost per liter of milk.
   - **Silage Quality Assessment & Flieg Index Simulator**:
     * Supports pH, Dry Matter %, Lactic Acid %, Butyric Acid %, and Ammonia-N %.
     * Computes Flieg's Score (0–100) and assigns Class I (Excellent) through Class V (Very Poor / Spoiled).
     * Distinguishes explicitly between: *User-entered*, *Laboratory-verified*, *Calculated estimates*, and *AI/ML predictions*.
5. **AI/ML Model Registry & Dataset Portal**:
   - Independent integration contracts for 8+ animal and feed models.
   - Displays clear `"Model integration pending"` status prior to administrative approval.
   - CSV and Excel dataset ingest pipeline with missing-value analysis and duplicate detection.
6. **AI Agricultural Assistant**:
   - Domain-grounded agronomic advisory engine.
   - Pre-loaded with ICAR pest management, dairy mastitis prevention protocols, and PMKSY subsidy guidance.
   - User feedback capture (helpful / unhelpful rating).
7. **APMC Mandi Agricultural Marketing**:
   - Modal prices per quintal for cereals, pulses, oilseeds, and fodder across Indian Mandis.
   - Location filtering by State and District with explicit data source attribution.
8. **Agricultural Engineering Directory & Machinery**:
   - Searchable index of verified irrigation companies, tractor manufacturers, drone technology firms, and dairy automation providers.
   - Machinery specifications, PTO ratings, and operating guides.
9. **Government Schemes & Subsidies**:
   - Up-to-date central and state agricultural programs: **SMAM (Mechanization), NLM (Feed & Silage Units), PMKSY (Per Drop More Crop), PM-KISAN, and PMFBY**.
10. **Global Climate & Agro-Meteorology Models**:
    - Real-time weather observatory telemetry with Cattle Heat-Stress Index (THI), crop water evapotranspiration demand, and CMIP6 long-term climate projections.

---

## 🚀 Quick Start Guide

### 1. Requirements
- Node.js v22.5+ or embedded Antigravity runtime (`node:sqlite` native support).

### 2. Launch Server
```powershell
# Navigate to project directory
cd C:\Users\LENOVO\.gemini\antigravity\scratch\plantiva-tech

# Start the platform
node server/index.js
```
The application will start on: **`http://localhost:3000`**

---

## 🔑 Pre-Configured Test Accounts

| Role | Mobile Number | Password | Notes |
|---|---|---|---|
| **Super Administrator** | `9876543210` | `Admin@123` | Full administrative control, branding, user roles & audit logs |
| **Farmer** | `9876500001` | `Farmer@123` | Gujarat Kisan Cooperative, Gir Cattle herd |
| **Livestock Owner** | `9876500002` | `Farmer@123` | Gokul Dairy Farm, Murrah Buffaloes & Silage Pits |
| **Agri Engineer** | `9876500003` | `Engineer@123` | Krishi Tech Labs Pune, Smart Drip IoT & Machinery |
| **Mandi Trader** | `9876500004` | `Farmer@123` | Karnal Grain Traders, APMC Price Feeds |
| **Researcher** | `9876500005` | `Engineer@123` | ICAR - NDRI Karnal, Lactation & Feed Datasets |

> *Tip: You can also log in via SMS OTP. When testing mode is active, the 6-digit test OTP appears directly in an interactive toast and auto-populates.*

---

## 🏗️ Architecture & Technology Stack

```
plantiva-tech/
├── package.json               # Platform definition & scripts
├── README.md                  # Comprehensive documentation
├── data/
│   └── plantiva.db            # High-performance SQLite database (node:sqlite)
├── server/
│   ├── index.js               # HTTP/1.1 static file & REST API server
│   ├── db.js                  # Database schema, foreign keys & seed data
│   ├── auth.js                # PBKDF2 hashing, sessions, rate limits & OTP engine
│   ├── feedEngine.js          # ICAR nutritional balance & Flieg silage index
│   ├── assistantEngine.js     # Agricultural knowledge base & advisory contract
│   └── api.js                 # REST controllers & server-side RBAC enforcement
└── public/
    ├── index.html             # Mandatory login-first gate & responsive SPA layout
    ├── css/
    │   └── style.css          # Glassmorphism, CSS variables & visual themes
    ├── js/
    │   ├── branding.js        # Reactive theme, logo & title applicator
    │   ├── auth.js            # Session authentication & OTP gatekeeper
    │   ├── modules.js         # Controllers for all 19 agricultural modules
    │   └── app.js             # Toast notifications & modal manager
    └── assets/
        ├── plantiva_logo.svg  # High-definition vector brand logo
        ├── favicon.svg        # Brand icon
        ├── agri_bg_tech.svg   # Geometric contour & satellite background
        ├── dairy_cattle_feed.jpg  # Photorealistic modern dairy cattle feed shed
        └── precision_agritech.jpg # Photorealistic drone sprayer & solar drip station
```

---

## 🔒 Security Architecture
- **Server-Side Enforcement**: All protected endpoints verify the session token and role before querying or mutating data.
- **PBKDF2 Cryptographic Hashing**: Unique 16-byte cryptographic salt per user, 10,000 rounds of SHA-512.
- **Brute-Force & Rate Limiting**: OTP generation is throttled to 4 requests per 10 minutes; incorrect OTP attempts invalidate the record after 3 strikes.
- **Audit Logging**: Every authentication event, silage test, marketplace ad, and administrative configuration change is logged with IP and payload details in the audit trail.
