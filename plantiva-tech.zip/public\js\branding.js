/**
 * Plantiva Tech - Centralized Branding & Theme Controller
 * Allows platform administrator to update name, logo, typography and theme colors
 * in real-time without needing to rebuild or restart the application.
 */

let currentBranding = null;

async function loadBrandingConfig() {
  try {
    const res = await fetch('/api/branding');
    const data = await res.json();
    if (data.success && data.branding) {
      applyBranding(data.branding);
    }
  } catch (err) {
    console.error('Failed to load branding config:', err);
  }
}

function applyBranding(b) {
  currentBranding = b;

  // 1. Update Document Title & Favicon
  if (b.website_name) {
    document.title = `${b.website_name} — Universal Agricultural Technology Platform`;
    const titleEl = document.getElementById('pageTitle');
    if (titleEl) titleEl.innerText = `${b.website_name} — Universal Agricultural Technology Platform`;
  }
  if (b.favicon_url) {
    const fav = document.getElementById('pageFavicon');
    if (fav) fav.href = b.favicon_url;
  }

  // 2. Update Brand Logos
  const authLogo = document.getElementById('authBrandLogo');
  if (authLogo && b.logo_url) {
    authLogo.src = b.logo_url;
    authLogo.alt = b.website_name;
  }
  const navLogo = document.getElementById('navBrandLogo');
  if (navLogo && b.logo_url) {
    navLogo.src = b.logo_url;
    navLogo.alt = b.website_name;
  }

  // 3. Update Hero Title & Subtitle
  const authHeroTitle = document.getElementById('authHeroTitle');
  if (authHeroTitle) authHeroTitle.innerText = b.hero_title || b.website_name;

  const authHeroSubtitle = document.getElementById('authHeroSubtitle');
  if (authHeroSubtitle) authHeroSubtitle.innerText = b.hero_subtitle || b.tagline;

  const authFooter = document.getElementById('authFooterText');
  if (authFooter) authFooter.innerText = b.footer_text || `${b.website_name} — Empowering Indian Agriculture`;

  // 4. Update CSS Custom Properties (Colors & Typography)
  const root = document.documentElement;
  if (b.primary_color) {
    root.style.setProperty('--primary-color', b.primary_color);
  }
  if (b.secondary_color) {
    root.style.setProperty('--secondary-color', b.secondary_color);
  }
  if (b.accent_color) {
    root.style.setProperty('--accent-color', b.accent_color);
  }
  if (b.font_family) {
    root.style.setProperty('--font-family', b.font_family);
  }
}

// Initial trigger
document.addEventListener('DOMContentLoaded', () => {
  loadBrandingConfig();
});
