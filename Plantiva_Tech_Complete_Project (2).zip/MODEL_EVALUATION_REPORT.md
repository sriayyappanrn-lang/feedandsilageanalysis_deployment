# MODEL EVALUATION REPORT - PLANTIVA TECH

## 1. Dataset Descriptions
- **Disease Detection Dataset**: 250,000 observations of Cattle demographics, feeding behavior, immunization statuses, and targeted health metrics.
- **Feed & Silage Quality Performance Dataset**: 30,000 cattle nutrient-yield telemetry rows analyzed.

## 2. Model Performance
- **Cattle Health Classification**: Multinomial Logistic Regression model achieved validation accuracy of **55.58%**.
- **Silage Productivity Regression**: Random Forest model mapping livestock forage qualities onto actual production targets.

## 3. Preprocessing
- Robust Categorical Feature Handling using `One-Hot Encoding`.
- Standard Feature Normalization using fit-mapped `StandardScaler` scalers.
