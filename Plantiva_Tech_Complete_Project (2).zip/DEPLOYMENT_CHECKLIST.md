# DEPLOYMENT CHECKLIST

1. Ensure Python 3.9+ environment is configured.
2. Extract 'Plantiva_Tech_Complete_Project.zip'.
3. Set up virtual environment: `python -m venv venv`.
4. Install exact requirements: `pip install -r requirements.txt`.
5. Launch Flask Server: `python app.py`.
6. Test endpoints locally at `http://localhost:5000/health`.
