import os
import joblib
import pandas as pd
import numpy as np
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

app = Flask(__name__, static_folder='static')
CORS(app) 

# Model 1 Paths: Disease Classification
DISEASE_MODEL = 'logistic_regression_model.joblib'
DISEASE_SCALER = 'scaler.joblib'
DISEASE_FEATURES = 'model_features.joblib'

# Model 2 Paths: Feed & Silage Regression
FEED_MODEL = 'feed_regression_model.joblib'
FEED_SCALER = 'feed_scaler.joblib'
FEED_FEATURES = 'feed_features.joblib'

# Startup loading container
models = {}

try:
    if os.path.exists(DISEASE_MODEL) and os.path.exists(DISEASE_SCALER) and os.path.exists(DISEASE_FEATURES):
        models['disease_model'] = joblib.load(DISEASE_MODEL)
        models['disease_scaler'] = joblib.load(DISEASE_SCALER)
        models['disease_features'] = joblib.load(DISEASE_FEATURES)
        print("Loaded Disease Classification Model.")
        
    if os.path.exists(FEED_MODEL) and os.path.exists(FEED_SCALER) and os.path.exists(FEED_FEATURES):
        models['feed_model'] = joblib.load(FEED_MODEL)
        models['feed_scaler'] = joblib.load(FEED_SCALER)
        models['feed_features'] = joblib.load(FEED_FEATURES)
        print("Loaded Feed & Silage Regression Model.")
except Exception as e:
    print(f"Startup Load Error: {e}")

@app.route('/')
def home():
    return jsonify({
        "status": "online",
        "project": "Plantiva Tech Livestock Core API",
        "endpoints": ["/health", "/features", "/predict", "/silage-quality"]
    })

@app.route('/health')
def health():
    status = {"disease_loaded": 'disease_model' in models, "feed_loaded": 'feed_model' in models}
    return jsonify(status)

@app.route('/features', methods=['GET'])
def features():
    return jsonify({
        "disease_inputs": models.get('disease_features', []),
        "feed_inputs": models.get('feed_features', [])
    })

@app.route('/predict', methods=['POST'])
def predict_disease():
    if 'disease_model' not in models:
        return jsonify({"error": "Disease model unavailable"}), 503
    try:
        data = request.get_json(force=True)
        df_in = pd.DataFrame([data])
        df_encoded = pd.get_dummies(df_in)
        df_aligned = df_encoded.reindex(columns=models['disease_features'], fill_value=0)
        scaled = models['disease_scaler'].transform(df_aligned)
        pred = models['disease_model'].predict(scaled)[0]
        return jsonify({"predicted_disease_status": pred})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/silage-quality', methods=['POST'])
def predict_feed_quality():
    if 'feed_model' not in models:
        return jsonify({"error": "Feed quality model unavailable"}), 503
    try:
        data = request.get_json(force=True)
        df_in = pd.DataFrame([data])
        df_aligned = df_in.reindex(columns=models['feed_features'], fill_value=0)
        scaled = models['feed_scaler'].transform(df_aligned)
        pred_yield = models['feed_model'].predict(scaled)[0]
        
        # Scientific Silage Recommendation logic built dynamically
        recommendation = "Standard Feed Ration" 
        if pred_yield > 20.0:
            recommendation = "High-Protein Clover Silage with Alfalfa mix"
        elif pred_yield > 10.0:
            recommendation = "Moderate Forage Silage combined with Maize Corn Cob"
        
        return jsonify({
            "expected_milk_yield_L": float(pred_yield),
            "recommended_silage_diet": recommendation
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/test-interface')
def serve_frontend():
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
